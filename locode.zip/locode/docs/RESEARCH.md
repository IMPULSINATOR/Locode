# Research notes: how the big harnesses work

Field notes gathered while designing locode (July 2026). Links were live at
the time of writing.

## Claude Code

**The loop.** Claude Code runs a single-threaded master agent loop (named
`nO` in the minified source; an async queue `h2A` feeds user steering
messages into it mid-turn). One model, one flat message history, one loop:
call the model, execute whatever tools it asked for, append results, repeat
until it answers in plain text. There is no planner/executor split and no
multi-agent graph. Complexity lives in the tools and prompts, not the
control flow.

**Tools.** About twenty, with a three-tier activation system (always-on,
conditional, feature-flagged). The workhorses: `Bash` (persistent shell
session with command risk classification and injection filtering), `Read`
(numbered `cat -n`-style output), `Edit` (exact string replacement — the
old string must match and be unique), `Write`, `Glob`, `Grep`, `TodoWrite`
(a structured plan the UI renders as a checklist), and `Task` /
`dispatch_agent` — a subagent with its own context window that explores and
returns only a report. Subagents cannot spawn subagents.

**Permissions.** A tiered permission system gates tool execution: per-tool
rules, session allowlists ("always allow"), and risk classification for
shell commands so destructive operations prompt even in permissive modes.

**Context.** Auto-compaction triggers around 92% of the window (the `wU2`
compressor summarizes the transcript into a continuation note), plus
lighter "microcompaction" of old tool outputs. `CLAUDE.md` files form a
memory hierarchy injected into the system prompt, and `system-reminder`
blocks nudge the model about state (todo list, plan mode) between turns.

Sources:
- https://blog.promptlayer.com/claude-code-behind-the-scenes-of-the-master-agent-loop/
- https://callsphere.ai/blog/inside-claude-code-s-architecture-how-the-agent-loop-works
- https://bits-bytes-nn.github.io/insights/agentic-ai/2026/03/31/claude-code-architecture-analysis.html
- https://kotrotsos.medium.com/claude-code-internals-part-2-the-agent-loop-5b3977640894
- https://github.com/VILA-Lab/Dive-into-Claude-Code
- https://code.claude.com/docs/en/agent-sdk/agent-loop (official description of the loop)
- https://arxiv.org/html/2604.14228v1 (comparative study of coding-agent harnesses)

## Codex CLI

**Rust core.** Codex was rewritten from TypeScript into Rust (`codex-rs`) —
a single static binary with the agent loop, TUI and sandbox in one process.

**Sandboxing.** Unlike Claude Code's application-level gating, Codex
enforces isolation at the OS level: Seatbelt profiles on macOS,
Landlock + seccomp on Linux. Three modes: `read-only`,
`workspace-write` (write inside the repo, ask for anything else), and
`danger-full-access`. Approval and sandboxing compose: a `ToolOrchestrator`
checks approval policy, picks a sandbox, executes, and can retry with
escalated permissions after asking.

**Editing.** A dedicated `apply_patch` tool consumes a custom diff format
(grammar-checked) rather than string replacement.

**Project memory.** `AGENTS.md` files form an instruction chain — global
`~/.codex/AGENTS.md`, then repo root, then each directory down to the cwd;
later files override earlier ones, with a size cap (32 KiB) on what gets
injected.

**History discipline.** Message history is append-only and prompt-cache
friendly: config changes mid-session are appended as new messages rather
than rewriting earlier ones, so the server-side prefix cache stays warm.
Sessions persist in SQLite and can be resumed or forked.

Sources:
- https://developers.openai.com/codex/cli
- https://developers.openai.com/codex/guides/agents-md
- https://github.com/openai/codex/blob/main/AGENTS.md
- https://codex.danielvaughan.com/2026/03/28/codex-rs-rust-rewrite-architecture/
- https://botmonster.com/posts/openai-codex-cli-rust-powered-ai-agent/
- https://agent-safehouse.dev/docs/agent-investigations/codex

## The counterpoint: mini-SWE-agent

The SWE-bench authors' mini-SWE-agent scores competitively on SWE-bench
with ~100 lines of control flow, one tool (bash), and a *stateless*
subprocess per command. Lesson taken: the loop should stay trivial, and a
fresh shell per command eliminates a whole class of hung-session bugs.
locode adopts the stateless shell and keeps richer file tools.

- https://github.com/SWE-agent/mini-swe-agent

## Target models

**Qwen 3.6** (April 2026, Apache 2.0): `Qwen3.6-27B` (dense, multimodal)
and `Qwen3.6-35B-A3B` (MoE, ~3B active). Native context 262,144 tokens,
hybrid thinking (`<think>` blocks), strong native tool calling. vLLM needs
`--reasoning-parser qwen3 --enable-auto-tool-choice --tool-call-parser
qwen3_coder`. Qwen's own agentic-coding evals sample at temperature 1.0 /
top_p 0.95. The Qwen 3.5 family (0.8B–397B-A17B, Feb–Mar 2026) covers the
smaller sizes and works identically in this harness.

- https://qwen.ai/blog?id=qwen3.6-27b
- https://huggingface.co/Qwen/Qwen3.6-27B
- https://github.com/QwenLM/Qwen3.6
- https://unsloth.ai/docs/models/qwen3.6
- https://ollama.com/library/qwen3.6:27b

**Gemma 4** (April 2026): `E2B` / `E4B` efficient models (128K context)
and `12B` / `26B-A4B` MoE / `31B` (256K context). This generation adds
native function calling, a native system role, and a toggleable thinking
mode. Google's reference docs still describe template-level call parsing,
but Ollama, LM Studio and vLLM all expose it through the standard OpenAI
`tools` parameter — locode defaults Gemma 4 to native mode and falls back
to prompted mode for older Gemma or bare llama.cpp servers.

- https://blog.google/innovation-and-ai/technology/developers-tools/gemma-4/
- https://ai.google.dev/gemma/docs/capabilities/text/function-calling-gemma4
- https://ai.google.dev/gemma/docs/core/model_card_4
- https://machinelearningmastery.com/how-to-implement-tool-calling-with-gemma-4-and-python/
