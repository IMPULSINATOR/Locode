# Architecture

locode is architecture-faithful to Claude Code and Codex CLI, not a
product-parity clone — see the honesty notes in README.md for what's
still missing. This document maps each design decision to its source and
lists the module layout.

## Design mapping

| Feature | Inspired by | locode implementation |
|---|---|---|
| Core agent loop (plan → tool → observe) | Claude Code's nO loop | `agent.py: Agent.run_turn` |
| Native + prompted tool calling | Claude Code (native), Hermes format (prompted fallback) | `llm.py`, `parsing.py: extract_tool_calls` |
| Stateless shell | mini-SWE-agent | fresh subprocess per bash call, `tools/shell.py` |
| Agent Skills + progressive disclosure | open standard (agentskills.io), Claude Code | `skills.py` + `skill` tool; reads `.claude/skills` too |
| Custom slash commands | Claude Code `.claude/commands` | markdown templates, `$ARGUMENTS`/`$1..$9` |
| Plugins (skills+commands+agents bundles) | Claude Code plugins | `plugins.py`; Claude Code repo layout readable |
| Full-screen terminal UI | Claude Code (Ink/React) | `tui.py` (Textual — Python's Ink analogue) |
| Custom subagents | Claude Code `.claude/agents` | `agents.py`; `task(agent=…)`; parallel fan-out ≤4 |
| MCP tool servers | MCP standard (Claude Code, Codex) | `mcp.py` stdio client; `mcp__srv__tool` naming |
| Hooks | Claude Code hooks | `hooks.py`; exit-2 blocks, stderr → model |
| Repo orientation | Aider repo-map (NOT RAG — CC skips RAG deliberately) | `project_map()` file tree in the system prompt |
| @file mentions | Claude Code | inline attachment expansion in `run_turn` |
| Clarifying questions | Claude Code AskUserQuestion | `ask_user` tool; modal w/ options + custom answer |
| Plan mode | Claude Code /plan + Shift+Tab | tool gate + preamble + approve→execute gate in `drive()` |
| Goal loops | Claude Code /goal | auto-continue until GOAL_MET marker, capped rounds |
| Side questions | Claude Code /btw | one-off completion over a copy of history, never appended |
| Context breakdown | Claude Code /context | per-role token bars via `/context` |
| Web fetch/search | Claude Code WebFetch/WebSearch (no RAG) | `tools/web.py`; search via Tavily/Brave/SearXNG config |
| Training-data pipeline | (locode-specific) | `datagen.py`: verified rollouts through the real Agent |
| Multi-line prompt | Claude Code Shift+Enter | `PromptArea(TextArea)`; Enter submits, Ctrl+J newline |
| Clipboard copy | Claude Code | `App.copy_to_clipboard()` (OSC52) on Ctrl+Shift+C |
| Session replay | (fixes silent --continue) | `replay_transcript()` renders restored messages into #chat |
| Session resume + picker | Claude Code /resume | `sessions.py`: one file per conversation, not per turn; `/resume` + multi-session `--continue` picker |
| Environment auto-setup | (fixes Windows path-guessing bug) | `envdetect.py`: venv/node_modules put on PATH automatically |

## Module layout

```
locode/
├── __init__.py    version string
├── config.py      Config dataclass, layered loading (defaults → toml → env → CLI)
├── llm.py         OpenAI-compatible client: streaming, tool-call parsing
├── anthropic_compat.py  Anthropic Messages-format client (for GLM/teacher use)
├── parsing.py     tool-call extraction (native + Hermes-style prompted), token estimate
├── safety.py      command risk classification (incl. Windows/PowerShell patterns), path jail
├── prompts.py     system prompt assembly, project map, AGENTS.md chain
├── envdetect.py   Python venv / node_modules detection → PATH injection + prompt notes
├── agent.py       the Agent class: run_turn, drive() (plan/goal), compaction, mentions
├── agents.py      custom subagent definitions (.claude/agents compatible)
├── mcp.py         MCP stdio client: handshake, tools/list, tools/call
├── hooks.py       lifecycle hooks (blocking pre-tool-use / prompt-submit)
├── sessions.py    one JSON file per conversation; list/restore for --continue and /resume
├── skills.py      Agent Skills: SKILL.md parsing + multi-dir discovery
├── commands.py    custom slash commands (markdown templates)
├── plugins.py     plugin discovery + install (git/path)
├── replcmds.py     slash-command logic shared by the REPL and the TUI
├── datagen.py     fine-tuning data generation: verified real-tool rollouts
├── cli.py         argument parsing, REPL loop, TUI launch, datagen/plugin subcommands
├── ui.py          plain-REPL rendering: streams, diffs, approvals, ask_user picker
├── tui.py         Textual app: chat log, modals, status bar, worker thread
└── tools/         registry + the built-in tools (read/write/edit/glob/grep,
                   bash, todo_write, task, skill, ask_user, web_fetch,
                   web_search) plus dynamically-registered MCP tools
```

## TUI threading model

The agent loop is synchronous and blocking, so the Textual app runs it in
a worker thread and marshals every UI touch through `call_from_thread`. A
`TextualUI` adapter implements the same interface as the plain `UI`, which
is what keeps the agent completely UI-agnostic — the same `Agent` class
drives the REPL, one-shot mode, the TUI, and `datagen`'s rollouts.

Approvals and clarifying questions block the worker on a `Queue` until
their modal resolves. Esc sets an interrupt flag the adapter checks at
each stream chunk and tool call, raising `KeyboardInterrupt` inside the
worker — the agent unwinds it safely by filling any pending tool results
so the transcript stays valid for the next turn.

The prompt itself (`PromptArea`, a `TextArea` subclass) intercepts Enter
to submit and Ctrl+J to insert a newline, and only recalls arrow-key
history when its buffer is a single line — on multi-line content the
arrows move the cursor instead, like a normal text editor. A defensive
regex (`_strip_leaked_escapes`) scrubs any stray terminal mouse/CSI escape
fragment that slips into the widget (observed on some Windows terminals
during modal-close focus transitions) rather than relying on disabling
mouse capture globally, which would also break clicking approval buttons
and wheel-scrolling the chat log.

## Session model

Each real conversation gets one file
(`~/.local/share/locode/sessions/<project-hash>/<session_id>.json`),
updated in place on every turn rather than snapshotted per turn — that's
what makes `list_sessions()` a meaningful picker (one entry per genuine
past conversation) instead of dozens of near-duplicate growth snapshots
of the same thread. `--continue` restores the single most recent session
directly when there's only one; when there are several, it opens the same
picker `/resume` does (a modal in the TUI, a numbered list in `--plain`)
rather than silently guessing which one you meant.

## Subagent tool access

The default subagent the `task` tool falls back to (no `agent=` given) is
read-only by design, matching Claude Code's own built-in researcher
subagent. Two reasons converge here: subagents report back only a final
summary (you don't see each intermediate step the way you do for the main
agent's own tool calls), and locode fans independent subagents out **in
parallel** (`_parallelizable`, up to 4 concurrent) whenever every
participant is safely read-only — concurrent uncoordinated writes to
shared files would be a correctness hazard, so the parallel path
requires it. This is a default, not a hard limit: a **custom** subagent
(`.claude/agents/*.md`) can whitelist `write_file`/`edit_file`/`bash` in
its `tools:` frontmatter and will genuinely get them — it simply becomes
ineligible for the parallel fast-path and runs serially instead, with its
own approval flow like any other tool call.
