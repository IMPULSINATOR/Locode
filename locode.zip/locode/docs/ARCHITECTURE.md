# locode architecture

locode is a deliberate remix: Claude Code's loop-and-tools shape, Codex's
approval modes and project-instruction chain, mini-SWE-agent's stateless
shell — rebuilt in ~2,000 lines of Python for models that run on your own
GPU and make mistakes frontier models don't.

## Design mapping

| Idea | Origin | locode implementation |
|---|---|---|
| Single flat agent loop | Claude Code `nO`, mini-SWE-agent | `agent.py` — one `while` loop, no graphs |
| Small sharp toolset | Claude Code | bash, read_file, write_file, edit_file, glob, grep, todo_write, task |
| Exact-unique string edits | Claude Code `Edit` | `edit_file` with teaching error messages |
| Todo list as working memory | Claude Code `TodoWrite` | `todo_write` + checklist rendering; survives compaction |
| Read-only research subagent, no recursion | Claude Code `dispatch_agent` | `task` tool, depth limit 1, read-only registry |
| Approval modes | Codex sandbox policies | `read-only` / `workspace-write` / `full-access` |
| Command risk classification | Claude Code bash gating | `safety.py` regex tiers: safe / risky / dangerous |
| Project instruction chain | Codex `AGENTS.md` | `AGENTS.md` / `CLAUDE.md` / `LOCODE.md`, root→cwd, 24k char cap |
| Auto-compaction | Claude Code (~92%) | summarize-and-bridge at 75% of the context budget |
| Append-only history | Codex prompt-cache discipline | messages are never rewritten, only appended |
| Stateless shell | mini-SWE-agent | fresh subprocess per bash call |
| Agent Skills + progressive disclosure | open standard (agentskills.io), Claude Code | `skills.py` + `skill` tool; reads `.claude/skills` too |
| Custom slash commands | Claude Code `.claude/commands` | markdown templates, `$ARGUMENTS`/`$1..$9` |
| Plugins (skills+commands bundles) | Claude Code plugins | `plugins.py`; Claude Code repo layout readable |
| Full-screen terminal UI | Claude Code (Ink/React) | `tui.py` (Textual — Python's Ink analogue) |
| Custom subagents | Claude Code `.claude/agents` | `agents.py`; `task(agent=…)`; parallel fan-out ≤4 |
| MCP tool servers | MCP standard (Claude Code, Codex) | `mcp.py` stdio client; `mcp__srv__tool` naming |
| Hooks | Claude Code hooks | `hooks.py`; exit-2 blocks, stderr → model |
| Session resume | Codex SQLite threads | `sessions.py` JSON snapshots; `--continue` |
| Repo orientation | Aider repo-map (NOT RAG — CC skips RAG deliberately) | `project_map()` file tree in the system prompt |
| @file mentions | Claude Code | inline attachment expansion in `run_turn` |
| Clarifying questions | Claude Code AskUserQuestion | `ask_user` tool; modal w/ options + custom answer |
| Plan mode | Claude Code /plan + Shift+Tab | tool gate + preamble + approve→execute gate in `drive()` |
| Goal loops | Claude Code /goal | auto-continue until GOAL_MET marker, capped rounds |
| Side questions | Claude Code /btw | one-off completion over a copy of history, never appended |
| Context breakdown | Claude Code /context | per-role token bars via `/context` |
| Web fetch/search | Claude Code WebFetch/WebSearch (no RAG) | `tools/web.py`; search via Tavily/Brave/SearXNG config |
| Training-data pipeline | (locode-specific) | `datagen.py`: verified rollouts through the real Agent |

Where locode deliberately differs, it is because the target models are
smaller: the system prompt is shorter and more imperative, prompted mode
allows only **one** tool call per message, tool errors are written as
instructions for recovery, and a repetition guard halts identical-call
loops (small models loop far more often than frontier ones).

## Module map

```
locode/
├── cli.py        flags, REPL, slash commands, one-shot -p mode
├── agent.py      the loop: gate → execute → append; compaction; guards
├── llm.py        OpenAI-compatible transport; streaming; think-tag filter
├── parsing.py    Hermes <tool_call> extraction; lenient JSON; token estimate
├── prompts.py    system prompt; env block; AGENTS.md discovery; compaction prompt
├── safety.py     command risk regexes; project path jail
├── config.py     family profiles (qwen/gemma/generic); TOML/env/flag layering
├── ui.py         plain-REPL rendering: streams, diffs, approvals
├── tui.py        Textual app: chat log, modals, status bar, worker thread
├── skills.py     Agent Skills: SKILL.md parsing + multi-dir discovery
├── commands.py   custom slash commands (markdown templates)
├── plugins.py    plugin discovery + install (git/path)
├── replcmds.py   slash-command logic shared by REPL and TUI
├── agents.py     custom subagent definitions (.claude/agents compatible)
├── mcp.py        MCP stdio client: handshake, tools/list, tools/call
├── hooks.py      lifecycle hooks (blocking pre-tool-use / prompt-submit)
├── sessions.py   per-project session snapshots for --continue
└── tools/        registry + the ten built-in tools (+ MCP tools)
```

## TUI threading model

The agent loop is synchronous and blocking, so the Textual app runs it in
a worker thread and marshals every UI touch through `call_from_thread`. A
`TextualUI` adapter implements the same interface as the plain `UI`, which
is what keeps the agent completely UI-agnostic. Approvals block the worker
on a `Queue` until the modal resolves; Esc sets an interrupt flag the
adapter checks at each stream chunk and tool call, raising
`KeyboardInterrupt` inside the worker — the agent unwinds it safely by
filling any pending tool results so the transcript stays valid for the
next turn.

## The loop

```
run_turn(user_text):
    append user message
    for step in range(max_steps):
        compact history if past 75% of budget
        turn = model(messages [, tools])          # native or prompted
        calls = normalize(turn)                   # one transport-neutral list
        if no calls: append final text; return it
        append assistant message (transport-specific shape)
        for call in calls:
            approval = tool.approve(agent, args)  # allow / ask / deny
            result  = tool.run(agent, args)       # or denial text
            append result (role:"tool" | <tool_response> user message)
```

## Two tool transports

**Native** (default for Qwen 3.6/3.5 and Gemma 4 on Ollama/vLLM/LM Studio):
schemas go in the `tools` parameter; the server's parser returns structured
`tool_calls`; results return as `role:"tool"` messages. Streaming deltas
are accumulated per-index.

**Prompted** (fallback for any model/server without a tool parser): tool
docs are rendered into the system prompt and the model is told to emit
exactly one Hermes-style block per message —

```
<tool_call>
{"name": "tool_name", "arguments": {"param": "value"}}
</tool_call>
```

Results go back inside `<tool_response name="...">…</tool_response>` in a
user message (the format Qwen models saw in training). The parser tolerates
unclosed tags, fenced-JSON variants, trailing commas and single quotes; a
malformed call triggers a corrective message instead of a crash, and the
`<tool_call>` marker also tells the stream filter to stop echoing raw JSON
to the screen.

## Approval matrix

| | read-only | workspace-write | full-access |
|---|---|---|---|
| read_file / glob / grep / todo / task | allow | allow | allow |
| write_file / edit_file in project | **deny** | allow | allow |
| write/edit outside project | **deny** | ask | allow |
| bash — safe command | ask | allow | allow |
| bash — risky (sudo, installs, pushes, recursive rm…) | ask | ask | allow |
| bash — dangerous (rm -rf /, dd to devices, fork bombs…) | ask | ask | **ask** |

`a` at any prompt allows that tool for the rest of the session; dangerous
commands always ask unless `--dangerously-allow-all`. This is app-level
gating (Claude Code's approach), not an OS sandbox (Codex's) — a seatbelt,
not a cage.

## Context management

Token use is estimated locally (~4 chars/token — server-agnostic). Past
75% of `context_tokens − max_output_tokens`, the agent summarizes everything
but the last few messages through the `COMPACT_PROMPT` (GOAL / STATE /
LEARNED / PENDING / NEXT), then rebuilds history as
`[system, bridge-summary, recent tail]`, cutting only at a user-message
boundary so native tool-call/result pairs are never split. The todo list
doubles as externalized working memory across compactions.
