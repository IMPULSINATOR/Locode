"""Tests for v0.3: MCP client, hooks, sessions, @mentions, custom agents,
project map, parallel-task gating, and the new TUI affordances."""
from __future__ import annotations

import asyncio
import json
import sys
from types import SimpleNamespace

import pytest

from locode.agent import Agent
from locode.agents import discover_agents
from locode.config import Config
from locode.hooks import merge_hooks, run_hooks
from locode.llm import ToolCall, Turn
from locode.tui import LocodeApp
from locode.ui import UI

from test_harness import FakeLLM

ECHO_SERVER = r'''
import sys, json
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    msg = json.loads(line)
    m, mid = msg.get("method"), msg.get("id")
    if m == "initialize":
        out = {"jsonrpc": "2.0", "id": mid, "result": {
            "protocolVersion": "2025-03-26", "capabilities": {"tools": {}},
            "serverInfo": {"name": "echo", "version": "1"}}}
    elif m == "tools/list":
        out = {"jsonrpc": "2.0", "id": mid, "result": {"tools": [{
            "name": "echo", "description": "Echo text back.",
            "inputSchema": {"type": "object",
                            "properties": {"text": {"type": "string"}},
                            "required": ["text"]}}]}}
    elif m == "tools/call":
        t = msg["params"]["arguments"].get("text", "")
        out = {"jsonrpc": "2.0", "id": mid, "result": {
            "content": [{"type": "text", "text": "echo: " + t}],
            "isError": False}}
    elif mid is not None:
        out = {"jsonrpc": "2.0", "id": mid,
               "error": {"code": -32601, "message": "unknown"}}
    else:
        continue
    sys.stdout.write(json.dumps(out) + "\n")
    sys.stdout.flush()
'''


@pytest.fixture
def env(tmp_path, monkeypatch):
    home = tmp_path / "home"
    proj = tmp_path / "proj"
    home.mkdir(), proj.mkdir()
    monkeypatch.setattr("pathlib.Path.home", staticmethod(lambda: home))
    cfg = Config(project_dir=proj, stream=False)
    cfg.family = "generic"
    return SimpleNamespace(home=home, proj=proj, cfg=cfg)


def quiet_ui():
    return UI(interactive=False, quiet=True)


# ------------------------------------------------------------------ MCP

def test_mcp_end_to_end_through_agent(env, tmp_path):
    server = tmp_path / "echo_server.py"
    server.write_text(ECHO_SERVER)
    env.cfg.mcp_servers = {"echo": {"command": sys.executable,
                                    "args": [str(server)]}}
    env.cfg.approval = "full-access"       # MCP tools auto-allow only here

    args = {"text": "hello mcp"}
    turns = [
        Turn(text="", tool_calls=[ToolCall(
            id="c1", name="mcp__echo__echo", arguments=args,
            raw_arguments=json.dumps(args))]),
        Turn(text="The server replied."),
    ]
    agent = Agent(env.cfg, ui=quiet_ui())
    try:
        assert "mcp__echo__echo" in agent.registry
        assert "[MCP:echo]" in agent.registry["mcp__echo__echo"].description
        agent.llm = FakeLLM(turns)
        final = agent.run_turn("ping the echo server")
        assert final == "The server replied."
        tool_msg = next(m for m in agent.messages if m["role"] == "tool")
        assert tool_msg["content"] == "echo: hello mcp"
    finally:
        agent.close()


def test_mcp_asks_approval_below_full_access(env, tmp_path):
    server = tmp_path / "echo_server.py"
    server.write_text(ECHO_SERVER)
    env.cfg.mcp_servers = {"echo": {"command": sys.executable,
                                    "args": [str(server)]}}
    args = {"text": "x"}
    turns = [
        Turn(text="", tool_calls=[ToolCall(
            id="c1", name="mcp__echo__echo", arguments=args,
            raw_arguments=json.dumps(args))]),
        Turn(text="ok"),
    ]
    agent = Agent(env.cfg, ui=quiet_ui())   # workspace-write, non-interactive
    try:
        agent.llm = FakeLLM(turns)
        agent.run_turn("ping")
        tool_msg = next(m for m in agent.messages if m["role"] == "tool")
        assert "Denied" in tool_msg["content"]   # auto-denied ask
    finally:
        agent.close()


# ---------------------------------------------------------------- hooks

def test_hook_blocks_tool_and_prompt(env):
    guard = env.proj / "guard.py"
    guard.write_text(
        "import sys, json\n"
        "d = json.load(sys.stdin)\n"
        "if d['event'] == 'pre-tool-use' and d['tool'] == 'write_file':\n"
        "    print('writes are frozen today', file=sys.stderr); sys.exit(2)\n"
        "if d['event'] == 'user-prompt-submit' and 'forbidden' in d['prompt']:\n"
        "    print('nope', file=sys.stderr); sys.exit(2)\n")
    env.cfg.hooks = {
        "pre-tool-use": [f"{sys.executable} {guard}"],
        "user-prompt-submit": [f"{sys.executable} {guard}"],
    }
    blocked, msg = run_hooks(merge_hooks(env.cfg), "pre-tool-use",
                             {"tool": "write_file", "arguments": {}})
    assert blocked and "frozen" in msg
    blocked, _ = run_hooks(merge_hooks(env.cfg), "pre-tool-use",
                           {"tool": "read_file", "arguments": {}})
    assert not blocked

    wargs = {"path": "x.txt", "content": "hi"}
    turns = [
        Turn(text="", tool_calls=[ToolCall(id="c1", name="write_file",
                                           arguments=wargs,
                                           raw_arguments=json.dumps(wargs))]),
        Turn(text="understood"),
    ]
    agent = Agent(env.cfg, ui=quiet_ui())
    agent.llm = FakeLLM(turns)
    agent.run_turn("write x.txt")
    tool_msg = next(m for m in agent.messages if m["role"] == "tool")
    assert "Blocked by a user-configured hook" in tool_msg["content"]
    assert not (env.proj / "x.txt").exists()

    agent2 = Agent(env.cfg, ui=quiet_ui())
    agent2.llm = FakeLLM([Turn(text="never called")])
    out = agent2.run_turn("do the forbidden thing")
    assert "blocked by hook" in out and len(agent2.llm.turns) == 1


# -------------------------------------------------------------- sessions

def test_session_save_and_continue(env):
    turns = [Turn(text="Remembered.")]
    agent = Agent(env.cfg, ui=quiet_ui())
    agent.llm = FakeLLM(turns)
    agent.todos = [{"content": "step", "status": "pending"}]
    agent.goal = "ship the feature"
    agent.run_turn("remember the plan")

    from locode import sessions
    fresh = Agent(env.cfg, ui=quiet_ui())
    data = sessions.restore(fresh, quiet_ui())
    assert data
    assert fresh.todos == [{"content": "step", "status": "pending"}]
    assert fresh.goal == "ship the feature"
    assert fresh.input_history == ["remember the plan"]
    contents = [m.get("content", "") for m in fresh.messages]
    assert any("remember the plan" in c for c in contents)
    assert "Remembered." in contents
    assert fresh.messages[0]["role"] == "system"


# -------------------------------------------------------------- mentions

def test_at_file_mention_expansion(env):
    (env.proj / "notes.txt").write_text("SECRET-PLAN-42\n")
    agent = Agent(env.cfg, ui=quiet_ui())
    agent.llm = FakeLLM([Turn(text="read it")])
    agent.run_turn("summarize @notes.txt please")
    user_msg = agent.messages[1]["content"]
    assert "SECRET-PLAN-42" in user_msg and "Attached file" in user_msg
    # non-existent mention is left alone
    agent2 = Agent(env.cfg, ui=quiet_ui())
    agent2.llm = FakeLLM([Turn(text="ok")])
    agent2.run_turn("what about @missing.txt")
    assert "Attached file" not in agent2.messages[1]["content"]


# --------------------------------------------------------- custom agents

def write_agent(env, name="reviewer", tools=None):
    d = env.proj / ".claude" / "agents"
    d.mkdir(parents=True, exist_ok=True)
    tline = f"tools: {tools}\n" if tools else ""
    (d / f"{name}.md").write_text(
        f"---\nname: {name}\ndescription: reviews code for bugs\n{tline}---\n"
        f"You are {name}. Be thorough.")


def test_agent_defs_discovery_and_prompt(env):
    write_agent(env, "reviewer", tools="read_file, grep, task")
    (env.proj / "src").mkdir()
    (env.proj / "src" / "main.py").write_text("print('x')\n")
    defs = discover_agents(env.cfg)
    assert defs["reviewer"].tools == ["read_file", "grep"]  # task stripped
    agent = Agent(env.cfg, ui=quiet_ui())
    sp = agent.messages[0]["content"]
    assert "# Custom subagents" in sp and "reviewer:" in sp
    assert "# Project layout" in sp and "main.py" in sp  # repo map present


def test_task_routes_to_custom_agent(env, monkeypatch):
    write_agent(env, "reviewer")
    captured = {}

    class StubAgent:
        def __init__(self, cfg, ui, depth=0, subagent=False, agent_def=None):
            captured["agent_def"] = agent_def

        def run_turn(self, prompt):
            captured["prompt"] = prompt
            return "stub report"

    monkeypatch.setattr("locode.agent.Agent", StubAgent)
    from locode.tools.task import run_task
    parent = SimpleNamespace(cfg=env.cfg, depth=0, ui=quiet_ui(),
                             agent_defs=discover_agents(env.cfg))
    out = run_task(parent, {"agent": "reviewer", "prompt": "check auth"})
    assert "stub report" in out
    assert captured["agent_def"].name == "reviewer"
    out = run_task(parent, {"agent": "ghost", "prompt": "x"})
    assert "no subagent named" in out and "reviewer" in out


def test_parallel_gate(env):
    write_agent(env, "writer", tools="read_file, bash")
    agent = Agent(env.cfg, ui=quiet_ui())
    mk = lambda i, a=None: ToolCall(
        id=f"c{i}", name="task",
        arguments={"prompt": "x", **({"agent": a} if a else {})})
    assert agent._parallelizable([mk(1), mk(2)])
    assert not agent._parallelizable([mk(1)])                    # single
    assert not agent._parallelizable([mk(1), mk(2, "writer")])   # has bash
    other = ToolCall(id="c9", name="bash", arguments={"command": "ls"})
    assert not agent._parallelizable([mk(1), other])             # mixed


# ------------------------------------------------------------------- TUI

async def wait_until(pred, timeout=8.0):
    for _ in range(int(timeout / 0.05)):
        if pred():
            return True
        await asyncio.sleep(0.05)
    return False


async def test_tui_slash_suggestions_and_activity(env):
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="done")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        prompt = app.query_one("#prompt")
        prompt.focus()
        await pilot.press("slash", "s", "k")
        assert app.suggestions_open
        names = [n for n, _ in app._sugg_items]
        assert "skills" in names
        await pilot.press("tab")
        assert prompt.text.startswith("/skills")
        assert not app.suggestions_open
        # activity line switches on while busy
        prompt.load_text("hello")
        await pilot.press("enter")
        act = app.query_one("#activity")
        seen_on = await wait_until(lambda: act.has_class("on") or not app.busy,
                                   timeout=2)
        assert seen_on
        await wait_until(lambda: not app.busy)
        assert not act.has_class("on")


async def test_tui_suggestions_scroll_past_the_fold(env):
    """Regression: with 14 builtins, ↓ past row 7 must scroll the popup
    and keep the highlight visible; /mcp and /quit must be reachable."""
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="done")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        prompt = app.query_one("#prompt")
        prompt.focus()
        await pilot.press("slash")
        assert app.suggestions_open
        names = [n for n, _ in app._sugg_items]
        assert len(names) >= 14                      # no more 8-item cap
        assert "mcp" in names and "quit" in names    # previously unreachable
        for _ in range(10):
            await pilot.press("down")
        await pilot.pause()
        assert app._sugg_sel == 10
        box = app.query_one("#suggestions")
        assert box.scroll_y > 0                      # container scrolled
        await pilot.press("tab")
        assert prompt.text == f"/{names[10]} "


async def test_tui_tool_dropdown_collapsed(env):
    args = {"path": "a.txt", "content": "x"}
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([
            Turn(text="", tool_calls=[ToolCall(
                id="c1", name="write_file", arguments=args,
                raw_arguments=json.dumps(args))]),
            Turn(text="done"),
        ])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        app.query_one("#prompt").load_text("make a.txt")
        await pilot.press("enter")
        ok = await wait_until(lambda: not app.busy)
        assert ok
        from textual.widgets import Collapsible
        boxes = list(app.query(Collapsible))
        assert boxes, "tool call should render as a Collapsible"
        assert boxes[0].collapsed
        assert "write_file" in str(boxes[0].title)


# ------------------------------------------------------------- ask_user

def test_plain_ui_ask_user(monkeypatch):
    ui = UI(interactive=True)
    ui.interactive = True                       # force despite no tty
    monkeypatch.setattr(ui.console, "input", lambda *a, **k: "2")
    assert ui.ask_user("Which DB?", ["Postgres", "SQLite"]) == "SQLite"
    monkeypatch.setattr(ui.console, "input", lambda *a, **k: "use redis")
    assert ui.ask_user("Which DB?", ["Postgres"]) == "use redis"
    monkeypatch.setattr(ui.console, "input", lambda *a, **k: "")
    assert ui.ask_user("Which DB?", []) == ""   # skip
    assert quiet_ui().ask_user("Which DB?", []) is None


def test_ask_user_noninteractive_tells_model_to_proceed(env):
    qargs = {"question": "Tabs or spaces?", "options": ["tabs", "spaces"]}
    turns = [
        Turn(text="", tool_calls=[ToolCall(id="c1", name="ask_user",
                                           arguments=qargs,
                                           raw_arguments=json.dumps(qargs))]),
        Turn(text="Going with spaces."),
    ]
    agent = Agent(env.cfg, ui=quiet_ui())
    assert "ask_user" in agent.registry
    agent.llm = FakeLLM(turns)
    final = agent.run_turn("format the file")
    assert final == "Going with spaces."
    tool_msg = next(m for m in agent.messages if m["role"] == "tool")
    assert "best judgment" in tool_msg["content"]


async def test_tui_ask_user_pick_option(env):
    qargs = {"question": "Which database should the site use?",
             "options": ["Postgres", "SQLite", "MySQL"]}
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([
            Turn(text="", tool_calls=[ToolCall(
                id="c1", name="ask_user", arguments=qargs,
                raw_arguments=json.dumps(qargs))]),
            Turn(text="Using SQLite then."),
        ])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 32)) as pilot:
        app.query_one("#prompt").load_text("set up the db layer")
        await pilot.press("enter")
        from locode.tui import QuestionScreen
        ok = await wait_until(lambda: isinstance(app.screen, QuestionScreen))
        assert ok, "question modal never appeared"
        await pilot.press("down", "enter")          # highlight #2, select
        ok = await wait_until(lambda: not app.busy)
        assert ok
        tool_msg = next(m for m in app.agent.messages
                        if m["role"] == "tool")
        assert tool_msg["content"] == "The user answered: SQLite"
        assert "[ask_user] -> 'SQLite'" in app.ui_adapter.transcript


async def test_tui_ask_user_custom_answer(env):
    qargs = {"question": "Deploy target?", "options": ["Vercel", "Netlify"]}
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([
            Turn(text="", tool_calls=[ToolCall(
                id="c1", name="ask_user", arguments=qargs,
                raw_arguments=json.dumps(qargs))]),
            Turn(text="Righto."),
        ])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 32)) as pilot:
        app.query_one("#prompt").load_text("ship it")
        await pilot.press("enter")
        from locode.tui import QuestionScreen
        ok = await wait_until(lambda: isinstance(app.screen, QuestionScreen))
        assert ok
        box = app.screen.query_one("#question-input")
        box.focus()
        await pilot.pause()
        await pilot.press(*"raspberry pi", "enter")
        ok = await wait_until(lambda: not app.busy)
        assert ok
        tool_msg = next(m for m in app.agent.messages
                        if m["role"] == "tool")
        assert tool_msg["content"] == "The user answered: raspberry pi"
        assert app.query_one("#prompt").text == ""  # main input untouched
