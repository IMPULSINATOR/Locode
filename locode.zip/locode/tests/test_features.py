"""Tests for skills, plugins, custom commands, and the Textual TUI."""
from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace

import pytest

from locode.agent import Agent
from locode.commands import discover_commands, expand_command
from locode.config import Config
from locode.llm import ToolCall, Turn
from locode.plugins import discover_plugins
from locode.skills import discover_skills, parse_frontmatter
from locode.tools.skill import run_skill
from locode.tui import LocodeApp
from locode.ui import UI

from test_harness import FakeLLM  # reuse the scripted fake


# ------------------------------------------------------------ fixtures

def write_skill(base, name, description="does a thing. Use when testing.",
                body="# T\nDo the thing."):
    d = base / name
    d.mkdir(parents=True)
    (d / "SKILL.md").write_text(
        f"---\nname: {name}\ndescription: {description}\n---\n\n{body}\n")
    return d


@pytest.fixture
def env(tmp_path, monkeypatch):
    """Isolated HOME + project dir so discovery only sees what we create."""
    home = tmp_path / "home"
    proj = tmp_path / "proj"
    home.mkdir(), proj.mkdir()
    monkeypatch.setattr("pathlib.Path.home", staticmethod(lambda: home))
    cfg = Config(project_dir=proj, stream=False)
    cfg.family = "generic"
    return SimpleNamespace(home=home, proj=proj, cfg=cfg)


# -------------------------------------------------------------- skills

def test_frontmatter_parsing_variants():
    meta, body = parse_frontmatter(
        "---\nname: x\ndescription: |\n  multi\n  line\n---\nBody here")
    assert meta["name"] == "x"
    assert "multi" in meta["description"]
    assert body == "Body here"
    meta, body = parse_frontmatter("no frontmatter at all")
    assert meta == {} and body == "no frontmatter at all"


def test_skill_discovery_precedence_and_builtin(env):
    write_skill(env.proj / ".locode" / "skills", "deploy",
                description="project version")
    write_skill(env.home / ".claude" / "skills", "deploy",
                description="user version")          # loses to project
    write_skill(env.home / ".claude" / "skills", "review")

    skills = discover_skills(env.cfg)
    assert skills["deploy"].description == "project version"
    assert skills["deploy"].source == "project"
    assert skills["review"].source == "user"
    assert "skill-creator" in skills                 # builtin ships
    assert skills["skill-creator"].source == "builtin"


def test_skill_tool_loads_body_and_lists_bundled(env):
    d = write_skill(env.proj / ".locode" / "skills", "pdf-fu",
                    body="# PDF\nRun the script.")
    (d / "scripts").mkdir()
    (d / "scripts" / "go.py").write_text("print('x')\n")
    agent = SimpleNamespace(skills=discover_skills(env.cfg))
    out = run_skill(agent, {"name": "pdf-fu"})
    assert "Run the script." in out and "scripts/go.py" in out
    out = run_skill(agent, {"name": "nope"})
    assert "pdf-fu" in out and "Error" in out        # helpful listing


def test_system_prompt_carries_skill_metadata_only(env):
    write_skill(env.proj / ".locode" / "skills", "secret-sauce",
                description="cooks sauce. Use when saucing.",
                body="THE-FULL-RECIPE")
    agent = Agent(env.cfg, ui=UI(interactive=False, quiet=True))
    sp = agent.messages[0]["content"]
    assert "# Skills" in sp and "secret-sauce" in sp
    assert "cooks sauce" in sp
    assert "THE-FULL-RECIPE" not in sp               # progressive disclosure
    assert "skill" in agent.registry                 # tool registered


# ---------------------------------------------------------- commands

def test_custom_command_expansion(env):
    cdir = env.proj / ".claude" / "commands"          # Claude Code location
    cdir.mkdir(parents=True)
    (cdir / "review.md").write_text(
        "---\ndescription: review a file\n---\n"
        "Review $1 carefully.\nFull args: $ARGUMENTS")
    cmds = discover_commands(env.cfg)
    assert "review" in cmds and cmds["review"].description == "review a file"
    out = expand_command(cmds["review"], "src/app.py --strict")
    assert "Review src/app.py carefully." in out
    assert "Full args: src/app.py --strict" in out


def test_command_without_placeholders_appends_args(env):
    cdir = env.proj / ".locode" / "commands"
    cdir.mkdir(parents=True)
    (cdir / "fix.md").write_text("Fix the failing tests.")
    cmds = discover_commands(env.cfg)
    out = expand_command(cmds["fix"], "in auth module")
    assert out.endswith("ARGUMENTS: in auth module")


# ----------------------------------------------------------- plugins

def test_plugin_contributes_skills_and_commands(env):
    proot = env.home / ".config" / "locode" / "plugins" / "toolkit"
    (proot / ".claude-plugin").mkdir(parents=True)
    (proot / ".claude-plugin" / "plugin.json").write_text(
        json.dumps({"name": "toolkit", "description": "handy pack"}))
    write_skill(proot / "skills", "docs-writer")
    (proot / "commands").mkdir()
    (proot / "commands" / "ship.md").write_text("Ship it: $ARGUMENTS")

    plugins = discover_plugins(env.cfg)
    assert [p.name for p in plugins] == ["toolkit"]
    skills = discover_skills(env.cfg)
    assert skills["docs-writer"].source == "plugin:toolkit"
    cmds = discover_commands(env.cfg)
    assert cmds["ship"].source == "plugin:toolkit"


# ---------------------------------------------------------------- TUI

def make_app(env, turns):
    def factory(cfg, ui):
        agent = Agent(cfg, ui)
        agent.llm = FakeLLM(turns)
        return agent
    return LocodeApp(env.cfg, agent_factory=factory)


async def wait_until(pred, timeout=8.0):
    for _ in range(int(timeout / 0.05)):
        if pred():
            return True
        await asyncio.sleep(0.05)
    return False


async def test_tui_end_to_end_turn(env):
    args = {"path": "hello.py", "content": "print('tui')\n"}
    turns = [
        Turn(text="", tool_calls=[ToolCall(id="c1", name="write_file",
                                           arguments=args,
                                           raw_arguments=json.dumps(args))]),
        Turn(text="Done — created **hello.py**."),
    ]
    app = make_app(env, turns)
    async with app.run_test(size=(100, 30)) as pilot:
        prompt = app.query_one("#prompt")
        prompt.load_text("make hello.py")
        await pilot.press("enter")
        ok = await wait_until(lambda: not app.busy and
                              (env.proj / "hello.py").exists())
        assert ok, "turn did not complete"
        log = "\n".join(app.ui_adapter.transcript)
        assert "⏺ write_file" in log and "Done" in log
        assert (env.proj / "hello.py").read_text() == "print('tui')\n"
        assert app._ctx_pct >= 0


async def test_tui_approval_modal_deny(env):
    args = {"command": "sudo rm -r /tmp/x"}
    turns = [
        Turn(text="", tool_calls=[ToolCall(id="c1", name="bash",
                                           arguments=args,
                                           raw_arguments=json.dumps(args))]),
        Turn(text="Okay, skipping that."),
    ]
    app = make_app(env, turns)
    async with app.run_test(size=(100, 30)) as pilot:
        app.query_one("#prompt").load_text("clean tmp")
        await pilot.press("enter")
        from locode.tui import ApprovalScreen
        ok = await wait_until(
            lambda: isinstance(app.screen, ApprovalScreen))
        assert ok, "approval modal never appeared"
        await pilot.press("n")                        # deny via keybinding
        ok = await wait_until(lambda: not app.busy)
        assert ok
        log = "\n".join(app.ui_adapter.transcript)
        assert "[approval:bash] -> n" in log
        assert "Denied by user" in log


async def test_tui_slash_commands_and_custom(env):
    cdir = env.proj / ".locode" / "commands"
    cdir.mkdir(parents=True)
    (cdir / "greet.md").write_text("Say hello to $ARGUMENTS")
    turns = [Turn(text="Hello Zubin!")]
    app = make_app(env, turns)
    async with app.run_test(size=(100, 30)) as pilot:
        prompt = app.query_one("#prompt")
        prompt.load_text("/skills")
        await pilot.press("enter")
        log = "\n".join(app.ui_adapter.transcript)
        assert "skill-creator" in log
        prompt.load_text("/greet Zubin")
        await pilot.press("enter")
        ok = await wait_until(lambda: not app.busy and
                              "Hello Zubin!" in
                              "\n".join(app.ui_adapter.transcript))
        assert ok
        # the expanded prompt reached the model
        sent = app.agent.llm.requests[0]
        assert any("Say hello to Zubin" in m.get("content", "")
                   for m in sent if isinstance(m.get("content"), str))
