"""Tests for the datagen pipeline and the web tools."""
from __future__ import annotations

import http.server
import json
import random
import threading
from pathlib import Path
from types import SimpleNamespace

import pytest

from locode.config import Config
from locode.datagen import (TEMPLATES, generate, rollout, to_native,
                            to_prompted)
from locode.tools.web import html_to_text, run_fetch, run_search
from locode.ui import UI


@pytest.fixture
def env(tmp_path, monkeypatch):
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setattr("pathlib.Path.home", staticmethod(lambda: home))
    return SimpleNamespace(home=home, tmp=tmp_path)


def tpl(name):
    return next(t for t in TEMPLATES if t.name == name)


# ------------------------------------------------------------- datagen

def test_rollout_fix_template_verified(env):
    s = rollout(tpl("fix_failing_test"), random.Random(1))
    assert s is not None and s.ok
    roles = [m["role"] for m in s.messages]
    assert roles[0] == "system" and "tool" in roles
    tool_out = [m["content"] for m in s.messages if m["role"] == "tool"]
    assert any("passed" in t for t in tool_out)          # real pytest ran
    native = to_native(s)
    assert s.project_dir not in json.dumps(native)       # paths scrubbed
    assert any(t["function"]["name"] == "edit_file" for t in native["tools"])


def test_rollout_plan_and_denied_behaviors(env):
    s = rollout(tpl("plan_mode"), random.Random(2))
    assert s is not None
    assert "PLAN MODE" in s.messages[1]["content"]
    s2 = rollout(tpl("recover_from_denied"), random.Random(3))
    assert s2 is not None
    assert any(m["role"] == "tool" and m["content"].startswith("Denied")
               for m in s2.messages)


def test_prompted_export_selfheal_is_valid(env):
    s = rollout(tpl("create_and_run"), random.Random(4))
    assert s is not None
    rng = random.Random(0)
    row = to_prompted(s, rng, selfheal_p=1.0)   # force augmentation
    msgs = row["messages"]
    joined = "\n".join(m["content"] for m in msgs)
    assert "<tool_call>" in joined and "<tool_response" in joined
    # every non-final assistant block ends with a parseable tool_call
    fixed = [m for m in msgs if m["role"] == "assistant"
             and m["content"].rstrip().endswith("</tool_call>")]
    ok = 0
    for m in fixed:
        block = m["content"].rsplit("<tool_call>", 1)[1]
        payload = block.rsplit("</tool_call>", 1)[0].strip()
        try:
            json.loads(payload)
            ok += 1
        except json.JSONDecodeError:
            pass
    assert ok >= 1                                # corrected calls parse
    assert any("malformed" in m["content"]
               for m in msgs if m["role"] == "user")


def test_generate_small_batch(env, tmp_path):
    out = tmp_path / "data"
    stats = generate(out, count=8, seed=5, log=lambda *a: None)
    assert stats["total"] == 8
    lines = (out / "train_native.jsonl").read_text().strip().splitlines()
    assert len(lines) == stats["train"]
    row = json.loads(lines[0])
    assert row["messages"][0]["role"] == "system"
    assert (out / "train_prompted.jsonl").exists()
    assert (out / "stats.json").exists()


# ----------------------------------------------------------------- web

def test_html_to_text_strips_scripts():
    html = ("<html><head><script>evil()</script></head>"
            "<body><h1>Title</h1><p>Hello <b>world</b></p></body></html>")
    out = html_to_text(html)
    assert "Title" in out and "Hello" in out and "evil" not in out


def test_web_fetch_local_server(env, tmp_path):
    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            body = b"<html><body><p>locode fetch works</p></body></html>"
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a):
            pass

    srv = http.server.HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        port = srv.server_address[1]
        cfg = Config(project_dir=tmp_path, approval="full-access")
        agent = SimpleNamespace(cfg=cfg)
        out = run_fetch(agent, {"url": f"http://127.0.0.1:{port}/x"})
        assert "locode fetch works" in out and "untrusted" in out
        out = run_fetch(agent, {"url": "ftp://nope"})
        assert out.startswith("Error")
    finally:
        srv.shutdown()


def test_web_search_needs_provider_and_registers_conditionally(env, tmp_path):
    cfg = Config(project_dir=tmp_path)
    agent = SimpleNamespace(cfg=cfg)
    out = run_search(agent, {"query": "anything"})
    assert "no search provider configured" in out
    from locode.tools import build_registry
    reg = build_registry(cfg)
    assert "web_fetch" in reg and "web_search" not in reg
    cfg.search = {"provider": "tavily", "api_key": "x"}
    reg = build_registry(cfg)
    assert "web_search" in reg


# ------------------------------------------------- anthropic teacher

def test_anthropic_teacher_end_to_end(tmp_path):
    """A fake Anthropic-format server drives a real rollout: the teacher
    returns tool_use, locode executes it, results go back as tool_result
    blocks, and the trajectory verifies."""
    import http.server
    import threading
    from locode.anthropic_compat import AnthropicTeacher

    captured = {}

    class H(http.server.BaseHTTPRequestHandler):
        def do_POST(self):
            body = json.loads(self.rfile.read(
                int(self.headers["Content-Length"])))
            captured.setdefault("bodies", []).append(body)
            has_result = any(
                isinstance(m.get("content"), list) and
                any(b.get("type") == "tool_result" for b in m["content"])
                for m in body["messages"])
            if not has_result:
                # ask to write the file the create_and_run task wants
                word = "hello"
                for m in body["messages"]:
                    if m["role"] == "user" and isinstance(m["content"], str):
                        import re as _re
                        mm = _re.search(r"prints? (?:exactly )?([\w-]+)",
                                        m["content"])
                        if mm:
                            word = mm.group(1)
                fname = "gen.py"
                out = {"content": [
                    {"type": "thinking", "thinking": "write then run"},
                    {"type": "tool_use", "id": "tu_1", "name": "write_file",
                     "input": {"path": fname,
                               "content": f'print("{word}")\n'}}],
                    "stop_reason": "tool_use"}
            else:
                out = {"content": [{"type": "text",
                                    "text": "Created and verified."}],
                       "stop_reason": "end_turn"}
            data = json.dumps(out).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, *a):
            pass

    srv = http.server.HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        port = srv.server_address[1]
        teacher = AnthropicTeacher(f"http://127.0.0.1:{port}", "glm-5.2",
                                   api_key="trial-key")
        from locode.datagen import TEMPLATES
        create = next(t for t in TEMPLATES if t.name == "create_and_run")
        s = rollout(create, random.Random(9), teacher)
        assert s is not None, "teacher-driven rollout failed verification"
        # request shape: system lifted, tools converted, results batched
        first = captured["bodies"][0]
        assert first.get("system"), "system prompt should be lifted"
        assert any(t["name"] == "write_file" and "input_schema" in t
                   for t in first["tools"])
        second = captured["bodies"][1]
        result_msgs = [m for m in second["messages"]
                       if isinstance(m.get("content"), list) and
                       m["content"][0].get("type") == "tool_result"]
        assert result_msgs and result_msgs[0]["role"] == "user"
    finally:
        srv.shutdown()
