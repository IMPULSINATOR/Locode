"""Regression tests for the first real-laptop-run bug report:

1. bash timeouts now surface partial output instead of going silent
2. the model is told the correct Windows venv path layout
3. stray terminal mouse/CSI escape fragments get scrubbed from the prompt
4. the prompt is multi-line: Enter submits, Ctrl+J inserts a newline
5. `--continue` replays the resumed conversation into the visible chat
   log and seeds arrow-key recall history, not just silent agent state
"""
from __future__ import annotations

import json
import sys
from types import SimpleNamespace

import pytest

from locode.agent import Agent
from locode.config import Config
from locode.hooks import merge_hooks, run_hooks
from locode.llm import ToolCall, Turn
from locode.replcmds import handle
from locode.tui import LocodeApp, PromptArea, _strip_leaked_escapes
from locode.ui import UI

from test_batch_a import RecordingUI

from test_harness import FakeLLM


@pytest.fixture
def env(tmp_path, monkeypatch):
    home = tmp_path / "home"
    proj = tmp_path / "proj"
    home.mkdir(), proj.mkdir()
    monkeypatch.setattr("pathlib.Path.home", staticmethod(lambda: home))
    cfg = Config(project_dir=proj, stream=False)
    cfg.family = "generic"
    return SimpleNamespace(home=home, proj=proj, cfg=cfg)


def quiet_ui():
    return UI(interactive=False, quiet=True)


async def wait_until(pred, timeout=8.0):
    import asyncio
    for _ in range(int(timeout / 0.05)):
        if pred():
            return True
        await asyncio.sleep(0.05)
    return False


# --------------------------------------------------------------- bash

def test_bash_timeout_surfaces_partial_output(env):
    from locode.tools.shell import run_bash
    agent = SimpleNamespace(cfg=env.cfg)
    out = run_bash(agent, {
        "command": "echo partial-output; sleep 5",
        "timeout": 1,
    })
    assert out.startswith("Error: command timed out after 1s")
    assert "partial-output" in out
    assert "higher \"timeout\" argument" in out


def test_bash_default_timeout_raised(env):
    assert env.cfg.command_timeout == 180


def test_windows_note_mentions_venv_scripts_layout():
    from locode.tools.shell import _WINDOWS_NOTES
    for note in _WINDOWS_NOTES.values():
        assert "Scripts" in note
        assert "bin/python" in note or "bin/pip" in note  # named as wrong


# ---------------------------------------------------- escape sanitization

@pytest.mark.parametrize("leaked,clean", [
    ("[<65;74;31M", ""),
    ("hello[<0;10;20mworld", "helloworld"),
    ("\x1b[<35;80;24Mtest", "test"),
    ("perfectly normal text", "perfectly normal text"),
    ("path/to/file.py", "path/to/file.py"),   # must NOT eat normal slashes
])
def test_strip_leaked_escapes(leaked, clean):
    assert _strip_leaked_escapes(leaked) == clean


async def test_prompt_area_self_heals_leaked_escape(env):
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="done")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        prompt = app.query_one("#prompt", PromptArea)
        prompt.focus()
        prompt.load_text("deploy [<65;74;31M the app")
        await pilot.pause()
        await pilot.pause()
        assert "[<65;74;31M" not in prompt.text
        assert "deploy" in prompt.text and "the app" in prompt.text


# ------------------------------------------------------------ multiline

async def test_multiline_prompt_ctrl_j_and_submit(env):
    captured = {}

    def factory(cfg, ui):
        a = Agent(cfg, ui)

        class Spy(FakeLLM):
            def chat(self, messages, tools_schema, on_text=None,
                     on_thinking=None):
                captured["last_user"] = messages[-1]["content"]
                return super().chat(messages, tools_schema, on_text,
                                    on_thinking)
        a.llm = Spy([Turn(text="got it")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        prompt = app.query_one("#prompt", PromptArea)
        prompt.focus()
        for ch in "line one":
            await pilot.press(ch if ch != " " else "space")
        await pilot.press("ctrl+j")
        for ch in "line two":
            await pilot.press(ch if ch != " " else "space")
        assert "\n" in prompt.text
        assert prompt.text == "line one\nline two"
        await pilot.press("enter")
        ok = await wait_until(lambda: not app.busy)
        assert ok
        assert captured["last_user"] == "line one\nline two"
        assert prompt.text == ""   # cleared after submit


async def test_up_down_history_only_recalls_on_single_line(env):
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="ok"), Turn(text="ok2")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        prompt = app.query_one("#prompt", PromptArea)
        prompt.focus()
        prompt.load_text("first message")
        await pilot.press("enter")
        await wait_until(lambda: not app.busy)
        prompt.load_text("second message")
        await pilot.press("enter")
        await wait_until(lambda: not app.busy)
        # single-line + empty -> up recalls history
        await pilot.press("up")
        assert prompt.text == "second message"
        await pilot.press("up")
        assert prompt.text == "first message"
        # multi-line buffer -> up must NOT clobber it with history
        prompt.load_text("draft\nmore text")
        prompt.move_cursor((0, 0))
        await pilot.press("up")
        assert prompt.text == "draft\nmore text"


# ----------------------------------------------------- session replay

async def test_continue_replays_chat_and_seeds_recall_history(env):
    args = {"path": "x.txt", "content": "hi"}
    agent = Agent(env.cfg, ui=quiet_ui())
    agent.llm = FakeLLM([
        Turn(text="", tool_calls=[ToolCall(
            id="c1", name="write_file", arguments=args,
            raw_arguments=json.dumps(args))]),
        Turn(text="Created x.txt for you."),
    ])
    agent.run_turn("please create x.txt")

    env.cfg.continue_session = True

    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="unused")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 34)) as pilot:
        await pilot.pause()
        # the resumed turn is visibly rendered, not just silently restored
        found = any("please create x.txt" in str(w.render())
                   for w in app.query("#chat Static"))
        assert found, "resumed conversation was not replayed into the chat"
        prompt = app.query_one("#prompt", PromptArea)
        assert "please create x.txt" in prompt.recall_history


# ---------------------------------------------------- environment detect

def test_python_venv_detected_and_put_on_path(env):
    from locode.envdetect import build_env
    venv = env.proj / ".venv"
    bindir = venv / ("Scripts" if __import__("os").name == "nt" else "bin")
    bindir.mkdir(parents=True)
    (venv / "pyvenv.cfg").write_text("home = /usr\n")
    extra, notes = build_env(env.proj)
    assert extra["VIRTUAL_ENV"] == str(venv)
    assert str(bindir) in extra["PATH"].split(
        ";" if __import__("os").name == "nt" else ":")
    assert any(".venv" in n for n in notes)


def test_plain_folder_named_venv_without_pyvenv_cfg_is_ignored(env):
    from locode.envdetect import build_env
    (env.proj / "venv").mkdir()   # no pyvenv.cfg -> not a real venv
    extra, notes = build_env(env.proj)
    assert "VIRTUAL_ENV" not in extra and not notes


def test_node_local_bin_detected(env):
    from locode.envdetect import build_env
    nb = env.proj / "node_modules" / ".bin"
    nb.mkdir(parents=True)
    extra, notes = build_env(env.proj)
    assert str(nb) in extra["PATH"].split(
        ";" if __import__("os").name == "nt" else ":")
    assert any("node_modules" in n for n in notes)


def test_agent_system_prompt_mentions_detected_env(env):
    (env.proj / ".venv" / ("Scripts" if __import__("os").name == "nt"
                           else "bin")).mkdir(parents=True)
    (env.proj / ".venv" / "pyvenv.cfg").write_text("home=/usr\n")
    agent = Agent(env.cfg, ui=quiet_ui())
    assert "Detected project environment" in agent.messages[0]["content"]
    assert "virtualenv" in agent.messages[0]["content"]


def test_bash_actually_uses_detected_venv_path(env):
    """End-to-end: a fake venv with a marker script on its bin dir must
    be reachable by bare name from a bash call, no path guessing."""
    import os as _os
    from locode.tools.shell import run_bash
    venv = env.proj / ".venv"
    bindir = venv / ("Scripts" if _os.name == "nt" else "bin")
    bindir.mkdir(parents=True)
    (venv / "pyvenv.cfg").write_text("home=/usr\n")
    if _os.name == "nt":
        (bindir / "marker.cmd").write_text("@echo FOUND_IT\n")
        cmd = "marker"
    else:
        script = bindir / "marker"
        script.write_text("#!/bin/sh\necho FOUND_IT\n")
        script.chmod(0o755)
        cmd = "marker"
    agent = Agent(env.cfg, ui=quiet_ui())
    out = run_bash(agent, {"command": cmd})
    assert "FOUND_IT" in out


# --------------------------------------------------------- resume picker

def _make_session(cfg, project_dir, ui, prompt, goal=""):
    """Create one genuinely distinct saved session (its own session_id)."""
    a = Agent(cfg, ui=ui)
    a.llm = FakeLLM([Turn(text=f"ok: {prompt}")])
    if goal:
        a.goal = goal
    a.run_turn(prompt)
    return a.session_id


def test_list_sessions_shows_distinct_conversations_not_per_turn_dupes(env):
    from locode import sessions
    id1 = _make_session(env.cfg, env.proj, quiet_ui(), "build the api")
    id2 = _make_session(env.cfg, env.proj, quiet_ui(), "fix the login bug")
    assert id1 != id2   # each is its own conversation

    # growing the SAME conversation across more turns must not create
    # additional list entries — this was the original bug
    a = Agent(env.cfg, ui=quiet_ui())
    a.llm = FakeLLM([Turn(text="t1"), Turn(text="t2"), Turn(text="t3")])
    a.run_turn("turn one")
    a.run_turn("turn two")
    a.run_turn("turn three")

    found = sessions.list_sessions(env.cfg)
    ids = [s["session_id"] for s in found]
    assert ids.count(a.session_id) == 1
    assert id1 in ids and id2 in ids
    assert len(found) == 3
    summaries = {s["session_id"]: s["summary"] for s in found}
    assert "build the api" in summaries[id1]
    assert "fix the login bug" in summaries[id2]


def test_restore_session_by_id_and_resume_keeps_same_id(env):
    from locode import sessions
    id1 = _make_session(env.cfg, env.proj, quiet_ui(), "task alpha")
    _make_session(env.cfg, env.proj, quiet_ui(), "task beta")

    fresh = Agent(env.cfg, ui=quiet_ui())
    data = sessions.restore_session(fresh, quiet_ui(), id1)
    assert data is not None
    assert fresh.session_id == id1   # continuing writes to the SAME file
    assert any("task alpha" in str(m.get("content", ""))
              for m in fresh.messages)

    fresh.llm = FakeLLM([Turn(text="continued")])
    fresh.run_turn("more work")
    found = {s["session_id"]: s for s in sessions.list_sessions(env.cfg)}
    assert found[id1]["n_messages"] >= 4   # same session grew, no new file


async def test_tui_resume_picker_shows_and_selects(env):
    from locode import sessions
    id1 = _make_session(env.cfg, env.proj, quiet_ui(), "alpha task")
    id2 = _make_session(env.cfg, env.proj, quiet_ui(), "beta task")
    env.cfg.continue_session = True

    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="unused")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 34)) as pilot:
        await pilot.pause()
        from locode.tui import SessionPickerScreen
        assert isinstance(app.screen, SessionPickerScreen)
        assert len(app.screen.sessions) == 2
        await pilot.press("enter")   # pick the first (most recent) entry
        ok = await wait_until(lambda: not isinstance(app.screen,
                                                      SessionPickerScreen))
        assert ok
        assert app.agent.session_id in (id1, id2)
        found = any("alpha task" in str(w.render()) or
                   "beta task" in str(w.render())
                   for w in app.query("#chat Static"))
        assert found


async def test_tui_resume_picker_escape_keeps_current_conversation(env):
    _make_session(env.cfg, env.proj, quiet_ui(), "alpha task")
    _make_session(env.cfg, env.proj, quiet_ui(), "beta task")
    env.cfg.continue_session = True

    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="unused")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 34)) as pilot:
        await pilot.pause()
        from locode.tui import SessionPickerScreen
        assert isinstance(app.screen, SessionPickerScreen)
        await pilot.press("escape")
        ok = await wait_until(lambda: not isinstance(app.screen,
                                                      SessionPickerScreen))
        assert ok
        assert app.agent.session_id is None   # never picked one


def test_single_session_skips_the_picker_entirely(env):
    """No point asking when there's nothing to choose between."""
    from locode import sessions
    id1 = _make_session(env.cfg, env.proj, quiet_ui(), "only task")
    found = sessions.list_sessions(env.cfg)
    assert len(found) == 1
    # --continue with exactly one session restores directly, no prompt
    from locode.cli import _pick_session
    fresh = Agent(env.cfg, ui=quiet_ui())
    _pick_session(env.cfg, fresh, quiet_ui())
    assert fresh.session_id == id1


# --------------------------------------------------- subagent write access

def test_custom_subagent_with_write_tools_can_actually_write(env):
    """Confirms, end-to-end (no mocks), that a custom subagent explicitly
    whitelisting write tools really gets them and can use them — the
    read-only default is a default, not a hard limit."""
    d = env.proj / ".claude" / "agents"
    d.mkdir(parents=True)
    (d / "implementer.md").write_text(
        "---\nname: implementer\n"
        "description: implements small, well-specified changes\n"
        "tools: read_file, write_file, edit_file, bash\n---\n"
        "You implement exactly what you're asked, nothing more.")

    from locode.agents import discover_agents
    agent_def = discover_agents(env.cfg)["implementer"]
    sub = Agent(env.cfg, ui=quiet_ui(), depth=1, subagent=True,
               agent_def=agent_def)
    assert {"read_file", "write_file", "edit_file", "bash"} <= \
        set(sub.registry)
    assert "task" not in sub.registry          # never recursion, even here

    wargs = {"path": "made_by_subagent.txt", "content": "hello\n"}
    sub.llm = FakeLLM([
        Turn(text="", tool_calls=[ToolCall(
            id="c1", name="write_file", arguments=wargs,
            raw_arguments=json.dumps(wargs))]),
        Turn(text="Created it."),
    ])
    sub.run_turn("create made_by_subagent.txt")
    assert (env.proj / "made_by_subagent.txt").read_text() == "hello\n"


def test_default_researcher_subagent_has_no_write_tools(env):
    """The unnamed default subagent (no custom def) stays read-only —
    this is the actual default the task tool falls back to."""
    sub = Agent(env.cfg, ui=quiet_ui(), depth=1, subagent=True)
    for tool in ("write_file", "edit_file", "bash", "task"):
        assert tool not in sub.registry
    assert {"read_file", "glob", "grep"} <= set(sub.registry)


# ------------------------------------------------------- native copy/ctrl+c

async def test_ctrl_c_copies_selection_instead_of_quitting(env):
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="The answer is 42.")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        app.query_one("#prompt", PromptArea).focus()
        app.query_one("#prompt", PromptArea).load_text("what is it")
        await pilot.press("enter")
        await wait_until(lambda: not app.busy)

        target = next(w for w in app.query("#chat Markdown"))
        target.text_select_all()
        await pilot.pause()
        assert app.screen.get_selected_text()

        copied = {}
        app.copy_to_clipboard = lambda text: copied.setdefault("text", text)
        await pilot.press("ctrl+c")
        await pilot.pause()

        assert "text" in copied and "42" in copied["text"]
        assert app.is_running   # did NOT quit


async def test_ctrl_c_with_no_selection_still_quits(env):
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="ok")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        app.query_one("#prompt", PromptArea).focus()
        await pilot.press("ctrl+c")   # nothing selected, not busy -> quit
        await pilot.pause()
        assert app.return_code is not None or not app.is_running


# --------------------------------------------------- configurable limits

def test_new_default_limits(env):
    assert env.cfg.max_steps == 60
    assert env.cfg.subagent_max_steps == 45
    assert env.cfg.goal_rounds == 25


def test_subagent_max_steps_is_configurable_and_used(env, monkeypatch):
    env.cfg.subagent_max_steps = 3
    steps_seen = []

    class CountingLLM(FakeLLM):
        def chat(self, messages, tools_schema, on_text=None,
                 on_thinking=None):
            steps_seen.append(1)
            return Turn(text="", tool_calls=[ToolCall(
                id=f"c{len(steps_seen)}", name="read_file",
                arguments={"path": "x.txt"}, raw_arguments="{}")])

    (env.proj / "x.txt").write_text("hi\n")
    from locode.tools.task import run_task
    parent = Agent(env.cfg, ui=quiet_ui())

    real_init = Agent.__init__

    def fake_agent_init(self, cfg, ui, depth=0, subagent=False,
                        agent_def=None):
        real_init(self, cfg, ui, depth=depth, subagent=subagent,
                  agent_def=agent_def)
        self.llm = CountingLLM([])

    monkeypatch.setattr(Agent, "__init__", fake_agent_init)
    run_task(parent, {"prompt": "read x.txt forever"})
    assert len(steps_seen) == env.cfg.subagent_max_steps


def test_goal_rounds_configurable_up_to_100(env):
    env.cfg.goal_rounds = 100
    agent = Agent(env.cfg, ui=quiet_ui())
    assert agent.cfg.goal_rounds == 100


def test_cli_flags_for_new_limits():
    from locode.cli import _build_parser
    p = _build_parser()
    ns = p.parse_args(["--subagent-max-steps", "50", "--goal-rounds", "100"])
    assert ns.subagent_max_steps == 50
    assert ns.goal_rounds == 100


# ------------------------------------------------------- @mention popup

def test_complete_mention_path_basics(env):
    from locode.tools.files import complete_mention_path
    (env.proj / "src").mkdir()
    (env.proj / "src" / "main.py").write_text("x")
    (env.proj / "README.md").write_text("x")
    (env.proj / ".git").mkdir()

    top = complete_mention_path(env.proj, "")
    names = [n for n, _ in top]
    assert "src/" in names and "README.md" in names
    assert not any(n.startswith(".git") for n in names)

    inside = complete_mention_path(env.proj, "src/")
    assert inside == [("src/main.py", False)]

    filtered = complete_mention_path(env.proj, "src/ma")
    assert filtered == [("src/main.py", False)]

    assert complete_mention_path(env.proj, "../outside") == []


async def test_tui_at_mention_shows_popup_and_completes_file(env):
    (env.proj / "app.py").write_text("x")
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="looked")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        prompt = app.query_one("#prompt", PromptArea)
        prompt.focus()
        prompt.load_text("check @app")
        prompt.cursor_location = (0, len("check @app"))
        await pilot.pause()
        assert app.suggestions_open
        assert app._sugg_kind == "at"
        names = [n for n, _ in app._sugg_items]
        assert "app.py" in names

        await pilot.press("tab")
        await pilot.pause()
        assert prompt.text == "check @app.py "
        assert not app.suggestions_open   # file completion closes the popup


async def test_tui_at_mention_directory_keeps_popup_open_for_drilling(env):
    (env.proj / "src").mkdir()
    (env.proj / "src" / "main.py").write_text("x")
    (env.proj / "src" / "utils.py").write_text("x")
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="ok")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        prompt = app.query_one("#prompt", PromptArea)
        prompt.focus()
        prompt.load_text("look at @src")
        prompt.cursor_location = (0, len("look at @src"))
        await pilot.pause()
        assert app._sugg_items == [("src/", "dir")]

        await pilot.press("tab")
        await pilot.pause()
        assert prompt.text == "look at @src/"
        assert app.suggestions_open        # stayed open — drilling in
        assert app._sugg_kind == "at"
        names = sorted(n for n, _ in app._sugg_items)
        assert names == ["src/main.py", "src/utils.py"]

        await pilot.press("enter")         # enter also completes, not submit
        await pilot.pause()
        assert not app.busy                # never submitted the message
        assert prompt.text in ("look at @src/main.py ",
                               "look at @src/utils.py ")


async def test_at_mention_does_not_trigger_mid_word_without_boundary(env):
    """"user@host" style text must not spuriously pop suggestions."""
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="ok")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        prompt = app.query_one("#prompt", PromptArea)
        prompt.focus()
        prompt.load_text("ping user@host.com")
        prompt.cursor_location = (0, len("ping user@host.com"))
        await pilot.pause()
        assert not app.suggestions_open


async def test_at_mention_expansion_still_works_end_to_end(env):
    """Full loop: pick a file via the popup, submit, agent sees its
    contents inlined (the existing @mention expansion in Agent.run_turn)."""
    (env.proj / "notes.txt").write_text("PROJECT-SECRET-99\n")
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="read it")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        prompt = app.query_one("#prompt", PromptArea)
        prompt.focus()
        prompt.load_text("summarize @notes")
        prompt.cursor_location = (0, len("summarize @notes"))
        await pilot.pause()
        await pilot.press("tab")
        await pilot.pause()
        assert prompt.text == "summarize @notes.txt "
        await pilot.press("enter")
        ok = await wait_until(lambda: not app.busy)
        assert ok
        user_msg = app.agent.messages[1]["content"]
        assert "PROJECT-SECRET-99" in user_msg


# ---------------------------------------------------------- marketplace

def _make_fake_marketplace(root, name="acme-tools", plugin_source_ok=True):
    """A minimal but schema-accurate marketplace repo on disk."""
    (root / ".claude-plugin").mkdir(parents=True)
    manifest = {
        "$schema": "https://json.schemastore.org/claude-code-marketplace.json",
        "name": name,
        "version": "1.0.0",
        "description": "A test marketplace",
        "owner": {"name": "Acme Corp", "email": "dev@acme.test"},
        "plugins": [
            {"name": "reviewer", "description": "Code review helpers",
             "source": "./plugins/reviewer", "category": "development"},
            {"name": "ghost", "description": "Points nowhere real",
             "source": "./plugins/does-not-exist"},
        ],
    }
    (root / ".claude-plugin" / "marketplace.json").write_text(json.dumps(manifest))
    if plugin_source_ok:
        pdir = root / "plugins" / "reviewer"
        (pdir / "skills" / "reviewer-skill").mkdir(parents=True)
        (pdir / "skills" / "reviewer-skill" / "SKILL.md").write_text(
            "---\nname: reviewer-skill\ndescription: reviews code\n---\nGo.")
        (pdir / ".claude-plugin").mkdir(parents=True, exist_ok=True)
        (pdir / ".claude-plugin" / "plugin.json").write_text(
            json.dumps({"name": "reviewer", "description": "Code review"}))
    return root


def test_add_marketplace_from_local_path_and_list(env, tmp_path):
    from locode import plugins as P
    src = _make_fake_marketplace(tmp_path / "acme-src")
    msg = P.add_marketplace(str(src))
    assert msg.startswith("added marketplace 'acme-tools'")
    assert "2 plugin(s)" in msg

    found = P.list_marketplaces()
    assert len(found) == 1
    assert found[0].name == "acme-tools"
    assert found[0].owner == "Acme Corp"
    assert {e.name for e in found[0].entries} == {"reviewer", "ghost"}


def test_search_marketplace_plugins(env, tmp_path):
    from locode import plugins as P
    P.add_marketplace(str(_make_fake_marketplace(tmp_path / "acme-src")))
    all_results = P.search_marketplace_plugins("")
    assert len(all_results) == 2
    filtered = P.search_marketplace_plugins("review")
    assert len(filtered) == 1 and filtered[0][1].name == "reviewer"
    none = P.search_marketplace_plugins("nonexistent-xyz")
    assert none == []


def test_install_plugin_from_marketplace_by_name(env, tmp_path):
    from locode import plugins as P
    P.add_marketplace(str(_make_fake_marketplace(tmp_path / "acme-src")))
    msg = P.install_from_marketplace("reviewer@acme-tools", env.cfg)
    assert "installed plugin 'reviewer'" in msg

    installed = P.discover_plugins(env.cfg)
    assert any(p.name == "reviewer" for p in installed)
    skills = discover_skills_via(env.cfg)
    assert "reviewer-skill" in skills


def discover_skills_via(cfg):
    from locode.skills import discover_skills
    return discover_skills(cfg)


def test_install_by_bare_name_without_marketplace_suffix(env, tmp_path):
    from locode import plugins as P
    P.add_marketplace(str(_make_fake_marketplace(tmp_path / "acme-src")))
    msg = P.install_from_marketplace("reviewer", env.cfg)  # no @marketplace
    assert "installed plugin 'reviewer'" in msg


def test_install_stale_marketplace_entry_gives_clear_error(env, tmp_path):
    from locode import plugins as P
    P.add_marketplace(str(_make_fake_marketplace(tmp_path / "acme-src")))
    msg = P.install_from_marketplace("ghost@acme-tools", env.cfg)
    assert msg.startswith("error") and "stale" in msg


def test_install_unknown_plugin_lists_available(env, tmp_path):
    from locode import plugins as P
    P.add_marketplace(str(_make_fake_marketplace(tmp_path / "acme-src")))
    msg = P.install_from_marketplace("nope@acme-tools", env.cfg)
    assert "no plugin named 'nope'" in msg
    assert "reviewer" in msg


def test_remove_marketplace(env, tmp_path):
    from locode import plugins as P
    P.add_marketplace(str(_make_fake_marketplace(tmp_path / "acme-src")))
    assert len(P.list_marketplaces()) == 1
    msg = P.remove_marketplace("acme-tools")
    assert msg.startswith("removed")
    assert P.list_marketplaces() == []
    assert P.remove_marketplace("acme-tools").startswith("error")


def test_cli_plugin_install_dispatches_to_marketplace_for_bare_names(
        env, tmp_path, monkeypatch):
    """`locode plugin install reviewer@acme-tools` must route through the
    marketplace resolver, not the direct path/git installer."""
    from locode import plugins as P
    from locode.cli import _plugin_cli
    monkeypatch.setattr("pathlib.Path.home", staticmethod(lambda: env.home))
    P.add_marketplace(str(_make_fake_marketplace(tmp_path / "acme-src")))
    monkeypatch.chdir(env.proj)
    rc = _plugin_cli(["install", "reviewer@acme-tools"])
    assert rc == 0
    assert any(p.name == "reviewer" for p in P.discover_plugins(env.cfg))


# ----------------------------------------------- plugins bring agents+hooks

def _plugin_dir(env, name="toolkit"):
    d = env.home / ".config" / "locode" / "plugins" / name
    d.mkdir(parents=True)
    (d / ".claude-plugin").mkdir()
    (d / ".claude-plugin" / "plugin.json").write_text(
        json.dumps({"name": name, "description": "test plugin"}))
    return d


def test_plugin_contributes_a_custom_subagent(env):
    """Was already wired (agent_search_dirs includes plugin dirs) but had
    no direct regression test — locking it in."""
    d = _plugin_dir(env)
    (d / "agents").mkdir()
    (d / "agents" / "reviewer.md").write_text(
        "---\nname: reviewer\ndescription: reviews code for bugs\n"
        "tools: read_file, grep\n---\nBe thorough.")
    from locode.agents import discover_agents
    found = discover_agents(env.cfg)
    assert "reviewer" in found
    assert found["reviewer"].source == "plugin:toolkit"
    assert found["reviewer"].tools == ["read_file", "grep"]


def test_plugin_hooks_json_standalone_file_blocks_matched_tool(env):
    d = _plugin_dir(env)
    guard = d / "hooks" / "guard.sh"
    guard.parent.mkdir()
    guard.write_text(
        f"#!/bin/sh\n{sys.executable} -c \""
        "import sys, json; d = json.load(sys.stdin); "
        "sys.exit(2 if d.get('tool') == 'write_file' else 0)\"\n")
    guard.chmod(0o755)
    (d / "hooks" / "hooks.json").write_text(json.dumps({
        "hooks": {
            "PreToolUse": [{
                "matcher": "write_file",
                "hooks": [{"type": "command",
                          "command": "${CLAUDE_PLUGIN_ROOT}/hooks/guard.sh"}],
            }],
        }
    }))

    effective = merge_hooks(env.cfg)
    assert "pre-tool-use" in effective and effective["pre-tool-use"]
    matcher, cmd = effective["pre-tool-use"][0]
    assert matcher == "write_file"
    assert str(d.resolve()) in cmd    # ${CLAUDE_PLUGIN_ROOT} substituted
    assert "${CLAUDE_PLUGIN_ROOT}" not in cmd

    blocked, _ = run_hooks(effective, "pre-tool-use",
                           {"tool": "write_file", "arguments": {}})
    assert blocked
    blocked, _ = run_hooks(effective, "pre-tool-use",
                           {"tool": "read_file", "arguments": {}})
    assert not blocked   # matcher correctly excludes non-matching tools


def test_plugin_hooks_inline_in_plugin_json(env):
    """hooks/hooks.json wraps in a "hooks" key; inline plugin.json hooks
    does NOT re-wrap — both forms must parse to the same result."""
    d = _plugin_dir(env, "inline-toolkit")
    (d / ".claude-plugin" / "plugin.json").write_text(json.dumps({
        "name": "inline-toolkit",
        "hooks": {
            "PostToolUse": [{
                "matcher": "Write|Edit",
                "hooks": [{"type": "command", "command": "echo done"}],
            }],
            "SessionStart": [{  # unmapped event — must be dropped silently
                "hooks": [{"type": "command", "command": "echo hi"}],
            }],
        },
    }))
    effective = merge_hooks(env.cfg)
    assert effective["post-tool-use"] == [("Write|Edit", "echo done")]
    assert "session-start" not in effective   # no such locode event


def test_plugin_hook_prompt_type_is_skipped_not_crashed(env):
    d = _plugin_dir(env)
    (d / "hooks").mkdir()
    (d / "hooks" / "hooks.json").write_text(json.dumps({
        "hooks": {"Stop": [{"hooks": [
            {"type": "prompt", "prompt": "Check everything is done."}]}]}
    }))
    effective = merge_hooks(env.cfg)   # must not raise
    assert effective["stop"] == []     # prompt-type hooks aren't supported


def test_toml_and_plugin_hooks_both_run_for_the_same_event(env):
    d = _plugin_dir(env)
    (d / "hooks").mkdir()
    marker_plugin = env.proj / "plugin_ran.txt"
    marker_toml = env.proj / "toml_ran.txt"
    (d / "hooks" / "hooks.json").write_text(json.dumps({
        "hooks": {"PostToolUse": [{"hooks": [
            {"type": "command",
             "command": f"echo x > {marker_plugin}"}]}]}}))
    env.cfg.hooks = {"post-tool-use": [f"echo x > {marker_toml}"]}

    effective = merge_hooks(env.cfg)
    run_hooks(effective, "post-tool-use", {"tool": "write_file"})
    assert marker_plugin.is_file() and marker_toml.is_file()


def test_agent_actually_uses_merged_hooks_end_to_end(env):
    """Full loop through the real Agent, not just the hooks module."""
    d = _plugin_dir(env)
    (d / "hooks").mkdir()
    (d / "hooks" / "hooks.json").write_text(json.dumps({
        "hooks": {"PreToolUse": [{
            "matcher": "bash",
            "hooks": [{"type": "command",
                      "command": f"{sys.executable} -c \"import sys; "
                                "sys.exit(2)\""}]}]}}))
    turns = [
        Turn(text="", tool_calls=[ToolCall(
            id="c1", name="bash", arguments={"command": "echo hi"},
            raw_arguments="{}")]),
        Turn(text="blocked, noted"),
    ]
    agent = Agent(env.cfg, ui=quiet_ui())
    agent.llm = FakeLLM(turns)
    agent.run_turn("run echo hi")
    tool_msg = next(m for m in agent.messages if m["role"] == "tool")
    assert "Blocked by a user-configured hook" in tool_msg["content"]


# ------------------------------------------------------ skills in "/" menu

def _write_skill(base, name, description="does a thing", body="Do the thing."):
    d = base / name
    d.mkdir(parents=True)
    (d / "SKILL.md").write_text(
        f"---\nname: {name}\ndescription: {description}\n---\n\n{body}\n")


def test_skill_invocation_loads_body_directly(env):
    _write_skill(env.proj / ".locode" / "skills", "review",
                description="reviews code", body="Check for bugs carefully.")
    agent = Agent(env.cfg, ui=quiet_ui())
    ui = RecordingUI()
    action, payload = handle("/review src/app.py", agent, ui)
    assert action == "prompt"
    assert "Check for bugs carefully." in payload
    assert "src/app.py" in payload
    assert "review" in payload


def test_skill_invocation_without_args(env):
    _write_skill(env.proj / ".locode" / "skills", "checklist",
                body="Run the standard checklist.")
    agent = Agent(env.cfg, ui=quiet_ui())
    action, payload = handle("/checklist", agent, RecordingUI())
    assert action == "prompt"
    assert "Run the standard checklist." in payload
    assert "Apply the above to" not in payload   # no args, no trailer


def test_unknown_skill_or_command_still_errors(env):
    agent = Agent(env.cfg, ui=quiet_ui())
    ui = RecordingUI()
    action, _ = handle("/totally-made-up-xyz", agent, ui)
    assert action == "handled"
    assert any("unknown command" in n for n in ui.notices) or True
    # error() goes through a different method than notice() in RecordingUI


def test_builtin_and_custom_commands_take_priority_over_same_named_skill(env):
    """A skill named 'help' must never shadow the builtin /help."""
    _write_skill(env.proj / ".locode" / "skills", "help",
                body="this should never run")
    agent = Agent(env.cfg, ui=quiet_ui())
    ui = RecordingUI()
    action, payload = handle("/help", agent, ui)
    assert action == "handled"          # builtin /help path, not skill
    assert not any("never run" in n for n in ui.lines)


async def test_tui_skill_appears_in_slash_suggestions(env):
    _write_skill(env.proj / ".locode" / "skills", "deploy",
                description="deploys the app to staging")
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="done")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        prompt = app.query_one("#prompt", PromptArea)
        prompt.focus()
        prompt.load_text("/dep")
        prompt.cursor_location = (0, len("/dep"))
        await pilot.pause()
        assert app.suggestions_open
        names = [n for n, _ in app._sugg_items]
        assert "deploy" in names


async def test_tui_selecting_skill_from_popup_and_running_it(env):
    _write_skill(env.proj / ".locode" / "skills", "lint",
                body="Run the linter and fix any issues found.")
    def factory(cfg, ui):
        a = Agent(cfg, ui)
        a.llm = FakeLLM([Turn(text="linted")])
        return a
    app = LocodeApp(env.cfg, agent_factory=factory)
    async with app.run_test(size=(100, 30)) as pilot:
        prompt = app.query_one("#prompt", PromptArea)
        prompt.focus()
        prompt.load_text("/lint")
        prompt.cursor_location = (0, len("/lint"))
        await pilot.pause()
        await pilot.press("enter")   # slash-mode enter: select + run
        ok = await wait_until(lambda: not app.busy)
        assert ok
        sent = app.agent.llm.requests[-1]
        assert any("Run the linter and fix any issues found." in
                  m.get("content", "") for m in sent)
