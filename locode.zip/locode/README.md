# locode

A Claude Code / Codex-style coding agent for **models you run yourself**.
Point it at any OpenAI-compatible server — Ollama, vLLM, LM Studio,
llama.cpp, SGLang — and it plans with a todo list, searches and reads your
code, edits files with exact string replacements, runs shell commands
behind an approval gate, and verifies its own work. Built for **Qwen 3.6**
(27B / 35B-A3B), the **Qwen 3.5** family, and **Gemma 4** (E2B–31B); works
with anything that speaks `/v1/chat/completions`.

It ships a full-screen terminal UI (Textual — the Python analogue of the
Ink framework Claude Code uses): a **multi-line prompt** (Enter submits,
Ctrl+J inserts a newline — paste a traceback and it just works), slash-
command suggestions as you type `/`, an animated activity line while the
model works, tool calls and thinking tucked into collapsible dropdowns,
approval modals with diff previews, and Ctrl+Shift+C to copy the last
reply to your system clipboard (works over SSH/tmux via OSC52). Alongside: **Agent Skills** (open
[agentskills.io](https://agentskills.io) standard), **custom slash
commands**, **plugins**, **custom subagents**, an **MCP client**,
**hooks**, **clarifying questions** (the model can pause and ask you,
with tappable options or a custom answer), **plan mode**, **goals**, and
**session resume** —
compatible with Claude Code's on-disk
layouts, so `~/.claude/skills`, `.claude/commands` and `.claude/agents`
work as-is.

![locode TUI](docs/tui.svg)

Design notes: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) ·
Research on Claude Code & Codex internals: [docs/RESEARCH.md](docs/RESEARCH.md)

## Install

```bash
git clone <this repo> && cd locode
pip install -e .        # or: pipx install .   or: uv tool install .
```

Python ≥ 3.10. Dependencies: `openai`, `rich`, `textual`, `pyyaml`.
`ripgrep` is used for search when available (pure-Python fallback
otherwise).

## Quickstart — Ollama

```bash
# 1. Serve with a real context window (Ollama defaults to ~4K, which is
#    far too small for agentic work — this is the #1 setup mistake)
OLLAMA_CONTEXT_LENGTH=32768 ollama serve

# 2. Pull a model
ollama pull qwen3.6:27b        # or: gemma4:12b, qwen3.5:9b, ...

# 3. Run locode inside your project
cd ~/my-project
locode -m qwen3.6:27b --context 32768
```

`--context` must match what the server actually allocates — locode uses it
to decide when to compact history. If the server window is smaller than
locode thinks, the model silently loses the start of the conversation.

## Quickstart — vLLM

```bash
vllm serve Qwen/Qwen3.6-27B \
  --reasoning-parser qwen3 \
  --enable-auto-tool-choice \
  --tool-call-parser qwen3_coder

locode -m Qwen/Qwen3.6-27B --base-url http://localhost:8000/v1 --context 131072
```

For Gemma 4 on vLLM, serve `google/gemma-4-12b` (or E4B etc.) with
`--enable-auto-tool-choice` and the Gemma tool parser your vLLM version
ships.

## Quickstart — LM Studio / llama.cpp

Start the local server, then:

```bash
locode -m qwen/qwen3.6-27b --base-url http://localhost:1234/v1   # LM Studio
locode -m local --base-url http://localhost:8080/v1 --tool-mode prompted  # bare llama.cpp
```

If a server has no tool-call parser, `--tool-mode prompted` makes locode
describe the tools in the system prompt and parse Hermes-style
`<tool_call>` blocks itself — slower but works with nearly any model.

## Models

| Model | Tags / IDs | Native ctx | Notes |
|---|---|---|---|
| Qwen 3.6 27B | `qwen3.6:27b`, `Qwen/Qwen3.6-27B` | 262K | best quality; hybrid thinking |
| Qwen 3.6 35B-A3B | `Qwen/Qwen3.6-35B-A3B` | 262K | MoE, ~3B active — fast |
| Qwen 3.5 (0.8B–397B) | `qwen3.5:9b`, … | 262K | smaller boxes; 9B+ recommended |
| Gemma 4 E2B / E4B | `gemma4:e2b`, `gemma4:e4b` | 128K | edge-sized; keep tasks small |
| Gemma 4 12B / 26B-A4B / 31B | `gemma4:12b`, … | 256K | strong local all-rounders |

Family is auto-detected from the model name (temperature, tool mode,
context defaults). Anything else gets the `generic` profile. Qwen's own
agentic evals sample at `--temperature 1.0`; locode defaults to 0.7 for
steadier exact-match edits — experiment.

## Using it

```
❯ add input validation to the /register endpoint and write a test
```

The agent plans (`todo_write`), greps and reads code, edits, runs your
tests, and reports. Risky actions pause for approval:

```
⏺ bash(pip install email-validator)
bash needs approval — modify installed packages
allow? [y]es / [n]o / [a]lways for this tool ❯
```

`locode` opens the full-screen TUI: streaming markdown, a live status bar
(model · approval mode · context %), approval modals with diff previews,
input history (↑/↓), and Esc to interrupt a running turn mid-stream.
Prefer the classic line REPL? `locode --plain`.

Slash commands: `/help` `/skills` `/plugins` `/todos` `/tools` `/config`
`/compact` `/approval <mode>` `/model <name>` `/clear` `/quit`.

One-shot mode for scripts/CI: `locode -p "explain what broke in the last commit"`.

## Skills

locode implements the open **Agent Skills** standard
([agentskills.io](https://agentskills.io/specification)): a skill is a
folder with a `SKILL.md` (YAML frontmatter `name` + `description`, then
markdown instructions, optionally bundled `scripts/`, `references/`,
`assets/`). Progressive disclosure keeps context lean — only each skill's
name and description sit in the system prompt; the model loads the full
body with the `skill` tool when a task matches, and reads bundled files
only when the instructions point at them.

Discovery order (first name wins):

```
<project>/.locode/skills/     <project>/.claude/skills/
~/.config/locode/skills/      ~/.claude/skills/
<plugins>/skills/             built-in
```

Skills written for Claude Code drop in unchanged, and vice versa. A
**skill-creator** skill ships built in — say *"create a skill for our
release checklist"* and the agent scaffolds a spec-compliant skill,
validates it, and tells you to `/clear` to load it.

Every installed skill also appears in the `/` suggestions popup and is
directly runnable as `/skill-name [args]` — Claude Code merged commands
into skills, and locode matches that: the skill's full body loads
immediately (no round trip through the model deciding whether to call the
`skill` tool), with `args` appended as what to apply it to. Builtin
commands and custom commands both take priority over a same-named skill,
so a skill can't accidentally shadow `/help` or `/clear`.

## Custom slash commands

Markdown prompt templates: put `review.md` in `.locode/commands/` (or
`.claude/commands/` — Claude Code's folder works) and `/review src/app.py`
expands it, substituting `$ARGUMENTS` and `$1`…`$9`. Optional frontmatter
`description:` shows in `/help`.

## Plugins

A plugin bundles skills, commands, subagents, and hooks:

```bash
locode plugin install https://github.com/someone/their-plugin.git
locode plugin install ./my-plugin --project   # into .locode/plugins/
locode plugin list
```

locode reads `skills/`, `commands/`, `agents/`, and `hooks/hooks.json`
straight from Claude Code-style plugin repos (`.claude-plugin/plugin.json`
manifests understood, inline `plugin.json["hooks"]` too), so most
published plugins install unchanged. Plugin hooks support the real
`matcher` field (a regex over the tool name, e.g. `"Write|Edit"`) and
`${CLAUDE_PLUGIN_ROOT}` path substitution, merged alongside whatever's in
your own `locode.toml`. The one piece not implemented: MCP servers
bundled with a plugin — configure those directly in `locode.toml` instead
(see MCP servers, below). **Security note:** skills, agents, and hooks
from a plugin are prompt injection *and, for hooks, arbitrary code
execution* with a folder structure — hooks in particular run automatically
with no approval prompt. Read a plugin's contents before installing it;
prefer project-level installs to limit blast radius.

### Marketplaces

A marketplace is a git repo with a `.claude-plugin/marketplace.json`
listing multiple plugins (Claude Code's own format — verified against
`anthropics/claude-code`'s and `anthropics/claude-plugins-official`'s
actual manifests). Add one, browse it, install by name:

```bash
locode plugin marketplace add https://github.com/anthropics/claude-plugins-official.git
locode plugin marketplace list
locode plugin search review          # search across every added marketplace
locode plugin install code-review@claude-plugins-official
locode plugin marketplace remove claude-plugins-official
```

`/plugins` in the REPL/TUI also lists added marketplaces and marks which
of their offerings you already have installed. Not implemented: the full
github/url/git-subdir source-object schema with independent ref/sha
pinning — plain git URLs and in-repo relative paths cover every real
marketplace found in practice, but a marketplace using the advanced form
will show entries that fail to resolve.

## Approval modes

- `read-only` — explore only; file writes denied, every command confirmed.
- `workspace-write` (default) — free edits inside the project; risky
  commands (installs, sudo, pushes, recursive deletes) and writes outside
  the project ask first.
- `full-access` (`--yolo`) — no prompts except genuinely dangerous
  commands, which always ask unless `--dangerously-allow-all`.

This is application-level gating, not an OS sandbox — review what you
approve, and prefer running inside a container/VM for untrusted tasks.

## Project instructions

Drop an `AGENTS.md` (or `CLAUDE.md` / `LOCODE.md`) in your repo root —
build commands, conventions, test invocations, warnings. locode injects the
chain from the project root down to the working directory (24k char cap),
exactly like Codex does.

## Environment auto-detection

locode's bash tool spawns a fresh shell per call (see below), so nothing
persists between commands the way an already-activated shell would — this
is what caused the earlier `.venv/bin/python` vs `.venv\Scripts\python.exe`
mix-up on Windows. Fixed properly: locode now detects a project's Python
virtualenv (`.venv`/`venv`/`env`, verified via `pyvenv.cfg`) and Node
`node_modules/.bin`, and puts their executables on PATH for every bash
call automatically. The model is told this in its system prompt, so it
just runs `python`/`pip`/local CLI tools by name — no platform-specific
path guessing needed, on any OS.

## Custom subagents

The default subagent the `task` tool falls back to (no `agent=` given) is
**read-only by design** — same as Claude Code's own built-in researcher
subagent. Two reasons: subagents run with less visibility (you only see
their final report, not each step), and locode fans independent subagents
out **in parallel** when it safely can — concurrent uncoordinated writes
to the same files would be a correctness hazard, so the parallel path
requires every participant to be read-only.

This is a default, not a ceiling: give a **custom** subagent explicit
write access via its `tools:` frontmatter (below) and it can genuinely
edit files and run commands — it just won't be eligible for the parallel
fast-path, and runs serially with its own approval flow instead, same as
any other tool call.

### Step and round limits

Three dials, all configurable, all more generous than earlier defaults
now that custom subagents can do real implementation work:

| Flag | Default | What it caps |
|---|---|---|
| `--max-steps` | 60 | tool-call iterations within one turn of the main agent |
| `--subagent-max-steps` | 45 | tool-call iterations within one subagent task |
| `--goal-rounds` | 25 | auto-continue turns for `/goal` before pausing |

These exist as safety stops so a stuck local model doesn't loop forever —
Esc always interrupts regardless. Since local runs have no API cost, the
main real constraint is your own time, so raise them freely for long
unattended sessions: `locode --goal-rounds 100 --subagent-max-steps 50`.

Claude Code's `.claude/agents` pattern: a markdown file whose frontmatter
names the agent and (optionally) whitelists tools, and whose body becomes
its system prompt:

```markdown
---
name: code-reviewer
description: Reviews changes for bugs, style and security issues.
tools: read_file, glob, grep
---
You are a meticulous reviewer. Report issues with file:line references.
```

Drop it in `.locode/agents/` or `.claude/agents/`; the main agent
delegates with `task(agent="code-reviewer", …)`. Independent read-only
subagents launched in the same turn run **in parallel** (up to 4).
Installed plugins can bring subagents too, via their own `agents/`
folder — no extra setup needed, they're discovered the same way.

## MCP servers

locode is an MCP client (stdio transport). Configure servers in
`locode.toml` and their tools appear as `mcp__<server>__<tool>`, gated
behind approval by default:

```toml
[mcp_servers.github]
command = "npx"
args = ["-y", "@modelcontextprotocol/server-github"]
env = { GITHUB_TOKEN = "ghp_..." }
```

`/mcp` lists connected servers. SSE/HTTP transports, resources and prompts
aren't implemented yet — stdio covers the bulk of the ecosystem.

## Hooks

Run your own commands at lifecycle events (Claude Code's hook contract:
JSON payload on stdin, exit code 2 blocks the action, stderr becomes the
reason the model sees):

```toml
[hooks]
pre-tool-use       = ["python .locode/hooks/guard.py"]   # can veto tools
user-prompt-submit = ["python .locode/hooks/policy.py"]  # can veto prompts
post-tool-use      = ["./log_tool.sh"]
stop               = ["notify-send 'locode done'"]
```

Installed plugins can also bring hooks via `hooks/hooks.json` (or inline
`plugin.json["hooks"]`) — Claude Code's own plugin hook format, schema
verified against the official plugins reference: PascalCase event names
(`PreToolUse`, `PostToolUse`, `UserPromptSubmit`, `Stop` — the four that
map onto locode's own lifecycle events), a `matcher` regex tested against
the tool name so a hook can target just `Bash` or `Write|Edit`, and
`${CLAUDE_PLUGIN_ROOT}` substituted with the plugin's real install path:

```json
{"hooks": {"PreToolUse": [{"matcher": "Bash",
    "hooks": [{"type": "command",
               "command": "${CLAUDE_PLUGIN_ROOT}/hooks/guard.sh"}]}]}}
```

`locode.toml` hooks and every installed plugin's hooks all run for a
matching event — nothing silently overrides anything else. Not
implemented: `"type": "prompt"` hooks (LLM-evaluated, a materially
different mechanism), and the `SessionStart`/`SessionEnd`/`PreCompact`/
`Notification`/`SubagentStop` events (locode has no matching lifecycle
point for them yet) — entries for those are parsed without error but
never fire.

## Plan mode, goals, and side questions

**Plan mode** (`/plan`, `/plan <task>`, or Shift+Tab): mutating tools are
blocked, the model researches and drafts a concrete plan, then locode asks
"Execute it now?" — approving flips plan mode off and runs the plan;
declining keeps refining. A magenta PLAN badge sits in the status bar.

**Goals** (`/goal <outcome>`, `/goal clear`): after every turn locode
auto-continues (up to 8 rounds, Esc stops) until the model verifies the
goal and ends its reply with `GOAL_MET`. Pairs well with plan mode:
approve the plan, set the goal, walk away.

**Side questions** (`/btw <question>`): answered using the current
conversation but never appended to it — tangents stay out of your
context window.

**Context introspection** (`/context`): token breakdown of the window —
system prompt vs user vs assistant vs tool results, with usage bars —
plus active plan/goal state. `/compact <focus>` now takes optional
instructions to steer what the summary preserves.

## Web tools

`web_fetch` fetches a page/API and returns readable text (approval-gated —
fetched content is untrusted input). `web_search` registers once you
configure a provider in `locode.toml` — there's no ToS-clean search
endpoint to scrape, so bring Tavily, Brave, or a local SearXNG:

```toml
[search]
provider = "tavily"      # or "brave" / "searxng"
api_key  = "tvly-..."    # tavily/brave
# url    = "http://localhost:8080"   # searxng
```

Same philosophy as Claude Code: **no RAG, no embeddings** — the model
searches and fetches agentically when it needs live information.

## Training data generation

`locode datagen` produces fine-tuning data by running the *real* agent
through synthetic repos: every tool result is actually executed, and each
trajectory must pass a programmatic verifier or it's discarded. Eight task
templates cover the harness protocol (edits, todos, plan mode, goals,
ask_user, recovering from denials). Exports native function-calling and
prompted `<tool_call>` formats, with self-heal augmentation. Point
`--teacher-url` at a strong open model (Qwen 3.6 27B) for
distillation-style SFT with rejection sampling. See **TRAINING.md** for
the full strategy, recipes, and licensing notes.

## Clarifying questions

When a decision genuinely needs your input, the model calls the
`ask_user` tool and locode pauses the turn with a question modal —
↑/↓ + Enter or a number key picks a suggested option, or type a custom
answer in the field below (Esc skips; the model then proceeds with a
stated assumption). In the plain REPL it's a numbered picker. In
non-interactive `-p` mode the tool tells the model to use its best
judgment instead of hanging.

![ask_user modal](docs/ask.svg)

## Sessions, @mentions, /init

`locode --continue` restores this project's last conversation. When more
than one exists, you get a picker — a modal in the TUI, a numbered list in
`--plain` — instead of silently guessing which one you meant; `/resume`
opens the same picker anytime. Each real conversation is one file, updated
in place across its turns (not a new snapshot every turn), so the list
shows genuinely distinct past sessions, not near-duplicates.

Typing `@` in the TUI pops up a file/directory picker filtered as you keep
typing — Tab or Enter completes it; picking a directory keeps the popup
open re-filtered to its contents so you can keep drilling in (`@src` →
Tab → `@src/` → shows `main.py`, `utils.py`, …), picking a file inserts it
with a trailing space and closes the popup so you can keep writing the
rest of your message. No need to type full paths by hand.

## Copying text

Click-drag to select any text on screen (Textual's own cross-widget
selection, not terminal-native — this is a full-screen app, so terminal
right-click-copy doesn't apply the way it would in a plain scrollback),
then Ctrl+C copies it, same as any terminal app. Ctrl+C only falls
through to interrupt/quit when nothing is selected. Ctrl+Shift+C is a
shortcut that copies the model's last reply without needing to select it
first.
`@path/to/file` in a prompt attaches that file's contents. `/init`
analyzes the repo and writes an `AGENTS.md` for future sessions.

## Config file

`./locode.toml` or `~/.config/locode/config.toml`:

```toml
model = "qwen3.6:27b"
base_url = "http://localhost:11434/v1"
context_tokens = 32768
approval = "workspace-write"
temperature = 0.7
max_steps = 40
show_thinking = false
```

Precedence: defaults < global config < project config < `LOCODE_*` env
vars < CLI flags.

## Troubleshooting

- **Model forgets earlier context / ignores files it read** → your server
  window is smaller than `--context`. On Ollama set
  `OLLAMA_CONTEXT_LENGTH` (or a Modelfile `num_ctx`) and pass the same
  number to `--context`.
- **"unknown tool" or raw JSON in replies** → the server has no tool
  parser for this model; use `--tool-mode prompted`.
- **vLLM returns tool calls as plain text** → you forgot
  `--enable-auto-tool-choice --tool-call-parser …` on the vLLM command.
- **WSL2: server runs in WSL, client on Windows (or vice versa)** →
  enable [mirrored networking](https://learn.microsoft.com/en-us/windows/wsl/networking#mirrored-mode-networking)
  (`networkingMode=mirrored` in `.wslconfig`) so `localhost` resolves both
  ways.
- **Everything is slow** → try Qwen3.6-35B-A3B or Gemma 4 26B-A4B (MoE =
  few active params), a smaller quant, or `--no-stream` off (streaming is
  on by default and hides latency).

## Development

```bash
pip install -e ".[dev]"
python -m pytest tests/ -q     # 43 tests, incl. headless TUI runs and a live MCP roundtrip
```

MIT licensed. Built as a study of how Claude Code and Codex actually work —
see [docs/RESEARCH.md](docs/RESEARCH.md) for the source trail.
