"""CLI entry point.

Default: the full-screen Textual TUI. `--plain` gives the classic
line-based REPL, `-p` runs one prompt non-interactively, and
`locode plugin install|list` manages plugins.
"""
from __future__ import annotations

import argparse
import os
import sys

from . import __version__
from .agent import Agent
from .config import APPROVAL_MODES, TOOL_MODES, load_config
from .replcmds import handle
from .ui import UI


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="locode",
        description="A Claude Code-style coding agent for local models "
                    "(Qwen 3.6/3.5, Gemma 4, …) behind any OpenAI-compatible "
                    "server.",
        epilog="plugin management: locode plugin install <path-or-git-url> "
               "[--project] · locode plugin list",
    )
    p.add_argument("-m", "--model", help="model name/tag, e.g. qwen3.6:27b")
    p.add_argument("--base-url", dest="base_url",
                   help="OpenAI-compatible endpoint "
                        "(default http://localhost:11434/v1 = Ollama)")
    p.add_argument("--api-key", dest="api_key",
                   help="API key if your server needs one")
    p.add_argument("-C", "--dir", dest="project_dir", metavar="DIR",
                   help="project root to work in (default: cwd)")
    p.add_argument("--approval", choices=APPROVAL_MODES,
                   help="approval mode (default workspace-write)")
    p.add_argument("--tool-mode", dest="tool_mode", choices=TOOL_MODES,
                   help="native tool calling, prompted fallback, or auto")
    p.add_argument("--context", dest="context_tokens", type=int,
                   help="context budget in tokens — match your server's "
                        "window (Ollama: num_ctx / OLLAMA_CONTEXT_LENGTH)")
    p.add_argument("--max-steps", dest="max_steps", type=int,
                   help="max tool iterations per user turn (default 40)")
    p.add_argument("--temperature", type=float, help="sampling temperature")
    p.add_argument("--no-stream", dest="stream", action="store_const",
                   const=False, default=None, help="disable streaming output")
    p.add_argument("--think", dest="show_thinking", action="store_const",
                   const=True, default=None,
                   help="show the model's reasoning (dim text)")
    p.add_argument("--no-subagent", dest="enable_subagent",
                   action="store_const", const=False, default=None,
                   help="disable the task/subagent tool")
    p.add_argument("--yolo", action="store_true",
                   help="shortcut for --approval full-access")
    p.add_argument("--dangerously-allow-all", dest="dangerously_allow_all",
                   action="store_const", const=True, default=None,
                   help="skip confirmation even for dangerous commands "
                        "(NOT recommended)")
    p.add_argument("--plain", action="store_true",
                   help="classic line-based REPL instead of the TUI")
    p.add_argument("--continue", dest="continue_session",
                   action="store_const", const=True, default=None,
                   help="restore this project's last session")
    p.add_argument("-p", "--print", dest="oneshot", metavar="PROMPT",
                   help="run a single prompt non-interactively and exit")
    p.add_argument("--version", action="version",
                   version=f"locode {__version__}")
    return p


def _plugin_cli(argv: list[str]) -> int:
    """Handle `locode plugin …` before regular argument parsing."""
    from .plugins import discover_plugins, install_plugin

    sub = argparse.ArgumentParser(prog="locode plugin")
    sp = sub.add_subparsers(dest="action", required=True)
    inst = sp.add_parser("install", help="install a plugin from a local "
                                         "path or git URL")
    inst.add_argument("src")
    inst.add_argument("--project", action="store_true",
                      help="install into ./.locode/plugins instead of "
                           "~/.config/locode/plugins")
    sp.add_parser("list", help="list installed plugins")
    args = sub.parse_args(argv)

    cfg = load_config({})
    if args.action == "install":
        msg = install_plugin(args.src, cfg, project=args.project)
        print(msg)
        return 1 if msg.startswith("error") else 0
    for p in discover_plugins(cfg):
        print(f"{p.name}  ({p.source})  {p.root}")
    return 0


def _run_turn(agent: Agent, ui: UI, text: str) -> None:
    try:
        agent.drive(text)
    except KeyboardInterrupt:
        ui.console.print()
        ui.notice("turn interrupted — context preserved, keep typing.")
    except ConnectionError as e:
        ui.error(str(e))
    except Exception as e:  # pragma: no cover - last-resort guard
        ui.error(f"unexpected {type(e).__name__}: {e}")


def _pick_session_from(agent: Agent, ui: UI, found: list[dict]) -> None:
    """Interactive numbered picker over an already-fetched session list."""
    from . import sessions
    if not found:
        ui.notice("no past sessions for this project yet.")
        return
    if len(found) == 1:
        sessions.restore_session(agent, ui, found[0]["session_id"])
        return
    ui.print_line("[bold]Past conversations for this project:[/]")
    for i, s in enumerate(found, 1):
        import time as _time
        when = _time.strftime("%b %d %H:%M", _time.localtime(s["ts"]))
        goal = f" · goal: {s['goal'][:30]}" if s.get("goal") else ""
        ui.print_line(f"  [bold cyan]{i}.[/] {when} · {s['n_messages']} "
                      f"msg · {s['summary']}{goal}")
    try:
        raw = ui.console.input(
            "[bold cyan]resume which? (number, Enter to skip) ❯[/] ").strip()
    except (EOFError, KeyboardInterrupt):
        ui.console.print()
        return
    if not raw:
        return
    if raw.isdigit() and 1 <= int(raw) <= len(found):
        sessions.restore_session(agent, ui, found[int(raw) - 1]["session_id"])
    else:
        ui.error("not a valid choice — staying on the current conversation.")


def _pick_session(cfg, agent: Agent, ui: UI) -> None:
    """--continue entry point: fetches the list, then delegates."""
    from . import sessions
    _pick_session_from(agent, ui, sessions.list_sessions(cfg))


def _repl(cfg) -> int:
    ui = UI(interactive=True)
    agent = Agent(cfg, ui)
    ui.banner(cfg)
    if cfg.continue_session:
        _pick_session(cfg, agent, ui)
    while True:
        try:
            line = ui.console.input("\n[bold green]❯[/] ").strip()
        except (EOFError, KeyboardInterrupt):
            ui.console.print("\n[dim]bye[/]")
            agent.close()
            return 0
        if not line:
            continue
        if line.startswith("/"):
            action, payload = handle(line, agent, ui)
            if action == "quit":
                ui.console.print("[dim]bye[/]")
                return 0
            if action == "agent":
                agent = payload
                continue
            if action == "prompt":
                _run_turn(agent, ui, payload)
            if action == "side":
                try:
                    agent.side_question(payload)
                    ui.notice("side answer — not added to the context.")
                except (ConnectionError, KeyboardInterrupt) as e:
                    ui.error(str(e) or "interrupted")
            if action == "resume":
                # payload is the pre-fetched session list from replcmds;
                # reuse the interactive picker on it directly
                _pick_session_from(agent, ui, payload)
            continue
        _run_turn(agent, ui, line)


def _datagen_cli(argv: list[str]) -> int:
    from pathlib import Path
    from .datagen import generate

    sub = argparse.ArgumentParser(prog="locode datagen")
    sub.add_argument("--out", required=True, help="output directory")
    sub.add_argument("--count", type=int, default=300,
                     help="verified trajectories to produce (default 300)")
    sub.add_argument("--seed", type=int, default=0)
    sub.add_argument("--workers", type=int, default=8)
    sub.add_argument("--teacher-url", default="",
                     help="OpenAI-compatible endpoint of a teacher model "
                          "(omit to use the built-in oracle)")
    sub.add_argument("--teacher-model", default="",
                     help="teacher model name, e.g. glm-5.2")
    sub.add_argument("--teacher-key",
                     default=os.environ.get("LOCODE_TEACHER_KEY", ""),
                     help="API key for the teacher endpoint (or set "
                          "LOCODE_TEACHER_KEY)")
    sub.add_argument("--teacher-format", choices=["openai", "anthropic"],
                     default="openai",
                     help="wire format of the teacher endpoint — use "
                          "'anthropic' for Z.ai GLM Coding Plan / trial "
                          "endpoints")
    a = sub.parse_args(argv)
    generate(Path(a.out), a.count, seed=a.seed,
             teacher_url=a.teacher_url, teacher_model=a.teacher_model,
             teacher_key=a.teacher_key, teacher_format=a.teacher_format,
             workers_n=a.workers)
    return 0


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "plugin":
        return _plugin_cli(argv[1:])
    if argv and argv[0] == "datagen":
        return _datagen_cli(argv[1:])

    args = _build_parser().parse_args(argv)
    overrides = {k: v for k, v in vars(args).items()
                 if k not in ("oneshot", "yolo", "plain")}
    if args.yolo:
        overrides["approval"] = "full-access"
    cfg = load_config(overrides)

    if args.oneshot is not None:
        ui = UI(interactive=False)
        agent = Agent(cfg, ui)
        if cfg.continue_session:
            from . import sessions
            sessions.restore(agent, ui)
        _run_turn(agent, ui, args.oneshot)
        agent.close()
        return 0

    if args.plain or not sys.stdout.isatty():
        return _repl(cfg)

    if args.show_thinking is None:
        cfg.show_thinking = True   # the TUI tucks thinking into a dropdown
    try:
        from .tui import LocodeApp
    except ImportError as e:
        print(f"[locode] textual unavailable ({e}); falling back to --plain",
              file=sys.stderr)
        return _repl(cfg)
    LocodeApp(cfg).run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
