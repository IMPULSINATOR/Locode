"""Project environment detection — the "set up an environment" piece.

Claude Code doesn't do much of this explicitly; it mostly gets away
without it because it typically runs inside a shell the user already has
configured (venv sourced in .bashrc, etc.). locode's bash tool spawns a
*fresh* shell per call by design (see tools/shell.py), so nothing persists
between calls — including an activated virtualenv. Without this module the
model has to guess platform-specific interpreter paths itself, which is
exactly what went wrong on Windows (it guessed `.venv/bin/python`, the
Unix layout, instead of `.venv\\Scripts\\python.exe`).

This module detects common project environments once per Agent and:
  1. prepends their executable directories to PATH for every bash call,
     so `python`/`pip`/`node`-local-tools resolve correctly regardless of
     what the model types — no platform-specific path needed at all.
  2. produces a short note for the system prompt so the model knows an
     environment is active, instead of silently working around it.

This is PATH plumbing, not a sandbox — see docs/ARCHITECTURE.md for the
list of still-missing Claude-Code-parity items (OS-level sandboxing among
them). It also isn't a package manager: locode doesn't create or install
into venvs, only detects and uses ones that already exist.
"""
from __future__ import annotations

import os
from pathlib import Path

VENV_MARKERS = (".venv", "venv", "env", ".env")


def detect_python_venv(project_dir: Path) -> Path | None:
    """A directory is a venv iff it has a pyvenv.cfg — avoids false
    positives on a coincidentally-named plain folder."""
    for name in VENV_MARKERS:
        cand = project_dir / name
        if (cand / "pyvenv.cfg").is_file():
            return cand
    return None


def venv_bin_dir(venv: Path) -> Path:
    return venv / ("Scripts" if os.name == "nt" else "bin")


def detect_node_local_bin(project_dir: Path) -> Path | None:
    cand = project_dir / "node_modules" / ".bin"
    return cand if cand.is_dir() else None


def build_env(project_dir: Path) -> tuple[dict[str, str], list[str]]:
    """Returns (extra_env_vars, human_readable_notes).

    extra_env_vars is meant to be merged over os.environ for subprocess
    calls; notes are meant for the system prompt so the model is told
    what's already set up rather than discovering it by trial and error.
    """
    extra: dict[str, str] = {}
    notes: list[str] = []
    prepend: list[str] = []

    venv = detect_python_venv(project_dir)
    if venv is not None:
        vbin = venv_bin_dir(venv)
        if vbin.is_dir():
            prepend.append(str(vbin))
            extra["VIRTUAL_ENV"] = str(venv)
            notes.append(
                f"Python virtualenv detected ({venv.name}/) and already "
                "on PATH for every command — just run `python`/`pip` "
                "directly; do not construct a platform-specific path "
                "into it yourself.")

    node_bin = detect_node_local_bin(project_dir)
    if node_bin is not None:
        prepend.append(str(node_bin))
        notes.append(
            "node_modules/.bin detected and already on PATH — locally "
            "installed CLI tools (eslint, jest, tsc, etc.) run by name "
            "directly, no npx or relative path needed.")

    if prepend:
        sep = ";" if os.name == "nt" else ":"
        extra["PATH"] = sep.join(prepend) + sep + os.environ.get("PATH", "")

    return extra, notes
