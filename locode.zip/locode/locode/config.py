"""Configuration: model family profiles, layered config loading.

Layering (later wins): built-in defaults -> family profile ->
~/.config/locode/config.toml -> ./locode.toml -> LOCODE_* env vars -> CLI flags.
This mirrors Codex CLI's config.toml approach in miniature.
"""
from __future__ import annotations

import os
import sys
import tomllib
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any

APP_NAME = "locode"

# --------------------------------------------------------------------------
# Model family profiles
#
# `context_tokens` here is the *model's* native limit. The context the server
# actually allocates is often smaller (Ollama defaults to a few K unless you
# raise num_ctx / OLLAMA_CONTEXT_LENGTH), so we deliberately default the
# working budget to a conservative value and let the user raise it.
# --------------------------------------------------------------------------

FAMILY_PROFILES: dict[str, dict[str, Any]] = {
    # Qwen 3.6 (Apr 2026): 27B dense + 35B-A3B MoE, native 262K context,
    # hybrid thinking, strong native tool calling.
    "qwen": {
        "tool_mode": "native",
        "temperature": 0.7,   # Qwen's own agentic-coding evals use 1.0/0.95;
        "top_p": 0.95,        # 0.7 is a steadier default for exact-match edits.
        "native_context": 262_144,
        "supports_thinking": True,
    },
    # Gemma 4 (Apr 2026): E2B/E4B (128K ctx), 12B/26B-A4B/31B (256K ctx),
    # native function calling + thinking mode.
    "gemma": {
        "tool_mode": "native",
        "temperature": 0.7,
        "top_p": 0.95,
        "native_context": 131_072,
        "supports_thinking": True,
    },
    "generic": {
        "tool_mode": "native",
        "temperature": 0.7,
        "top_p": 0.95,
        "native_context": 32_768,
        "supports_thinking": False,
    },
}

APPROVAL_MODES = ("read-only", "workspace-write", "full-access")
TOOL_MODES = ("auto", "native", "prompted")


def detect_family(model: str) -> str:
    m = model.lower()
    if "qwen" in m:
        return "qwen"
    if "gemma" in m:
        return "gemma"
    return "generic"


@dataclass
class Config:
    # connection
    base_url: str = "http://localhost:11434/v1"   # Ollama default
    api_key: str = "local"
    model: str = "qwen3.6:27b"

    # behaviour
    family: str = ""                  # auto-detected from model if empty
    tool_mode: str = "auto"           # auto | native | prompted
    approval: str = "workspace-write" # read-only | workspace-write | full-access
    project_dir: Path = field(default_factory=Path.cwd)

    # budgets
    context_tokens: int = 32_768      # working budget; match your server!
    max_output_tokens: int = 4096
    max_steps: int = 60               # tool iterations per user turn
    subagent_max_steps: int = 45      # tool iterations per subagent task
    goal_rounds: int = 25             # max auto-continue rounds for /goal
    command_timeout: int = 180        # seconds per bash command
    compact_threshold: float = 0.75   # compact when est. usage passes this
    tool_result_limit: int = 30_000   # chars of tool output fed back

    # sampling
    temperature: float = 0.7
    top_p: float = 0.95

    # ux
    stream: bool = True
    show_thinking: bool = False
    enable_subagent: bool = True
    dangerously_allow_all: bool = False   # skip even 'dangerous' confirms
    continue_session: bool = False        # restore the last session
    plan_mode: bool = False               # research-only planning mode

    # extensions (configured via locode.toml)
    mcp_servers: dict = field(default_factory=dict)  # [mcp_servers.<name>]
    hooks: dict = field(default_factory=dict)        # [hooks]
    search: dict = field(default_factory=dict)       # [search] provider/key
    save_sessions: bool = True

    def resolved_tool_mode(self) -> str:
        if self.tool_mode != "auto":
            return self.tool_mode
        return FAMILY_PROFILES[self.family or "generic"]["tool_mode"]

    @property
    def supports_thinking(self) -> bool:
        return FAMILY_PROFILES.get(self.family or "generic", {}).get(
            "supports_thinking", False
        )


def _load_toml(path: Path) -> dict[str, Any]:
    try:
        with open(path, "rb") as f:
            return tomllib.load(f)
    except FileNotFoundError:
        return {}
    except Exception as e:  # malformed config shouldn't crash the CLI
        print(f"[locode] warning: could not parse {path}: {e}", file=sys.stderr)
        return {}


def _env_overrides() -> dict[str, Any]:
    out: dict[str, Any] = {}
    mapping = {
        "LOCODE_BASE_URL": ("base_url", str),
        "LOCODE_API_KEY": ("api_key", str),
        "LOCODE_MODEL": ("model", str),
        "LOCODE_CONTEXT": ("context_tokens", int),
        "LOCODE_APPROVAL": ("approval", str),
        "LOCODE_TOOL_MODE": ("tool_mode", str),
        # convenience: reuse OpenAI-style vars if user already sets them
        "OPENAI_BASE_URL": ("base_url", str),
    }
    for var, (key, cast) in mapping.items():
        if var in os.environ and key not in out:
            try:
                out[key] = cast(os.environ[var])
            except ValueError:
                pass
    return out


def load_config(cli_overrides: dict[str, Any] | None = None) -> Config:
    cfg = Config()
    valid = {f.name for f in fields(Config)}

    layers: list[dict[str, Any]] = [
        _load_toml(Path.home() / ".config" / APP_NAME / "config.toml"),
        _load_toml(Path.cwd() / "locode.toml"),
        _env_overrides(),
        {k: v for k, v in (cli_overrides or {}).items() if v is not None},
    ]
    for layer in layers:
        for k, v in layer.items():
            if k in valid and v is not None:
                if k == "project_dir":
                    v = Path(v)
                setattr(cfg, k, v)

    cfg.project_dir = Path(cfg.project_dir).resolve()
    if not cfg.family:
        cfg.family = detect_family(cfg.model)

    # pull family default context only if user never set one explicitly
    explicitly_set = any("context_tokens" in layer for layer in layers)
    if not explicitly_set:
        cfg.context_tokens = min(
            32_768, FAMILY_PROFILES[cfg.family]["native_context"]
        )

    if cfg.approval not in APPROVAL_MODES:
        raise SystemExit(
            f"invalid --approval {cfg.approval!r}; choose from {APPROVAL_MODES}"
        )
    if cfg.tool_mode not in TOOL_MODES:
        raise SystemExit(
            f"invalid --tool-mode {cfg.tool_mode!r}; choose from {TOOL_MODES}"
        )
    return cfg
