"""Terminal UI (rich)."""
from __future__ import annotations

import sys

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text

from . import __version__
from .tools.todo import render_todos


class UI:
    def __init__(self, interactive: bool = True, quiet: bool = False) -> None:
        self.console = Console(highlight=False)
        self.interactive = interactive and sys.stdin.isatty()
        self.quiet = quiet
        self._streamed = False
        self._status = None
        self._think_open = False

    # ------------------------------------------------------------ banner

    def banner(self, cfg) -> None:
        if self.quiet:
            return
        self.console.print(
            f"[bold]locode[/] v{__version__} · [cyan]{cfg.model}[/] "
            f"@ {cfg.base_url}\n"
            f"[dim]project: {cfg.project_dir} · approval: {cfg.approval} · "
            f"tools: {cfg.resolved_tool_mode()} · ctx budget: "
            f"{cfg.context_tokens:,} tok · /help for commands[/]"
        )

    # ------------------------------------------------------- model output

    def wait_start(self) -> None:
        if self.quiet or not self.console.is_terminal:
            return
        self._status = self.console.status("[dim]thinking…[/]", spinner="dots")
        self._status.start()

    def wait_stop(self) -> None:
        if self._status is not None:
            self._status.stop()
            self._status = None

    def _interrupt_wait(self) -> None:
        # stop the spinner the moment real output starts
        if self._status is not None:
            self._status.stop()
            self._status = None

    def stream_text(self, chunk: str) -> None:
        self._interrupt_wait()
        if self._think_open:
            self.console.print("", end="\n")
            self._think_open = False
        self._streamed = True
        self.console.print(Text(chunk), end="", soft_wrap=True)

    def stream_thinking(self, chunk: str) -> None:
        self._interrupt_wait()
        self._think_open = True
        self.console.print(Text(chunk, style="grey50 italic"), end="",
                           soft_wrap=True)

    def stream_end(self) -> None:
        if self._streamed or self._think_open:
            self.console.print()
        self._streamed = False
        self._think_open = False

    def assistant_text(self, text: str) -> None:
        if text.strip():
            self.console.print(Markdown(text))

    # -------------------------------------------------------------- tools

    def tool_call(self, name: str, summary: str) -> None:
        self._interrupt_wait()
        self.console.print(
            f"[bold cyan]⏺ {name}[/][dim]({summary})[/]")

    def tool_result(self, name: str, result: str) -> None:
        if self.quiet:
            return
        lines = result.splitlines() or [""]
        shown = lines[:5]
        body = "\n".join(l[:160] for l in shown)
        extra = len(lines) - len(shown)
        if extra > 0:
            body += f"\n… +{extra} more line(s)"
        self.console.print(Text(body, style="dim"))
        if name == "todo_write":
            pass  # already a checklist

    def todos_panel(self, todos: list[dict]) -> None:
        self.console.print(Panel(render_todos(todos), title="plan",
                                 border_style="dim"))

    def subagent_start(self, label: str) -> None:
        self.console.print(f"[magenta]⇢ subagent:[/] [dim]{label}[/]")

    def subagent_end(self) -> None:
        self.console.print("[magenta]⇠ subagent finished[/]")

    # ---------------------------------------------------------- approvals

    def confirm(self, tool: str, reason: str, preview: str) -> str:
        """Return 'y', 'n' or 'a' (always allow this tool this session)."""
        if not self.interactive:
            self.console.print(
                f"[yellow]auto-denied[/] {tool}: {reason} "
                "[dim](non-interactive; use --approval full-access to allow)[/]")
            return "n"
        self._interrupt_wait()
        title = f"[bold yellow]{tool}[/] needs approval — {reason}"
        if preview:
            if preview.lstrip().startswith(("---", "+++", "@@")) or "\n+++" in preview:
                body = Syntax(preview, "diff", word_wrap=True)
            else:
                body = Text(preview)
            self.console.print(Panel(body, title=title, border_style="yellow"))
        else:
            self.console.print(title)
        while True:
            ans = self.console.input(
                "[bold]allow?[/] [green]y[/]es / [red]n[/]o / "
                "[cyan]a[/]lways for this tool ❯ ").strip().lower()
            if ans in ("y", "yes"):
                return "y"
            if ans in ("n", "no", ""):
                return "n"
            if ans in ("a", "always"):
                return "a"

    # ------------------------------------------------------------- misc

    def notice(self, msg: str) -> None:
        self.console.print(f"[yellow]•[/] [dim]{msg}[/]")

    def error(self, msg: str) -> None:
        self.console.print(f"[bold red]error:[/] {msg}")

    def print_line(self, markup: str) -> None:
        self.console.print(markup)

    def ask_user(self, question: str, options: list[str]) -> str | None:
        """Returns the answer, '' if skipped, or None if we can't ask."""
        if not self.interactive:
            return None
        self.console.print()
        self.console.print(Panel(question, title="locode asks",
                                 border_style="cyan"))
        for i, opt in enumerate(options, 1):
            self.console.print(f"  [bold cyan]{i}.[/] {opt}")
        hint = ("pick a number or type your own answer"
                if options else "type your answer")
        self.console.print(f"  [dim]({hint}; empty to skip)[/]")
        try:
            raw = self.console.input("[bold cyan]answer ❯[/] ").strip()
        except (EOFError, KeyboardInterrupt):
            self.console.print()
            return ""
        if raw.isdigit() and options and 1 <= int(raw) <= len(options):
            return options[int(raw) - 1]
        return raw

    def update_status(self, used_tokens: int, budget: int) -> None:
        pass  # the plain REPL has no persistent status bar
