"""Slash commands, shared between the plain REPL and the Textual TUI.

`handle()` returns an (action, payload) pair:

    ("quit",    None)       exit the app
    ("handled", None)       command consumed, nothing else to do
    ("agent",   new_agent)  the agent was rebuilt (/clear, /model)
    ("prompt",  text)       a custom command expanded — run it as a turn
"""
from __future__ import annotations

from .agent import Agent
from .commands import expand_command
from .config import APPROVAL_MODES, detect_family
from .parsing import estimate_tokens

BUILTIN_COMMANDS: list[tuple[str, str]] = [
    ("help", "show help and available commands"),
    ("plan", "plan mode: research → approve → execute (/plan <task>, off)"),
    ("goal", "auto-continue until a goal is met (/goal <desc>, clear)"),
    ("btw", "side question — answered without joining the context"),
    ("context", "show what is using the context window"),
    ("init", "analyze this repo and write an AGENTS.md"),
    ("resume", "pick a past conversation to continue"),
    ("model", "switch model (resets the conversation)"),
    ("approval", "read-only | workspace-write | full-access"),
    ("skills", "list installed skills"),
    ("agents", "list custom subagents"),
    ("plugins", "list installed plugins"),
    ("mcp", "list connected MCP servers and tools"),
    ("compact", "summarize older history (/compact [focus])"),
    ("todos", "show the current plan"),
    ("tools", "list available tools"),
    ("config", "show active configuration"),
    ("clear", "reset the conversation"),
    ("quit", "exit"),
]

INIT_PROMPT = (
    "Analyze this repository: its purpose, structure, build/test/lint "
    "commands, and code conventions. Then write an AGENTS.md at the "
    "project root that would help a coding agent work here effectively — "
    "short imperative sections: overview, commands, conventions, "
    "warnings. Keep it under 60 lines. If AGENTS.md already exists, "
    "improve it instead of overwriting blindly."
)

HELP = """\
[bold]/help[/]                 show this help
[bold]/plan [task|off][/]      plan mode: research, draft a plan, approve, execute
[bold]/goal <desc>[/]          auto-continue each turn until the goal is met
[bold]/btw <question>[/]       side question (not added to the context)
[bold]/context[/]              show what is using the context window
[bold]/model <name>[/]         switch model (resets the conversation)
[bold]/approval <mode>[/]      read-only | workspace-write | full-access
[bold]/skills[/]               list installed skills
[bold]/agents[/]               list custom subagents
[bold]/plugins[/]              list installed plugins
[bold]/mcp[/]                  list connected MCP servers
[bold]/init[/]                 analyze the repo and write AGENTS.md
[bold]/resume[/]               pick a past conversation to continue
[bold]/compact[/]              summarize older history to free context
[bold]/todos[/]                show the current plan
[bold]/tools[/]                list available tools
[bold]/config[/]               show active configuration
[bold]/clear[/]                reset the conversation (also reloads skills)
[bold]/quit[/]                 exit

Anything else is sent to the model. One message per line."""


def handle(line: str, agent: Agent, ui) -> tuple[str, object]:
    parts = line.split(maxsplit=1)
    name = parts[0].lower().lstrip("/")
    arg = parts[1].strip() if len(parts) > 1 else ""
    cfg = agent.cfg

    if name in ("quit", "exit", "q"):
        return "quit", None

    if name == "plan":
        if arg.lower() in ("off", "exit", "stop"):
            cfg.plan_mode = False
            ui.notice("plan mode off.")
            return "handled", None
        if not arg:
            cfg.plan_mode = not cfg.plan_mode
            ui.notice("plan mode ON — research only; I'll ask before "
                      "executing. (/plan off or Shift+Tab to exit)"
                      if cfg.plan_mode else "plan mode off.")
            return "handled", None
        cfg.plan_mode = True
        ui.notice("plan mode ON — researching and drafting a plan first.")
        return "prompt", arg

    if name == "goal":
        if arg.lower() == "clear":
            agent.goal = ""
            ui.notice("goal cleared.")
        elif not arg:
            ui.notice(f"active goal: {agent.goal}" if agent.goal
                      else "no active goal. Usage: /goal <desired outcome>")
        else:
            agent.goal = arg
            ui.notice("goal set — after each turn I'll auto-continue "
                      f"(max 8 rounds, Esc stops) until met: {arg}")
        return "handled", None

    if name == "btw":
        if not arg:
            ui.error("usage: /btw <side question>")
            return "handled", None
        return "side", arg

    if name == "context":
        budget = max(1, cfg.context_tokens - cfg.max_output_tokens)
        sys_t = estimate_tokens(agent.messages[:1])
        rest = agent.messages[1:]
        by_role = {"user": 0, "assistant": 0, "tool": 0}
        counts = {"user": 0, "assistant": 0, "tool": 0}
        for m in rest:
            r = m.get("role", "user")
            r = r if r in by_role else "user"
            by_role[r] += estimate_tokens([m])
            counts[r] += 1
        total = estimate_tokens(agent.messages)

        def bar(x: int) -> str:
            return "█" * max(1, round(24 * x / budget)) if x else ""

        ui.print_line(f"[bold]context[/] — {total:,} / {budget:,} tokens "
                      f"({min(100, 100 * total // budget)}%), "
                      f"{len(agent.messages)} message(s)")
        ui.print_line(f"  system prompt  {sys_t:>7,}  [cyan]{bar(sys_t)}[/]")
        ui.print_line(f"  user ({counts['user']:>3})     "
                      f"{by_role['user']:>7,}  [green]{bar(by_role['user'])}[/]")
        ui.print_line(f"  assistant ({counts['assistant']:>3})"
                      f"{by_role['assistant']:>7,}  "
                      f"[magenta]{bar(by_role['assistant'])}[/]")
        ui.print_line(f"  tool results ({counts['tool']:>3})"
                      f"{by_role['tool']:>6,}  "
                      f"[yellow]{bar(by_role['tool'])}[/]")
        ui.print_line(f"  free           {max(0, budget - total):>7,}")
        extras = []
        if cfg.plan_mode:
            extras.append("plan mode ON")
        if agent.goal:
            extras.append(f"goal: {agent.goal}")
        if agent.todos:
            extras.append(f"{len(agent.todos)} todo(s)")
        if extras:
            ui.print_line("  [dim]" + " · ".join(extras) + "[/]")
        return "handled", None

    if name == "resume":
        from . import sessions
        found = sessions.list_sessions(cfg)
        if not found:
            ui.notice("no past sessions for this project yet.")
            return "handled", None
        return "resume", found

    if name == "init":
        return "prompt", INIT_PROMPT

    if name == "agents":
        if not agent.agent_defs:
            ui.notice("no custom subagents. Drop markdown files into "
                      ".locode/agents/ or .claude/agents/ "
                      "(frontmatter: name, description, tools).")
        for a in agent.agent_defs.values():
            tools = ", ".join(a.tools) if a.tools else "read-only"
            ui.print_line(f"[bold]{a.name}[/] [dim]({a.source} · "
                          f"{tools})[/] — {a.description[:110]}")
        return "handled", None

    if name == "mcp":
        if not agent.mcp_servers:
            ui.notice("no MCP servers connected. Add [mcp_servers.<name>] "
                      "with command/args to locode.toml.")
        for sname, srv in agent.mcp_servers.items():
            ui.print_line(f"[bold]{sname}[/] — {len(srv.tools)} tool(s)")
            for t in srv.tools[:15]:
                ui.print_line(f"  [dim]mcp__{sname}__{t.get('name')}[/]")
        return "handled", None

    if name == "help":
        ui.print_line(HELP)
        if agent.commands:
            ui.print_line("\n[bold]Custom commands[/]")
            for c in agent.commands.values():
                desc = c.description or f"template from {c.source}"
                ui.print_line(f"[bold]/{c.name}[/]  — [dim]{desc}[/]")
        return "handled", None

    if name == "clear":
        ui.notice("conversation cleared; skills/commands reloaded.")
        return "agent", Agent(cfg, ui)

    if name == "compact":
        if len(agent.messages) < 4:
            ui.notice("nothing to compact yet.")
        else:
            agent.compact(arg or None)
        return "handled", None

    if name == "todos":
        ui.todos_panel(agent.todos)
        return "handled", None

    if name == "tools":
        for s in agent.registry.values():
            first = s.description.strip().splitlines()[0]
            ui.print_line(f"[bold]{s.name}[/] — [dim]{first}[/]")
        return "handled", None

    if name == "skills":
        if not agent.skills:
            ui.notice("no skills installed. Ask me to create one "
                      "(the skill-creator skill ships built in), or drop "
                      "folders into .locode/skills/ or ~/.claude/skills/.")
        for s in agent.skills.values():
            ui.print_line(f"[bold]{s.name}[/] [dim]({s.source})[/] — "
                          f"{s.description[:120]}")
        return "handled", None

    if name == "plugins":
        from .plugins import discover_plugins
        plugins = discover_plugins(cfg)
        if not plugins:
            ui.notice("no plugins installed. "
                      "Install with: locode plugin install <path-or-git-url>")
        for p in plugins:
            ui.print_line(f"[bold]{p.name}[/] [dim]({p.source})[/] — "
                          f"{p.description or p.root}")
        return "handled", None

    if name == "config":
        for k in ("model", "base_url", "approval", "context_tokens",
                  "max_steps", "temperature", "project_dir"):
            ui.print_line(f"[bold]{k}[/] = {getattr(cfg, k)}")
        ui.print_line(f"[bold]tool_mode[/] = {cfg.resolved_tool_mode()} "
                      f"[dim](family: {cfg.family})[/]")
        ui.print_line(f"[bold]skills[/] = {len(agent.skills)} · "
                      f"[bold]custom commands[/] = {len(agent.commands)}")
        return "handled", None

    if name == "approval":
        if arg not in APPROVAL_MODES:
            ui.error(f"usage: /approval {{{'|'.join(APPROVAL_MODES)}}}")
        else:
            cfg.approval = arg
            ui.notice(f"approval mode → {arg}")
        return "handled", None

    if name == "model":
        if not arg:
            ui.error("usage: /model <name>")
            return "handled", None
        cfg.model = arg
        cfg.family = detect_family(arg)
        ui.notice(f"model → {arg} (family: {cfg.family}; conversation reset)")
        return "agent", Agent(cfg, ui)

    # custom commands (markdown templates)
    custom = agent.commands.get(name)
    if custom is not None:
        try:
            return "prompt", expand_command(custom, arg)
        except OSError as e:
            ui.error(f"could not read {custom.path}: {e}")
            return "handled", None

    ui.error(f"unknown command /{name} — try /help")
    return "handled", None
