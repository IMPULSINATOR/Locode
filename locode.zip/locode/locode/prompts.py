"""System prompt construction.

Distilled from what Claude Code and Codex CLI put in front of their models,
rewritten for small local models: shorter, more imperative, with the tool
contract spelled out explicitly. Structure (static first, variable last)
follows Codex's prompt-caching lesson: instructions -> tool protocol ->
environment -> project instructions (AGENTS.md chain).
"""
from __future__ import annotations

import datetime
import platform
import subprocess
from pathlib import Path

from .config import Config
from .tools import ToolSpec, render_tools_for_prompt

INSTRUCTION_FILES = ("AGENTS.md", "CLAUDE.md", "LOCODE.md")
INSTRUCTIONS_CHAR_CAP = 24_000  # ~Codex's 32 KiB project_doc cap, scaled down

CORE = """You are locode, an expert software engineering agent running locally in the user's terminal. You work autonomously: you investigate, act with tools, verify, and report — you do not narrate plans you could simply execute.

# How you work
1. UNDERSTAND: For anything non-trivial, look before you leap. Use grep/glob to find relevant files and read_file to inspect them. Never guess file contents or APIs — verify.
2. PLAN: For tasks with 3+ steps, call todo_write first and keep it updated as you go (exactly one item in_progress at a time; mark items completed immediately when done).
3. ACT: Make changes with edit_file/write_file and run commands with bash. Work in small verifiable increments.
4. VERIFY: After changes, check your work — run the tests, the build, or the script itself. If the project has a test or lint command, use it. Fix what you broke.
5. REPORT: When the task is done, stop calling tools and reply with a short summary (a few sentences: what changed, in which files, how it was verified). No pep talk, no restating the plan.

# Code conventions
- Mimic the existing codebase: match its style, naming, structure, and libraries.
- Never assume a library is available — check the project's dependency file or imports first before using it.
- Prefer minimal, surgical changes over rewrites. Do not "improve" unrelated code, do not add comments explaining your edits unless asked.
- Never invent file paths, functions, or APIs. If unsure, search first.

# Tool discipline
- read_file before edit_file, always. edit_file old_string must match the current file exactly (whitespace included) and be unique — include surrounding lines for uniqueness. Never include the 'N→' line-number prefix.
- Prefer grep/glob/read_file over bash equivalents (grep -r, find, cat).
- bash runs each command in a FRESH shell from the project root: nothing persists between calls, so chain with && where needed.
- If a tool returns an error, read the error carefully and adjust; do not repeat the identical call.
- If the same approach fails twice, step back and try a different one.

# Safety
- You may see credentials or secrets in files; never print, copy, or transmit them beyond what the task strictly requires.
- Destructive operations (deleting many files, force-push, resets, package installs) only when the task clearly requires them — the user will be asked to approve risky commands.
- Never run `git commit` or `git push` unless the user explicitly asks.
- If the user's request is genuinely ambiguous or a choice would be hard to reverse, use the ask_user tool (with 2-5 suggested options) BEFORE doing the work, then follow the answer. For minor ambiguities, proceed with a reasonable assumption and state it.

# Style
- Be direct and concise. Answer questions about the code plainly, citing file paths (and line numbers where useful).
- Text you output is rendered as markdown in a terminal; keep it compact."""

PROMPTED_PROTOCOL = """# Tool call protocol (IMPORTANT — read carefully)
Native function calling is not enabled; you call tools by writing a block in this EXACT format:

<tool_call>
{{"name": "tool_name", "arguments": {{"param": "value"}}}}
</tool_call>

Rules:
- Emit AT MOST ONE <tool_call> block per message, at the END of the message. You may write one short sentence before it; write nothing after it.
- The block must contain a single valid JSON object with "name" and "arguments" keys. Use double quotes. No comments, no trailing commas.
- After you call a tool, STOP. The result will arrive in the next message inside <tool_response> tags. Never write <tool_response> yourself and never invent results.
- When the task is complete, reply with plain text and NO <tool_call> block — that ends the turn.

# Available tools
{tools}"""

NATIVE_NOTES = """# Tool calls
- Use the provided tools via native function calling. You may call more than one tool in a single turn only when the calls are independent (e.g. reading three files); otherwise call one tool, observe the result, then decide.
- When the task is complete, reply with plain text and no tool calls — that ends the turn."""

SUBAGENT_CORE = """You are a read-only research subagent inside locode, a local coding agent. Investigate the codebase with your tools (read_file, glob, grep) to answer the task you were given. You cannot modify files or run commands.

Work efficiently: search, read only what you need, and finish with ONE final plain-text report containing the concrete facts the caller needs — relevant file paths, line numbers, code snippets, and a direct answer. Your report is the only thing the caller sees."""

COMPACT_PROMPT = """You are compacting an agentic coding session so it can continue in a smaller context. Write a dense continuation summary with these sections:

1. GOAL: the user's overall objective, verbatim where possible.
2. STATE: what has been done so far (files created/modified with paths, commands run and their key results, decisions made).
3. LEARNED: important facts discovered about the codebase (structure, conventions, gotchas, exact paths, function names).
4. PENDING: the current todo list and what remains.
5. NEXT: the immediate next step.

Be specific — exact paths, names and commands. Output only the summary."""


# ------------------------------------------------------------ environment

def _git_info(root: Path) -> str:
    try:
        branch = subprocess.run(
            ["git", "-C", str(root), "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=5,
        )
        if branch.returncode != 0:
            return "Git: not a git repository"
        status = subprocess.run(
            ["git", "-C", str(root), "status", "--porcelain"],
            capture_output=True, text=True, timeout=5,
        )
        dirty = len([l for l in status.stdout.splitlines() if l.strip()])
        state = "clean" if dirty == 0 else f"{dirty} changed file(s)"
        return f"Git: branch {branch.stdout.strip()}, {state}"
    except (OSError, subprocess.TimeoutExpired):
        return "Git: unavailable"


def environment_block(cfg: Config) -> str:
    return "\n".join([
        "# Environment",
        f"OS: {platform.system()} {platform.release()} ({platform.machine()})",
        f"Project root (your working directory): {cfg.project_dir}",
        _git_info(cfg.project_dir),
        f"Date: {datetime.date.today().isoformat()}",
        f"Model: {cfg.model} | approval mode: {cfg.approval}",
    ])


# ------------------------------------------------------------ project map

def project_map(root: Path, max_entries: int = 150, max_depth: int = 4) -> str:
    """A compact file tree so small models can orient without a dozen
    glob calls (Aider's repo-map idea, minus the symbol extraction —
    Claude Code deliberately skips RAG in favor of agentic search, and so
    do we; this is orientation, not retrieval)."""
    from .tools.files import SKIP_DIRS

    lines: list[str] = []
    truncated = False

    def walk(d: Path, depth: int) -> None:
        nonlocal truncated
        if truncated or depth > max_depth:
            return
        try:
            entries = sorted(d.iterdir(),
                             key=lambda p: (p.is_file(), p.name.lower()))
        except OSError:
            return
        for p in entries:
            if p.name.startswith(".") or p.name in SKIP_DIRS:
                continue
            if len(lines) >= max_entries:
                truncated = True
                return
            indent = "  " * depth
            lines.append(f"{indent}{p.name}{'/' if p.is_dir() else ''}")
            if p.is_dir():
                walk(p, depth + 1)

    walk(root, 0)
    if not lines:
        return ""
    body = "\n".join(lines)
    note = "\n… (truncated — use glob/grep to explore further)"         if truncated else ""
    return f"# Project layout\n```\n{body}{note}\n```"


# ------------------------------------------- project instructions (AGENTS.md)

def discover_instructions(root: Path, cwd: Path | None = None) -> str:
    """Codex-style instruction chain: root -> ... -> cwd, first matching
    filename per directory, later files override earlier (they simply come
    later in the prompt), capped in size."""
    cwd = (cwd or root).resolve()
    root = root.resolve()
    chain: list[Path] = [root]
    try:
        rel = cwd.relative_to(root)
        acc = root
        for part in rel.parts:
            acc = acc / part
            chain.append(acc)
    except ValueError:
        pass  # cwd outside root: just use root

    sections: list[str] = []
    budget = INSTRUCTIONS_CHAR_CAP
    for d in chain:
        for name in INSTRUCTION_FILES:
            f = d / name
            if f.is_file():
                try:
                    text = f.read_text(errors="replace").strip()
                except OSError:
                    continue
                if not text:
                    continue
                take = text[:budget]
                sections.append(f"<!-- {f} -->\n{take}")
                budget -= len(take)
                break  # one file per directory
        if budget <= 0:
            break
    if not sections:
        return ""
    return "# Project instructions (from the repository — follow these)\n" + \
        "\n\n".join(sections)


# ------------------------------------------------------------- assembly

def build_system_prompt(cfg: Config, registry: dict[str, ToolSpec],
                        *, prompted: bool, subagent: bool = False,
                        skills: dict | None = None,
                        agent_defs: dict | None = None,
                        core_override: str | None = None,
                        env_notes: list[str] | None = None) -> str:
    parts = [core_override or (SUBAGENT_CORE if subagent else CORE)]
    if prompted:
        parts.append(PROMPTED_PROTOCOL.format(
            tools=render_tools_for_prompt(registry)))
    else:
        parts.append(NATIVE_NOTES)
    parts.append(environment_block(cfg))
    if env_notes:
        parts.append("# Detected project environment\n" +
                     "\n".join(f"- {n}" for n in env_notes))
    if skills:
        from .skills import render_skills_block
        parts.append(render_skills_block(skills))
    if agent_defs:
        from .agents import render_agents_block
        parts.append(render_agents_block(agent_defs))
    pmap = project_map(cfg.project_dir)
    if pmap:
        parts.append(pmap)
    if not subagent:
        instructions = discover_instructions(cfg.project_dir)
        if instructions:
            parts.append(instructions)
    return "\n\n".join(parts)
