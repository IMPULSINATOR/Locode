"""Session persistence — `locode --continue` picks up where you left off.

After every turn the conversation (messages + todos) is written to
~/.local/share/locode/sessions/<project-hash>/latest.json, with timestamped
copies kept alongside (last 20). Codex persists sessions in SQLite;
plain JSON keeps ours inspectable and dependency-free.
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

KEEP = 20


def session_dir(cfg) -> Path:
    h = hashlib.sha1(str(cfg.project_dir).encode()).hexdigest()[:12]
    return Path.home() / ".local" / "share" / "locode" / "sessions" / h


def save(agent) -> None:
    try:
        d = session_dir(agent.cfg)
        d.mkdir(parents=True, exist_ok=True)
        blob = json.dumps({
            "ts": time.time(),
            "project": str(agent.cfg.project_dir),
            "model": agent.cfg.model,
            "tool_mode": agent.cfg.resolved_tool_mode(),
            "messages": agent.messages,
            "todos": agent.todos,
        }, default=str)
        (d / "latest.json").write_text(blob)
        (d / f"{int(time.time())}.json").write_text(blob)
        stamps = sorted(d.glob("[0-9]*.json"))
        for old in stamps[:-KEEP]:
            old.unlink(missing_ok=True)
    except OSError:
        pass  # persistence must never break a turn


def load_latest(cfg) -> dict | None:
    f = session_dir(cfg) / "latest.json"
    if not f.is_file():
        return None
    try:
        data = json.loads(f.read_text(errors="replace"))
        return data if isinstance(data.get("messages"), list) else None
    except (json.JSONDecodeError, OSError):
        return None


def restore(agent, ui) -> bool:
    """Apply the latest saved session to a fresh agent. True on success."""
    data = load_latest(agent.cfg)
    if not data:
        ui.notice("no previous session found for this project.")
        return False
    if data.get("tool_mode") != agent.cfg.resolved_tool_mode():
        ui.notice("previous session used a different tool mode; "
                  "starting fresh.")
        return False
    # keep the freshly built system prompt; restore everything after it
    agent.messages = [agent.messages[0]] + \
        [m for m in data["messages"] if m.get("role") != "system"]
    agent.todos = data.get("todos") or []
    n = len(agent.messages) - 1
    when = time.strftime("%Y-%m-%d %H:%M",
                         time.localtime(float(data.get("ts", 0))))
    extra = ""
    if data.get("model") != agent.cfg.model:
        extra = f" (was {data.get('model')}, now {agent.cfg.model})"
    ui.notice(f"resumed session from {when} — {n} message(s){extra}.")
    return True
