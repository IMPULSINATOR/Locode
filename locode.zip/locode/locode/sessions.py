"""Session persistence — `locode --continue` / `/resume` pick up where you
left off.

Each conversation gets ONE file, keyed by a session id generated the first
time it's saved, and updated in place on every subsequent turn — not a new
snapshot per turn. That distinction matters: it's what makes
`list_sessions()` a meaningful "resume" picker (one entry per real past
conversation) rather than dozens of near-duplicate growth-snapshots of the
same thread. `latest.json` is kept alongside purely as a fast pointer for
the common "just continue what I was doing" case.

Layout: ~/.local/share/locode/sessions/<project-hash>/<session_id>.json
Codex persists sessions in SQLite; plain JSON keeps ours inspectable and
dependency-free. Retention: last 20 distinct sessions per project.
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from pathlib import Path

KEEP = 20


def session_dir(cfg) -> Path:
    h = hashlib.sha1(str(cfg.project_dir).encode()).hexdigest()[:12]
    return Path.home() / ".local" / "share" / "locode" / "sessions" / h


def _new_id() -> str:
    return uuid.uuid4().hex[:12]


def _session_file(cfg, session_id: str) -> Path:
    return session_dir(cfg) / f"{session_id}.json"


def _prune(d: Path) -> None:
    files = [f for f in d.glob("*.json") if f.name != "latest.json"]
    if len(files) <= KEEP:
        return
    files.sort(key=lambda f: f.stat().st_mtime)
    for old in files[:-KEEP]:
        old.unlink(missing_ok=True)


def save(agent) -> None:
    try:
        d = session_dir(agent.cfg)
        d.mkdir(parents=True, exist_ok=True)
        if not agent.session_id:
            agent.session_id = _new_id()
        blob = json.dumps({
            "session_id": agent.session_id,
            "ts": time.time(),
            "project": str(agent.cfg.project_dir),
            "model": agent.cfg.model,
            "tool_mode": agent.cfg.resolved_tool_mode(),
            "messages": agent.messages,
            "todos": agent.todos,
            "input_history": agent.input_history[-200:],
            "goal": agent.goal,
        }, default=str)
        _session_file(agent.cfg, agent.session_id).write_text(blob)
        (d / "latest.json").write_text(blob)
        _prune(d)
    except OSError:
        pass  # persistence must never break a turn


def load_latest(cfg) -> dict | None:
    f = session_dir(cfg) / "latest.json"
    if not f.is_file():
        return None
    try:
        data = json.loads(f.read_text(errors="replace"))
        return data if isinstance(data.get("messages"), list) else None
    except (json.JSONDecodeError, OSError):
        return None


def load_session(cfg, session_id: str) -> dict | None:
    f = _session_file(cfg, session_id)
    if not f.is_file():
        return None
    try:
        data = json.loads(f.read_text(errors="replace"))
        return data if isinstance(data.get("messages"), list) else None
    except (json.JSONDecodeError, OSError):
        return None


def _summarize(data: dict) -> dict:
    msgs = [m for m in data.get("messages", []) if m.get("role") != "system"]
    first_user = ""
    for m in msgs:
        if m.get("role") == "user" and isinstance(m.get("content"), str):
            first_user = m["content"]
            break
    for marker in ("\n\n[Active goal:", "[PLAN MODE", "\n\n[Attached file:"):
        if marker in first_user:
            first_user = first_user.split(marker, 1)[0].strip()
    return {
        "session_id": data.get("session_id", ""),
        "ts": data.get("ts", 0),
        "n_messages": len(msgs),
        "summary": first_user[:90] or "(no user message yet)",
        "model": data.get("model", ""),
        "goal": data.get("goal", ""),
    }


def list_sessions(cfg, limit: int = 20) -> list[dict]:
    """One entry per distinct past conversation, most recent first."""
    d = session_dir(cfg)
    if not d.is_dir():
        return []
    out = []
    for f in d.glob("*.json"):
        if f.name == "latest.json":
            continue
        try:
            data = json.loads(f.read_text(errors="replace"))
        except (json.JSONDecodeError, OSError):
            continue
        if not isinstance(data.get("messages"), list):
            continue
        out.append(_summarize(data))
    out.sort(key=lambda s: s["ts"], reverse=True)
    return out[:limit]


def _apply(agent, ui, data: dict) -> dict | None:
    if data.get("tool_mode") != agent.cfg.resolved_tool_mode():
        ui.notice("that session used a different tool mode; starting "
                  "fresh instead.")
        return None
    # keep the freshly built system prompt; restore everything after it
    agent.messages = [agent.messages[0]] + \
        [m for m in data["messages"] if m.get("role") != "system"]
    agent.todos = data.get("todos") or []
    agent.input_history = list(data.get("input_history") or [])
    agent.goal = data.get("goal") or ""
    # resuming continues the SAME session file, not a new one
    agent.session_id = data.get("session_id") or _new_id()
    n = len(agent.messages) - 1
    when = time.strftime("%Y-%m-%d %H:%M",
                         time.localtime(float(data.get("ts", 0))))
    extra = ""
    if data.get("model") != agent.cfg.model:
        extra = f" (was {data.get('model')}, now {agent.cfg.model})"
    if agent.goal:
        extra += f" · active goal: {agent.goal}"
    ui.notice(f"resumed session from {when} — {n} message(s){extra}.")
    return data


def restore(agent, ui) -> dict | None:
    """Restore the most recent session for this project. Returns the
    loaded data (so a UI can replay the visible transcript), or None."""
    data = load_latest(agent.cfg)
    if not data:
        ui.notice("no previous session found for this project.")
        return None
    return _apply(agent, ui, data)


def restore_session(agent, ui, session_id: str) -> dict | None:
    """Restore a specific past session by id (used by /resume's picker)."""
    data = load_session(agent.cfg, session_id)
    if not data:
        ui.error(f"session not found: {session_id}")
        return None
    return _apply(agent, ui, data)
