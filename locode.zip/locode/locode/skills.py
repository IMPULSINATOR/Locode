"""Agent Skills — implementation of the open SKILL.md standard.

A skill is a folder containing a SKILL.md file: YAML frontmatter with
required `name` and `description`, then markdown instructions, optionally
bundled scripts/, references/ and assets/. Progressive disclosure, same as
Claude Code: only name+description are injected into the system prompt at
startup; the full body is loaded on demand via the `skill` tool; bundled
files are read only when the instructions point at them.

Spec: https://agentskills.io/specification
Discovery is compatible with Claude Code's locations (.claude/skills,
~/.claude/skills) in addition to locode's own.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

FRONTMATTER_RE = re.compile(r"\A---\s*\n(.*?)\n---\s*\n?", re.DOTALL)
NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")


@dataclass
class Skill:
    name: str
    description: str
    root: Path              # the skill folder
    source: str             # builtin | user | project | plugin:<name>
    body: str = ""          # loaded lazily

    def load_body(self) -> str:
        text = (self.root / "SKILL.md").read_text(errors="replace")
        m = FRONTMATTER_RE.match(text)
        return text[m.end():].strip() if m else text.strip()

    def bundled_files(self, cap: int = 40) -> list[str]:
        out: list[str] = []
        for p in sorted(self.root.rglob("*")):
            if p.is_file() and p.name != "SKILL.md":
                out.append(str(p.relative_to(self.root)))
                if len(out) >= cap:
                    break
        return out


def parse_frontmatter(text: str) -> tuple[dict, str]:
    """Return (metadata, body). Tolerates missing/broken frontmatter."""
    m = FRONTMATTER_RE.match(text)
    if not m:
        return {}, text.strip()
    raw, body = m.group(1), text[m.end():].strip()
    meta: dict = {}
    if yaml is not None:
        try:
            loaded = yaml.safe_load(raw)
            if isinstance(loaded, dict):
                meta = loaded
        except yaml.YAMLError:
            meta = {}
    if not meta:  # minimal fallback: top-level "key: value" lines
        for line in raw.splitlines():
            if ":" in line and not line.startswith((" ", "\t", "#")):
                k, _, v = line.partition(":")
                meta[k.strip()] = v.strip().strip("\"'")
    return meta, body


def _load_skill_dir(d: Path, source: str) -> Skill | None:
    f = d / "SKILL.md"
    if not f.is_file():
        return None
    try:
        meta, _ = parse_frontmatter(f.read_text(errors="replace"))
    except OSError:
        return None
    name = str(meta.get("name") or d.name).strip()
    desc = str(meta.get("description") or "").strip()
    if not desc:
        desc = "(no description provided)"
    if not NAME_RE.match(name):
        name = d.name  # be forgiving; the folder name is the fallback
    return Skill(name=name, description=desc[:1024], root=d.resolve(),
                 source=source)


def skill_search_dirs(cfg) -> list[tuple[Path, str]]:
    """(directory, source-label) pairs in precedence order — first wins."""
    from .plugins import discover_plugins  # local import avoids a cycle

    home = Path.home()
    dirs: list[tuple[Path, str]] = [
        (cfg.project_dir / ".locode" / "skills", "project"),
        (cfg.project_dir / ".claude" / "skills", "project"),
        (home / ".config" / "locode" / "skills", "user"),
        (home / ".claude" / "skills", "user"),
    ]
    for plugin in discover_plugins(cfg):
        dirs.append((plugin.root / "skills", f"plugin:{plugin.name}"))
    dirs.append((Path(__file__).parent / "skills_builtin", "builtin"))
    return dirs


def discover_skills(cfg) -> dict[str, Skill]:
    skills: dict[str, Skill] = {}
    for base, source in skill_search_dirs(cfg):
        if not base.is_dir():
            continue
        for child in sorted(base.iterdir()):
            if not child.is_dir():
                continue
            skill = _load_skill_dir(child, source)
            if skill and skill.name not in skills:   # earlier source wins
                skills[skill.name] = skill
    return skills


def render_skills_block(skills: dict[str, Skill]) -> str:
    if not skills:
        return ""
    lines = [
        "# Skills",
        "Installed instruction packs for specialized tasks. When the user's "
        "request matches a skill's description, call the `skill` tool with "
        "its name FIRST and follow the returned instructions before "
        "improvising.",
        "",
    ]
    for s in skills.values():
        desc = " ".join(s.description.split())
        if len(desc) > 220:
            desc = desc[:220] + "…"
        lines.append(f"- {s.name}: {desc}")
    return "\n".join(lines)
