"""Plugins — bundles of skills and custom commands.

A plugin is a folder containing any of:

    my-plugin/
    ├── .claude-plugin/plugin.json   (Claude Code layout)  — or plugin.json
    ├── skills/<name>/SKILL.md
    └── commands/<name>.md

locode reads the `skills/` and `commands/` folders of Claude Code-style
plugin repos as-is, so most published skill/command plugins install
unchanged. (Plugin pieces locode does not implement — MCP servers, hooks,
custom agents — are ignored with a notice.)

Install locations: ~/.config/locode/plugins/ (global) or
<project>/.locode/plugins/ (per-project).
"""
from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Plugin:
    name: str
    root: Path
    description: str = ""
    source: str = "user"    # user | project


def _read_manifest(root: Path) -> dict:
    for rel in (".claude-plugin/plugin.json", "plugin.json"):
        f = root / rel
        if f.is_file():
            try:
                data = json.loads(f.read_text(errors="replace"))
                if isinstance(data, dict):
                    return data
            except (json.JSONDecodeError, OSError):
                pass
    return {}


def plugin_bases(cfg) -> list[tuple[Path, str]]:
    return [
        (cfg.project_dir / ".locode" / "plugins", "project"),
        (Path.home() / ".config" / "locode" / "plugins", "user"),
    ]


def discover_plugins(cfg) -> list[Plugin]:
    out: list[Plugin] = []
    seen: set[str] = set()
    for base, source in plugin_bases(cfg):
        if not base.is_dir():
            continue
        for child in sorted(base.iterdir()):
            if not child.is_dir():
                continue
            manifest = _read_manifest(child)
            name = str(manifest.get("name") or child.name)
            if name in seen:
                continue
            seen.add(name)
            out.append(Plugin(
                name=name, root=child.resolve(),
                description=str(manifest.get("description", "")),
                source=source,
            ))
    return out


def _looks_like_git(src: str) -> bool:
    return (src.startswith(("http://", "https://", "git@", "ssh://"))
            or src.endswith(".git"))


def install_plugin(src: str, cfg, project: bool = False) -> str:
    base = plugin_bases(cfg)[0][0] if project else plugin_bases(cfg)[1][0]
    base.mkdir(parents=True, exist_ok=True)

    if _looks_like_git(src):
        name = src.rstrip("/").rsplit("/", 1)[-1].removesuffix(".git")
        dest = base / name
        if dest.exists():
            return f"error: {dest} already exists — remove it first."
        if not shutil.which("git"):
            return "error: git is not installed; clone manually into " + str(base)
        proc = subprocess.run(["git", "clone", "--depth", "1", src, str(dest)],
                              capture_output=True, text=True, timeout=300)
        if proc.returncode != 0:
            return f"error: git clone failed:\n{proc.stderr.strip()}"
    else:
        srcpath = Path(src).expanduser().resolve()
        if not srcpath.is_dir():
            return f"error: {srcpath} is not a directory."
        dest = base / srcpath.name
        if dest.exists():
            return f"error: {dest} already exists — remove it first."
        shutil.copytree(srcpath, dest)

    plugin = Plugin(name=dest.name, root=dest, **_manifest_kw(dest))
    n_skills = len(list((dest / "skills").glob("*/SKILL.md"))) \
        if (dest / "skills").is_dir() else 0
    n_cmds = len(list((dest / "commands").glob("*.md"))) \
        if (dest / "commands").is_dir() else 0
    ignored = [d for d in ("hooks", "agents", "mcp") if (dest / d).exists()]
    note = (f" (note: {', '.join(ignored)}/ present but not supported by "
            "locode — ignored)") if ignored else ""
    return (f"installed plugin '{plugin.name}' → {dest}\n"
            f"  {n_skills} skill(s), {n_cmds} command(s){note}\n"
            "restart locode or /clear to load it.")


def _manifest_kw(root: Path) -> dict:
    m = _read_manifest(root)
    return {"description": str(m.get("description", ""))}
