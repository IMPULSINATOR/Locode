"""Plugins — bundles of skills, commands, subagents, and hooks.

A plugin is a folder containing any of:

    my-plugin/
    ├── .claude-plugin/plugin.json   (Claude Code layout)  — or plugin.json
    ├── skills/<name>/SKILL.md
    ├── commands/<name>.md
    ├── agents/<name>.md
    └── hooks/hooks.json

locode reads all of these from Claude Code-style plugin repos as-is —
skills (skills.py), commands (commands.py), agents (agents.py), and hooks
(hooks.py) — so most published plugins install unchanged. The one piece
not implemented: MCP servers bundled with a plugin (`.mcp.json` / `mcp/`)
are ignored with a notice; MCP servers still work fine when configured
directly in locode.toml.

Install locations: ~/.config/locode/plugins/ (global) or
<project>/.locode/plugins/ (per-project).
"""
from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Plugin:
    name: str
    root: Path
    description: str = ""
    source: str = "user"    # user | project


def _read_manifest(root: Path) -> dict:
    for rel in (".claude-plugin/plugin.json", "plugin.json"):
        f = root / rel
        if f.is_file():
            try:
                data = json.loads(f.read_text(errors="replace"))
                if isinstance(data, dict):
                    return data
            except (json.JSONDecodeError, OSError):
                pass
    return {}


def plugin_bases(cfg) -> list[tuple[Path, str]]:
    return [
        (cfg.project_dir / ".locode" / "plugins", "project"),
        (Path.home() / ".config" / "locode" / "plugins", "user"),
    ]


def discover_plugins(cfg) -> list[Plugin]:
    out: list[Plugin] = []
    seen: set[str] = set()
    for base, source in plugin_bases(cfg):
        if not base.is_dir():
            continue
        for child in sorted(base.iterdir()):
            if not child.is_dir():
                continue
            manifest = _read_manifest(child)
            name = str(manifest.get("name") or child.name)
            if name in seen:
                continue
            seen.add(name)
            out.append(Plugin(
                name=name, root=child.resolve(),
                description=str(manifest.get("description", "")),
                source=source,
            ))
    return out


def _looks_like_git(src: str) -> bool:
    return (src.startswith(("http://", "https://", "git@", "ssh://"))
            or src.endswith(".git"))


def install_plugin(src: str, cfg, project: bool = False) -> str:
    base = plugin_bases(cfg)[0][0] if project else plugin_bases(cfg)[1][0]
    base.mkdir(parents=True, exist_ok=True)

    if _looks_like_git(src):
        name = src.rstrip("/").rsplit("/", 1)[-1].removesuffix(".git")
        dest = base / name
        if dest.exists():
            return f"error: {dest} already exists — remove it first."
        if not shutil.which("git"):
            return "error: git is not installed; clone manually into " + str(base)
        proc = subprocess.run(["git", "clone", "--depth", "1", src, str(dest)],
                              capture_output=True, text=True, timeout=300)
        if proc.returncode != 0:
            return f"error: git clone failed:\n{proc.stderr.strip()}"
    else:
        srcpath = Path(src).expanduser().resolve()
        if not srcpath.is_dir():
            return f"error: {srcpath} is not a directory."
        dest = base / srcpath.name
        if dest.exists():
            return f"error: {dest} already exists — remove it first."
        shutil.copytree(srcpath, dest)

    plugin = Plugin(name=dest.name, root=dest, **_manifest_kw(dest))
    n_skills = len(list((dest / "skills").glob("*/SKILL.md"))) \
        if (dest / "skills").is_dir() else 0
    n_cmds = len(list((dest / "commands").glob("*.md"))) \
        if (dest / "commands").is_dir() else 0
    has_mcp = (dest / ".mcp.json").exists() or (dest / "mcp").exists()
    note = (" (note: MCP servers present but not supported by "
            "locode — ignored)") if has_mcp else ""
    return (f"installed plugin '{plugin.name}' → {dest}\n"
            f"  {n_skills} skill(s), {n_cmds} command(s){note}\n"
            "restart locode or /clear to load it.")


def _manifest_kw(root: Path) -> dict:
    m = _read_manifest(root)
    return {"description": str(m.get("description", ""))}


# ============================================================ marketplace
#
# Claude Code's marketplace format: a git repo with a
# .claude-plugin/marketplace.json manifest listing available plugins,
# each with a `source` pointing at a subdirectory of the same repo (the
# common case — "./plugins/foo") or a separate git source. Schema
# verified against anthropics/claude-code's own marketplace.json and the
# official plugin-marketplaces docs. `/plugin install <name>@<marketplace>`
# is Claude Code's own command surface; locode mirrors it via
# `locode plugin install <name>@<marketplace>` (CLI) — see cli.py.
#
# Not implemented: the full github/url/git-subdir source-object schema
# with independent ref/sha pinning — only plain git URLs and in-repo
# relative paths, which covers every real marketplace found in practice.

MARKETPLACE_SCHEMA_NOTE = (
    "unofficial, reverse-engineered from anthropics/claude-code's own "
    "marketplace.json and the public plugin-marketplaces docs — not "
    "guaranteed to track every future change to the format")


@dataclass
class MarketplaceEntry:
    name: str
    description: str
    source: str
    category: str = ""
    version: str = ""


@dataclass
class Marketplace:
    name: str
    root: Path
    owner: str = ""
    description: str = ""
    plugin_root: str = ""
    entries: list[MarketplaceEntry] = field(default_factory=list)


def marketplaces_dir() -> Path:
    return Path.home() / ".config" / "locode" / "marketplaces"


def _read_marketplace_manifest(root: Path) -> dict:
    f = root / ".claude-plugin" / "marketplace.json"
    if not f.is_file():
        return {}
    try:
        data = json.loads(f.read_text(errors="replace"))
        return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError):
        return {}


def _parse_marketplace(d: Path) -> Marketplace | None:
    manifest = _read_marketplace_manifest(d)
    if not manifest or not manifest.get("plugins"):
        return None
    entries = []
    for p in manifest.get("plugins") or []:
        if not isinstance(p, dict) or not p.get("name"):
            continue
        entries.append(MarketplaceEntry(
            name=str(p["name"]),
            description=str(p.get("description", "")),
            source=str(p.get("source", "")),
            category=str(p.get("category", "")),
            version=str(p.get("version", "")),
        ))
    owner = manifest.get("owner") or {}
    owner_name = owner.get("name", "") if isinstance(owner, dict) else str(owner)
    return Marketplace(
        name=str(manifest.get("name") or d.name),
        root=d,
        owner=str(owner_name),
        description=str(manifest.get("description", "")),
        plugin_root=str((manifest.get("metadata") or {}).get("pluginRoot", "")),
        entries=entries,
    )


def add_marketplace(src: str, override_name: str = "") -> str:
    base = marketplaces_dir()
    base.mkdir(parents=True, exist_ok=True)

    if _looks_like_git(src):
        tmp_name = src.rstrip("/").rsplit("/", 1)[-1].removesuffix(".git")
        dest = base / f".fetching-{tmp_name}"
        if dest.exists():
            shutil.rmtree(dest, ignore_errors=True)
        if not shutil.which("git"):
            return "error: git is not installed; clone manually into " + str(base)
        proc = subprocess.run(["git", "clone", "--depth", "1", src, str(dest)],
                              capture_output=True, text=True, timeout=300)
        if proc.returncode != 0:
            shutil.rmtree(dest, ignore_errors=True)
            return f"error: git clone failed:\n{proc.stderr.strip()}"
    else:
        srcpath = Path(src).expanduser().resolve()
        if not srcpath.is_dir():
            return f"error: {srcpath} is not a directory."
        dest = base / f".fetching-{srcpath.name}"
        if dest.exists():
            shutil.rmtree(dest, ignore_errors=True)
        shutil.copytree(srcpath, dest)

    mp = _parse_marketplace(dest)
    if mp is None:
        shutil.rmtree(dest, ignore_errors=True)
        return (f"error: no valid .claude-plugin/marketplace.json with a "
                f"'plugins' list found at {src}")

    final_name = override_name or mp.name
    final = base / final_name
    if final.exists():
        shutil.rmtree(dest, ignore_errors=True)
        return (f"error: a marketplace named '{final_name}' is already "
                "added. Remove it first if you want to re-add it.")
    dest.rename(final)
    return (f"added marketplace '{final_name}'"
            + (f" ({mp.owner})" if mp.owner else "") +
            f" — {len(mp.entries)} plugin(s) available. "
            "Try: locode plugin search")


def list_marketplaces() -> list[Marketplace]:
    base = marketplaces_dir()
    if not base.is_dir():
        return []
    out = []
    for d in sorted(base.iterdir()):
        if not d.is_dir() or d.name.startswith("."):
            continue
        mp = _parse_marketplace(d)
        if mp is not None:
            out.append(mp)
    return out


def remove_marketplace(name: str) -> str:
    d = marketplaces_dir() / name
    if not d.is_dir():
        return f"error: no marketplace named '{name}'."
    shutil.rmtree(d)
    return f"removed marketplace '{name}'."


def search_marketplace_plugins(query: str = "") -> list[tuple[Marketplace,
                                                              MarketplaceEntry]]:
    """All (marketplace, entry) pairs whose name/description/category
    match `query` (case-insensitive substring; empty query = everything)."""
    q = query.strip().lower()
    out = []
    for mp in list_marketplaces():
        for entry in mp.entries:
            if not q or q in entry.name.lower() \
                    or q in entry.description.lower() \
                    or q in entry.category.lower():
                out.append((mp, entry))
    return out


def find_marketplace_plugin(
        plugin_name: str, marketplace_name: str = ""
        ) -> tuple[Marketplace, MarketplaceEntry] | None:
    for mp in list_marketplaces():
        if marketplace_name and mp.name != marketplace_name:
            continue
        for entry in mp.entries:
            if entry.name == plugin_name:
                return mp, entry
    return None


def _resolve_marketplace_source(mp: Marketplace, entry: MarketplaceEntry) -> str:
    """A plugin's `source` is either a git URL (installed independently)
    or a path relative to the marketplace repo (the common case)."""
    if _looks_like_git(entry.source):
        return entry.source
    rel = entry.source[2:] if entry.source.startswith("./") else entry.source
    root = mp.root
    if mp.plugin_root:
        pr = mp.plugin_root[2:] if mp.plugin_root.startswith("./") \
            else mp.plugin_root
        prefixed = (root / pr / rel)
        if prefixed.is_dir():
            return str(prefixed)
    return str(root / rel)


def install_from_marketplace(spec: str, cfg, project: bool = False) -> str:
    """spec is "plugin-name" or "plugin-name@marketplace-name" (Claude
    Code's own `/plugin install` syntax)."""
    if "@" in spec:
        plugin_name, marketplace_name = spec.split("@", 1)
    else:
        plugin_name, marketplace_name = spec, ""
    found = find_marketplace_plugin(plugin_name.strip(), marketplace_name.strip())
    if not found:
        names = sorted({e.name for mp in list_marketplaces() for e in mp.entries})
        avail = ", ".join(names) if names else "(none — add a marketplace first)"
        return (f"error: no plugin named '{plugin_name}' in any added "
                f"marketplace. Available: {avail}")
    mp, entry = found
    resolved = _resolve_marketplace_source(mp, entry)
    if not Path(resolved).exists() and not _looks_like_git(resolved):
        return (f"error: marketplace entry '{entry.name}' points at "
                f"'{entry.source}', which doesn't resolve to anything in "
                f"the '{mp.name}' checkout. The marketplace listing may be "
                "stale.")
    return install_plugin(resolved, cfg, project=project)
