"""Robust output parsing for local models.

Local models are messier than frontier APIs: they wrap thinking in <think>
tags, emit tool calls with trailing commas or single quotes, forget closing
tags, or put JSON in markdown fences. Everything here is defensive.

The prompted tool-call wire format is Hermes-style, which Qwen has used
since Qwen2 and which most open models have seen in training:

    <tool_call>
    {"name": "tool_name", "arguments": {"key": "value"}}
    </tool_call>
"""
from __future__ import annotations

import ast
import json
import re
from dataclasses import dataclass, field

THINK_RE = re.compile(r"<think>(.*?)</think>", re.DOTALL)
THINK_OPEN_RE = re.compile(r"<think>(.*)\Z", re.DOTALL)

TOOL_CALL_RE = re.compile(r"<tool_call>(.*?)</tool_call>", re.DOTALL)
TOOL_CALL_OPEN_RE = re.compile(r"<tool_call>(.*)\Z", re.DOTALL)
FENCED_JSON_RE = re.compile(
    r"```(?:json|tool_call|tool)?\s*\n(\{.*?\})\s*\n```", re.DOTALL
)


def strip_think(text: str) -> tuple[str, str]:
    """Return (visible_text, thinking). Handles unclosed <think> blocks."""
    if not text:
        return "", ""
    thoughts = THINK_RE.findall(text)
    cleaned = THINK_RE.sub("", text)
    m = THINK_OPEN_RE.search(cleaned)
    if m:  # model ran out of tokens mid-thought
        thoughts.append(m.group(1))
        cleaned = cleaned[: m.start()]
    return cleaned.strip(), "\n".join(t.strip() for t in thoughts if t.strip())


def loads_lenient(raw: str):
    """json.loads with fallbacks for common small-model mistakes."""
    s = raw.strip()
    # strip a stray fence
    if s.startswith("```"):
        s = re.sub(r"^```[a-zA-Z_]*\s*", "", s)
        s = re.sub(r"\s*```$", "", s)
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        pass
    # trailing commas:  {"a": 1,}  /  [1, 2,]
    s2 = re.sub(r",\s*([}\]])", r"\1", s)
    try:
        return json.loads(s2)
    except json.JSONDecodeError:
        pass
    # python-ish dicts: single quotes, True/False/None
    try:
        val = ast.literal_eval(s2)
        if isinstance(val, (dict, list, str, int, float, bool)) or val is None:
            return val
    except (ValueError, SyntaxError):
        pass
    raise ValueError(f"could not parse as JSON: {raw[:200]!r}")


@dataclass
class ParsedCall:
    name: str
    arguments: dict


@dataclass
class ParseResult:
    calls: list[ParsedCall] = field(default_factory=list)
    text: str = ""          # assistant prose with tool blocks removed
    errors: list[str] = field(default_factory=list)


def _coerce_call(obj) -> ParsedCall | None:
    if not isinstance(obj, dict):
        return None
    name = obj.get("name") or obj.get("tool") or obj.get("function")
    if isinstance(name, dict):  # {"function": {"name": ..., "arguments": ...}}
        obj = name
        name = obj.get("name")
    if not isinstance(name, str) or not name:
        return None
    args = (
        obj.get("arguments")
        if "arguments" in obj
        else obj.get("args", obj.get("parameters", {}))
    )
    if isinstance(args, str):
        try:
            args = loads_lenient(args)
        except ValueError:
            args = {"value": args}
    if not isinstance(args, dict):
        args = {}
    return ParsedCall(name=name, arguments=args)


def extract_tool_calls(text: str) -> ParseResult:
    """Pull Hermes-style tool calls (plus fallback formats) out of text."""
    res = ParseResult()
    if not text:
        return res

    remaining = text
    blocks: list[str] = []

    def _sub(m: re.Match) -> str:
        blocks.append(m.group(1))
        return ""

    remaining = TOOL_CALL_RE.sub(_sub, remaining)
    m = TOOL_CALL_OPEN_RE.search(remaining)  # unclosed final block
    if m:
        blocks.append(m.group(1))
        remaining = remaining[: m.start()]

    # fallback: fenced JSON objects that look like calls (only if no
    # explicit blocks were found — don't double-parse)
    if not blocks:
        for fm in FENCED_JSON_RE.finditer(remaining):
            candidate = fm.group(1)
            if '"name"' in candidate or "'name'" in candidate:
                blocks.append(candidate)
                remaining = remaining.replace(fm.group(0), "", 1)

    for raw in blocks:
        raw = raw.strip()
        if not raw:
            continue
        try:
            obj = loads_lenient(raw)
        except ValueError as e:
            res.errors.append(str(e))
            continue
        call = _coerce_call(obj)
        if call:
            res.calls.append(call)
        else:
            res.errors.append(f"tool_call block is not a name/arguments object: {raw[:120]!r}")

    res.text = remaining.strip()
    return res


def estimate_tokens(messages: list[dict]) -> int:
    """Cheap length heuristic (~4 chars/token) over an OpenAI message list."""
    total = 0
    for m in messages:
        total += 8  # per-message overhead
        c = m.get("content")
        if isinstance(c, str):
            total += len(c) // 4
        for tc in m.get("tool_calls") or []:
            fn = tc.get("function", {})
            total += (len(fn.get("name", "")) + len(fn.get("arguments", ""))) // 4
    return total


def truncate_middle(text: str, limit: int) -> str:
    """Keep head and tail when output is huge (Claude Code-style truncation)."""
    if len(text) <= limit:
        return text
    head = int(limit * 0.7)
    tail = limit - head
    omitted = len(text) - head - tail
    return (
        text[:head]
        + f"\n... [{omitted} characters truncated] ...\n"
        + text[-tail:]
    )
