"""MCP (Model Context Protocol) client — stdio transport.

The protocol Claude Code, Codex and friends use to plug external tool
servers into an agent. This client speaks JSON-RPC 2.0 over newline-
delimited stdio: spawn the server process, `initialize` handshake,
`tools/list` to discover tools, `tools/call` to invoke them.

Configure servers in locode.toml (same idea as Claude Code's .mcp.json):

    [mcp_servers.github]
    command = "npx"
    args = ["-y", "@modelcontextprotocol/server-github"]
    env = { GITHUB_TOKEN = "..." }

Each discovered tool registers as `mcp__<server>__<tool>` (Claude Code's
naming). MCP tools ask for approval by default — they are external code
with unknown side effects — with the usual "a = always this session".
Not implemented (yet): SSE / streamable-HTTP transports, resources,
prompts, sampling.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import threading
from typing import TYPE_CHECKING

from . import __version__
from .tools import Approval, ALLOW, ToolSpec

if TYPE_CHECKING:
    from .agent import Agent

PROTOCOL_VERSION = "2025-03-26"


class MCPError(RuntimeError):
    pass


class MCPServer:
    def __init__(self, name: str, command: str, args: list[str] | None = None,
                 env: dict[str, str] | None = None, timeout: float = 30.0):
        self.name = name
        self.command = command
        self.args = list(args or [])
        self.env = dict(env or {})
        self.timeout = timeout
        self.proc: subprocess.Popen | None = None
        self.tools: list[dict] = []
        self._id = 0
        self._lock = threading.Lock()
        self._pending: dict[int, dict] = {}
        self._cv = threading.Condition()

    # ------------------------------------------------------------ lifecycle

    def start(self) -> None:
        if shutil.which(self.command) is None and not os.path.exists(self.command):
            raise MCPError(f"command not found: {self.command}")
        self.proc = subprocess.Popen(
            [self.command, *self.args],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True, bufsize=1,
            env={**os.environ, **self.env},
        )
        threading.Thread(target=self._reader, daemon=True,
                         name=f"mcp-{self.name}").start()
        result = self._request("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {}},
            "clientInfo": {"name": "locode", "version": __version__},
        })
        if not isinstance(result, dict):
            raise MCPError(f"bad initialize response from {self.name}")
        self._notify("notifications/initialized", {})
        listed = self._request("tools/list", {})
        self.tools = list(listed.get("tools", [])) if isinstance(listed, dict) else []

    def close(self) -> None:
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=3)
            except (subprocess.TimeoutExpired, OSError):
                self.proc.kill()

    # ------------------------------------------------------------ transport

    def _reader(self) -> None:
        assert self.proc and self.proc.stdout
        for line in self.proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue
            if "id" in msg and ("result" in msg or "error" in msg):
                with self._cv:
                    self._pending[msg["id"]] = msg
                    self._cv.notify_all()
            # notifications from the server are ignored in v1

    def _send(self, payload: dict) -> None:
        if not self.proc or self.proc.poll() is not None:
            raise MCPError(f"MCP server '{self.name}' is not running")
        assert self.proc.stdin
        with self._lock:
            self.proc.stdin.write(json.dumps(payload) + "\n")
            self.proc.stdin.flush()

    def _request(self, method: str, params: dict):
        with self._lock:
            self._id += 1
            rid = self._id
        self._send({"jsonrpc": "2.0", "id": rid,
                    "method": method, "params": params})
        with self._cv:
            ok = self._cv.wait_for(lambda: rid in self._pending,
                                   timeout=self.timeout)
            if not ok:
                raise MCPError(
                    f"MCP '{self.name}' timed out on {method} "
                    f"({self.timeout:.0f}s)")
            msg = self._pending.pop(rid)
        if "error" in msg:
            err = msg["error"]
            raise MCPError(f"{err.get('message', 'error')} "
                           f"(code {err.get('code')})")
        return msg.get("result")

    def _notify(self, method: str, params: dict) -> None:
        self._send({"jsonrpc": "2.0", "method": method, "params": params})

    # ------------------------------------------------------------ tools

    def call_tool(self, tool: str, arguments: dict) -> str:
        result = self._request("tools/call",
                               {"name": tool, "arguments": arguments})
        if not isinstance(result, dict):
            return json.dumps(result, default=str)
        parts: list[str] = []
        for item in result.get("content", []):
            if isinstance(item, dict) and item.get("type") == "text":
                parts.append(str(item.get("text", "")))
            else:
                parts.append(json.dumps(item, default=str))
        text = "\n".join(p for p in parts if p) or "(empty result)"
        if result.get("isError"):
            text = "Error (from MCP server): " + text
        return text


# ---------------------------------------------------------------- registry

def _approve_mcp(server: str):
    def approve(agent: "Agent", args: dict) -> Approval:
        if agent.cfg.approval == "full-access":
            return ALLOW
        return Approval(
            "ask", f"external MCP tool (server '{server}')",
            preview=json.dumps(args, indent=2, default=str)[:2000])
    return approve


def start_servers(cfg, notify=None) -> dict[str, MCPServer]:
    """Start every configured server; report failures via notify()."""
    servers: dict[str, MCPServer] = {}
    for name, spec in (cfg.mcp_servers or {}).items():
        if not isinstance(spec, dict) or not spec.get("command"):
            continue
        srv = MCPServer(name=name, command=str(spec["command"]),
                        args=spec.get("args") or [],
                        env=spec.get("env") or {},
                        timeout=float(spec.get("timeout", 30)))
        try:
            srv.start()
            servers[name] = srv
        except (MCPError, OSError) as e:
            srv.close()
            if notify:
                notify(f"MCP server '{name}' failed to start: {e}")
    return servers


def mcp_tool_specs(servers: dict[str, MCPServer]) -> list[ToolSpec]:
    specs: list[ToolSpec] = []
    for sname, srv in servers.items():
        for tool in srv.tools:
            tname = str(tool.get("name", "")).strip()
            if not tname:
                continue
            full = f"mcp__{sname}__{tname}"
            desc = str(tool.get("description", "")) or f"{tname} (MCP)"
            schema = tool.get("inputSchema") or {"type": "object",
                                                 "properties": {}}

            def make_run(server: MCPServer, tool_name: str):
                def run(agent: "Agent", args: dict) -> str:
                    try:
                        return server.call_tool(tool_name, args)
                    except MCPError as e:
                        return f"Error: {e}"
                return run

            specs.append(ToolSpec(
                name=full,
                description=f"[MCP:{sname}] {desc}",
                parameters=schema,
                run=make_run(srv, tname),
                approve=_approve_mcp(sname),
            ))
    return specs
