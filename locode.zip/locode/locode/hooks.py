"""Hooks — run your own shell commands at agent lifecycle events.

Claude Code's hooks pattern: the event payload arrives as JSON on stdin,
and for blocking events an exit code of 2 vetoes the action (stderr is fed
back to the model as the reason). Configure in locode.toml:

    [hooks]
    user-prompt-submit = ["python .locode/hooks/check_prompt.py"]
    pre-tool-use       = ["python .locode/hooks/guard.py"]     # can block
    post-tool-use      = ["./log_tool.sh"]
    stop               = ["notify-send 'locode done'"]

Events and payloads:
    user-prompt-submit  {event, prompt}                    blocking
    pre-tool-use        {event, tool, arguments}           blocking
    post-tool-use       {event, tool, arguments, result}   non-blocking
    stop                {event, final}                     non-blocking
"""
from __future__ import annotations

import json
import subprocess

EVENTS = ("user-prompt-submit", "pre-tool-use", "post-tool-use", "stop")


def run_hooks(cfg, event: str, payload: dict) -> tuple[bool, str]:
    """Run all hooks for an event. Returns (blocked, message)."""
    cmds = (cfg.hooks or {}).get(event) or []
    if isinstance(cmds, str):
        cmds = [cmds]
    data = json.dumps({"event": event, **payload}, default=str)
    for cmd in cmds:
        try:
            proc = subprocess.run(
                cmd, shell=True, input=data, text=True,
                capture_output=True, timeout=60, cwd=cfg.project_dir)
        except subprocess.TimeoutExpired:
            return False, f"hook timed out: {cmd}"
        except OSError as e:
            return False, f"hook failed to run ({cmd}): {e}"
        if proc.returncode == 2:
            reason = (proc.stderr or proc.stdout or "").strip() \
                or f"blocked by hook: {cmd}"
            return True, reason[:2000]
    return False, ""
