"""Hooks — run your own shell commands at agent lifecycle events.

Two sources, merged:

1. `locode.toml`'s `[hooks]` table (unchanged from earlier versions):

    [hooks]
    user-prompt-submit = ["python .locode/hooks/check_prompt.py"]
    pre-tool-use       = ["python .locode/hooks/guard.py"]     # can block
    post-tool-use      = ["./log_tool.sh"]
    stop               = ["notify-send 'locode done'"]

2. Installed plugins' `hooks/hooks.json` (or inline `plugin.json["hooks"]`)
   — Claude Code's own plugin hook format, schema verified against the
   official plugins reference: PascalCase event names, an array of
   {"matcher": "<regex over the tool name>", "hooks": [{"type": "command",
   "command": "..."}]} groups per event, and `${CLAUDE_PLUGIN_ROOT}`
   substituted with the plugin's real install path:

    {"hooks": {"PreToolUse": [{"matcher": "Bash",
        "hooks": [{"type": "command",
                   "command": "${CLAUDE_PLUGIN_ROOT}/hooks/guard.sh"}]}]}}

   Only "type": "command" hooks are supported — "type": "prompt" (LLM-
   evaluated hooks, a materially different mechanism) is not implemented.

Claude Code's hook contract either way: the event payload arrives as JSON
on stdin, and for blocking events an exit code of 2 vetoes the action
(stderr is fed back to the model as the reason).

Events and payloads:
    user-prompt-submit  {event, prompt}                    blocking
    pre-tool-use        {event, tool, arguments}           blocking
    post-tool-use       {event, tool, arguments, result}   non-blocking
    stop                {event, final}                     non-blocking
"""
from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

EVENTS = ("user-prompt-submit", "pre-tool-use", "post-tool-use", "stop")

# Claude Code plugin hooks.json uses PascalCase event names; only these
# four map onto locode's own hook events (SessionStart/End, PreCompact,
# Notification, SubagentStop aren't implemented — locode has no matching
# lifecycle point for them yet).
_PASCAL_TO_KEBAB = {
    "UserPromptSubmit": "user-prompt-submit",
    "PreToolUse": "pre-tool-use",
    "PostToolUse": "post-tool-use",
    "Stop": "stop",
}

HookEntry = tuple  # (matcher: str | None, command: str)


def _read_plugin_hooks(plugin_root: Path) -> dict[str, list[HookEntry]]:
    """hooks/hooks.json wraps its event map in a top-level "hooks" key;
    an inline plugin.json["hooks"] value IS that event map already —
    both are handled here."""
    hf = plugin_root / "hooks" / "hooks.json"
    block = None
    if hf.is_file():
        try:
            data = json.loads(hf.read_text(errors="replace"))
        except (json.JSONDecodeError, OSError):
            data = None
        if isinstance(data, dict):
            block = data.get("hooks")
    if block is None:
        pj = plugin_root / ".claude-plugin" / "plugin.json"
        if pj.is_file():
            try:
                pdata = json.loads(pj.read_text(errors="replace"))
            except (json.JSONDecodeError, OSError):
                pdata = None
            if isinstance(pdata, dict):
                block = pdata.get("hooks")
    if not isinstance(block, dict):
        return {}

    root_str = str(plugin_root.resolve())
    out: dict[str, list[HookEntry]] = {}
    for pascal_event, groups in block.items():
        kebab = _PASCAL_TO_KEBAB.get(pascal_event)
        if kebab is None or not isinstance(groups, list):
            continue
        for group in groups:
            if not isinstance(group, dict):
                continue
            matcher = group.get("matcher")
            matcher = str(matcher) if matcher else None
            for h in group.get("hooks") or []:
                if not isinstance(h, dict) or h.get("type") != "command":
                    continue  # "type": "prompt" hooks are not supported
                cmd = str(h.get("command", "")).replace(
                    "${CLAUDE_PLUGIN_ROOT}", root_str)
                if cmd.strip():
                    out.setdefault(kebab, []).append((matcher, cmd))
    return out


def merge_hooks(cfg) -> dict[str, list[HookEntry]]:
    """The effective hook set for this project: locode.toml's [hooks]
    (no matcher — always applies) plus every installed plugin's declared
    hooks (matcher-aware). Call once (e.g. in Agent.__init__) and reuse —
    this does real file I/O per installed plugin."""
    merged: dict[str, list[HookEntry]] = {e: [] for e in EVENTS}
    for event, cmds in (cfg.hooks or {}).items():
        if event not in merged:
            continue
        cmds = [cmds] if isinstance(cmds, str) else cmds
        merged[event].extend((None, str(c)) for c in cmds)

    from .plugins import discover_plugins
    for plugin in discover_plugins(cfg):
        for event, entries in _read_plugin_hooks(plugin.root).items():
            merged.setdefault(event, []).extend(entries)
    return merged


def _matcher_hits(matcher: str | None, tool_name: str) -> bool:
    """Claude Code's matcher convention: "*", empty, or missing means
    "every tool" — NOT valid regex on its own ("*" alone raises
    `nothing to repeat`), so it must be special-cased before ever
    reaching re.search. Anything else is tried as regex; a matcher that
    fails to compile/run falls back to a plain substring test rather than
    crashing the tool call a hook was only supposed to observe."""
    if not matcher or matcher == "*":
        return True
    try:
        return bool(re.search(matcher, tool_name))
    except re.error:
        return matcher in tool_name


def run_hooks(effective: dict[str, list[HookEntry]], event: str,
             payload: dict, *, cwd=None) -> tuple[bool, str]:
    """Run every hook registered for `event` whose matcher (if any)
    matches payload["tool"]. Returns (blocked, message)."""
    entries = effective.get(event) or []
    if not entries:
        return False, ""
    tool_name = str(payload.get("tool", ""))
    data = json.dumps({"event": event, **payload}, default=str)
    for matcher, cmd in entries:
        if not _matcher_hits(matcher, tool_name):
            continue
        try:
            proc = subprocess.run(
                cmd, shell=True, input=data, text=True,
                capture_output=True, timeout=60, cwd=cwd)
        except subprocess.TimeoutExpired:
            return False, f"hook timed out: {cmd}"
        except OSError as e:
            return False, f"hook failed to run ({cmd}): {e}"
        if proc.returncode == 2:
            reason = (proc.stderr or proc.stdout or "").strip() \
                or f"blocked by hook: {cmd}"
            return True, reason[:2000]
    return False, ""
