"""LLM transport over any OpenAI-compatible server.

Tested against the /v1/chat/completions surface exposed by Ollama, vLLM,
SGLang, LM Studio and llama.cpp's llama-server. Handles the messy realities
of local serving: reasoning arriving either as a separate delta field
(vLLM/Ollama reasoning parsers) or as inline <think> tags, tool-call
fragments across stream chunks, and servers that reject streaming.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Callable

from openai import OpenAI, APIConnectionError, APIError, NOT_GIVEN

from .config import Config
from .parsing import loads_lenient, strip_think


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict
    raw_arguments: str = ""
    parse_error: str = ""


@dataclass
class Turn:
    text: str = ""            # visible assistant prose (think-stripped)
    thinking: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    raw_content: str = ""     # original content incl. any tool_call blocks


# Stream filter: routes inline <think> to the thinking channel and hides
# everything after <tool_call> from the live display (it gets rendered as a
# structured call afterwards). Handles tags split across chunks.
_TOKENS = ("<think>", "</think>", "<tool_call>")
_MAXTOK = max(len(t) for t in _TOKENS)


class StreamFilter:
    def __init__(self) -> None:
        self.buf = ""
        self.in_think = False
        self.hidden = False

    def feed(self, chunk: str) -> tuple[str, str]:
        self.buf += chunk
        visible, thinking = [], []
        while True:
            idx, tok = -1, ""
            for t in _TOKENS:
                i = self.buf.find(t)
                if i != -1 and (idx == -1 or i < idx):
                    idx, tok = i, t
            if idx == -1:
                safe = max(0, len(self.buf) - (_MAXTOK - 1))
                out, self.buf = self.buf[:safe], self.buf[safe:]
                self._route(out, visible, thinking)
                break
            self._route(self.buf[:idx], visible, thinking)
            self.buf = self.buf[idx + len(tok):]
            if tok == "<think>":
                self.in_think = True
            elif tok == "</think>":
                self.in_think = False
            elif tok == "<tool_call>":
                self.hidden = True
        return "".join(visible), "".join(thinking)

    def flush(self) -> tuple[str, str]:
        out, self.buf = self.buf, ""
        v, t = [], []
        self._route(out, v, t)
        return "".join(v), "".join(t)

    def _route(self, text: str, visible: list, thinking: list) -> None:
        if not text or self.hidden:
            return
        (thinking if self.in_think else visible).append(text)


class LLMClient:
    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg
        self.client = OpenAI(
            base_url=cfg.base_url, api_key=cfg.api_key or "local", timeout=600.0,
        )

    # ------------------------------------------------------------ public

    def chat(
        self,
        messages: list[dict],
        tools_schema: list[dict] | None,
        on_text: Callable[[str], None] | None = None,
        on_thinking: Callable[[str], None] | None = None,
    ) -> Turn:
        last_err: Exception | None = None
        for attempt in range(3):
            try:
                if self.cfg.stream:
                    try:
                        return self._chat_stream(
                            messages, tools_schema, on_text, on_thinking)
                    except (APIError, ValueError) as e:
                        # some servers 400 on stream+tools; retry non-stream
                        if attempt == 0:
                            return self._chat_blocking(messages, tools_schema)
                        raise
                return self._chat_blocking(messages, tools_schema)
            except APIConnectionError as e:
                last_err = e
                time.sleep(1.5 * (attempt + 1))
        raise ConnectionError(
            f"Cannot reach {self.cfg.base_url} — is your model server running? "
            f"({last_err})"
        )

    def summarize(self, messages: list[dict], instruction: str) -> str:
        """One-shot call used for context compaction (no tools)."""
        convo = messages + [{"role": "user", "content": instruction}]
        turn = self._chat_blocking(convo, None)
        return turn.text or turn.raw_content

    # ---------------------------------------------------------- internal

    def _params(self, messages, tools_schema, stream: bool) -> dict:
        p = dict(
            model=self.cfg.model,
            messages=messages,
            temperature=self.cfg.temperature,
            top_p=self.cfg.top_p,
            max_tokens=self.cfg.max_output_tokens,
            stream=stream,
        )
        p["tools"] = tools_schema if tools_schema else NOT_GIVEN
        return p

    def _chat_blocking(self, messages, tools_schema) -> Turn:
        resp = self.client.chat.completions.create(
            **self._params(messages, tools_schema, stream=False))
        msg = resp.choices[0].message
        raw = msg.content or ""
        text, inline_think = strip_think(raw)
        thinking = _reasoning_of(msg) or inline_think
        calls = [self._mk_call(tc.id, tc.function.name, tc.function.arguments)
                 for tc in (msg.tool_calls or [])]
        return Turn(text=text, thinking=thinking, tool_calls=calls,
                    raw_content=raw)

    def _chat_stream(self, messages, tools_schema, on_text, on_thinking) -> Turn:
        stream = self.client.chat.completions.create(
            **self._params(messages, tools_schema, stream=True))
        filt = StreamFilter()
        raw_parts: list[str] = []
        reasoning_parts: list[str] = []
        acc: dict[int, dict] = {}  # index -> {id, name, arguments}

        for chunk in stream:
            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta
            piece = getattr(delta, "content", None)
            if piece:
                raw_parts.append(piece)
                vis, thk = filt.feed(piece)
                if vis and on_text:
                    on_text(vis)
                if thk:
                    reasoning_parts.append(thk)
                    if on_thinking:
                        on_thinking(thk)
            r = _reasoning_of(delta)
            if r:
                reasoning_parts.append(r)
                if on_thinking:
                    on_thinking(r)
            for tc in getattr(delta, "tool_calls", None) or []:
                slot = acc.setdefault(
                    tc.index or 0, {"id": "", "name": "", "arguments": ""})
                if tc.id:
                    slot["id"] = tc.id
                if tc.function:
                    if tc.function.name:
                        slot["name"] += tc.function.name
                    if tc.function.arguments:
                        slot["arguments"] += tc.function.arguments

        vis, thk = filt.flush()
        if vis and on_text:
            on_text(vis)
        if thk:
            reasoning_parts.append(thk)
            if on_thinking:
                on_thinking(thk)

        raw = "".join(raw_parts)
        text, inline_think = strip_think(raw)
        if inline_think:
            reasoning_parts.append(inline_think)
        calls = [
            self._mk_call(v["id"] or f"call_{i}", v["name"], v["arguments"])
            for i, v in sorted(acc.items())
            if v["name"]
        ]
        return Turn(text=text,
                    thinking="".join(reasoning_parts).strip(),
                    tool_calls=calls, raw_content=raw)

    @staticmethod
    def _mk_call(cid: str, name: str, raw_args: str) -> ToolCall:
        raw_args = raw_args or ""
        try:
            args = loads_lenient(raw_args) if raw_args.strip() else {}
            if not isinstance(args, dict):
                args = {"value": args}
            return ToolCall(id=cid or "call_0", name=name, arguments=args,
                            raw_arguments=raw_args)
        except ValueError as e:
            return ToolCall(id=cid or "call_0", name=name, arguments={},
                            raw_arguments=raw_args, parse_error=str(e))


def _reasoning_of(obj) -> str:
    """Servers disagree on the reasoning field name; check the usual ones."""
    for attr in ("reasoning_content", "reasoning", "thinking"):
        val = getattr(obj, attr, None)
        if isinstance(val, str) and val:
            return val
    return ""
