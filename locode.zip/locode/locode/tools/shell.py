"""bash tool.

Claude Code keeps a persistent shell session; mini-SWE-agent showed a fresh
subprocess per command is nearly as capable and far more robust (no hung
sessions, no state corruption). We take the stateless route and tell the
model so: chain with && and use paths relative to the project root.
"""
from __future__ import annotations

import shutil
import subprocess
from typing import TYPE_CHECKING

from . import Approval, ALLOW, ToolSpec
from ..parsing import truncate_middle
from ..safety import classify_command

if TYPE_CHECKING:
    from ..agent import Agent

DESCRIPTION = """Run a shell command from the project root and return its output.

- Each call runs in a FRESH shell: `cd`, exports and variables do NOT persist
  between calls. Chain steps with `&&` or use paths from the project root.
- Prefer the dedicated read_file / write_file / edit_file / grep / glob tools
  over cat, sed -i, grep -r and find: they are safer and give better output.
- Long output is truncated in the middle. Avoid commands that page or wait
  for input (use `git --no-pager`, `head`, non-interactive flags).
"""


def shell_kind() -> str:
    for name in ("bash", "sh", "pwsh"):
        if shutil.which(name):
            return name
    return "powershell"   # Windows PowerShell 5.1 — always present on Windows


def _shell_argv(command: str) -> list[str]:
    kind = shell_kind()
    if kind == "bash":
        return ["bash", "-lc", command]
    if kind == "sh":
        return ["sh", "-c", command]
    return [kind, "-NoProfile", "-Command", command]


_WINDOWS_NOTES = {
    "pwsh": ("\nNOTE: no bash on this machine — commands run in PowerShell 7"
             " (pwsh). Use PowerShell syntax; both `;` and `&&` chain"
             " commands."),
    "powershell": ("\nNOTE: no bash on this machine — commands run in"
                   " Windows PowerShell 5.1. Use PowerShell syntax and chain"
                   " with `;` (NOT `&&`, which fails in 5.1)."),
}


def run_bash(agent: "Agent", args: dict) -> str:
    command = str(args.get("command", "")).strip()
    if not command:
        return "Error: empty command."
    timeout = int(args.get("timeout", agent.cfg.command_timeout))
    timeout = max(1, min(timeout, 600))
    try:
        proc = subprocess.run(
            _shell_argv(command),
            cwd=agent.cfg.project_dir,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return f"Error: command timed out after {timeout}s: {command}"
    except FileNotFoundError as e:
        return f"Error: shell not available: {e}"

    parts = []
    if proc.stdout:
        parts.append(proc.stdout.rstrip())
    if proc.stderr:
        parts.append("[stderr]\n" + proc.stderr.rstrip())
    body = "\n".join(parts) if parts else "(no output)"
    body = truncate_middle(body, agent.cfg.tool_result_limit)
    return f"exit code: {proc.returncode}\n{body}"


def approve_bash(agent: "Agent", args: dict) -> Approval:
    command = str(args.get("command", ""))
    risk = classify_command(command)
    mode = agent.cfg.approval

    if risk.level == "dangerous":
        if agent.cfg.dangerously_allow_all:
            return ALLOW
        return Approval("ask", f"DANGEROUS: {risk.reason}", preview=command)
    if mode == "read-only":
        return Approval("ask", "read-only mode: every command needs approval",
                        preview=command)
    if mode == "workspace-write":
        if risk.level == "risky":
            return Approval("ask", risk.reason, preview=command)
        return ALLOW
    # full-access
    return ALLOW


def bash_spec() -> ToolSpec:
    return ToolSpec(
        name="bash",
        description=DESCRIPTION + _WINDOWS_NOTES.get(shell_kind(), ""),
        parameters={
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute.",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Optional timeout in seconds (default 120, max 600).",
                },
            },
            "required": ["command"],
        },
        run=run_bash,
        approve=approve_bash,
    )
