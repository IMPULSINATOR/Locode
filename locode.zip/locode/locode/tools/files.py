"""File tools: read_file, write_file, edit_file, glob, grep.

edit_file uses Claude Code's exact-and-unique string replacement contract:
old_string must appear exactly once. This forces the model to actually read
the file first and quote it precisely — which is exactly the discipline
smaller local models need. Error messages are written to teach the model
how to recover, not just to fail.
"""
from __future__ import annotations

import difflib
import fnmatch
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING

from . import Approval, ALLOW, ToolSpec
from ..parsing import truncate_middle
from ..safety import path_in_project, resolve_in_project

if TYPE_CHECKING:
    from ..agent import Agent

SKIP_DIRS = {
    ".git", "node_modules", ".venv", "venv", "__pycache__", ".mypy_cache",
    ".pytest_cache", "dist", "build", ".next", "target", ".tox", ".idea",
}
MAX_LINE_CHARS = 2000


# ---------------------------------------------------------------- helpers

def _numbered(lines: list[str], start: int) -> str:
    out = []
    for i, line in enumerate(lines, start=start):
        if len(line) > MAX_LINE_CHARS:
            line = line[:MAX_LINE_CHARS] + " …[line truncated]"
        out.append(f"{i:>5}\u2192{line}")
    return "\n".join(out)


def _unified_diff(old: str, new: str, path: str) -> str:
    diff = difflib.unified_diff(
        old.splitlines(keepends=True),
        new.splitlines(keepends=True),
        fromfile=f"a/{path}", tofile=f"b/{path}",
    )
    return "".join(diff)


def _write_approval(agent: "Agent", target: Path, preview: str) -> Approval:
    mode = agent.cfg.approval
    if mode == "read-only":
        return Approval("deny",
                        "read-only mode: file writes are disabled. "
                        "Explain the change you would make instead.")
    inside = path_in_project(target, agent.cfg.project_dir)
    if not inside and mode != "full-access":
        return Approval("ask", f"write OUTSIDE project root: {target}",
                        preview=preview)
    if mode == "full-access" or inside:
        return ALLOW
    return Approval("ask", "file write", preview=preview)


# ---------------------------------------------------------------- read_file

def run_read(agent: "Agent", args: dict) -> str:
    target = resolve_in_project(str(args.get("path", "")), agent.cfg.project_dir)
    offset = max(1, int(args.get("offset", 1)))
    limit = int(args.get("limit", 2000))
    if not target.exists():
        parent = target.parent
        hint = ""
        if parent.is_dir():
            nearby = [p.name for p in list(parent.iterdir())[:15]]
            hint = f" Files in {parent}: {nearby}"
        return f"Error: {target} does not exist.{hint}"
    if target.is_dir():
        entries = sorted(p.name + ("/" if p.is_dir() else "")
                         for p in target.iterdir())[:200]
        return f"{target} is a directory:\n" + "\n".join(entries)
    try:
        text = target.read_text(errors="replace")
    except Exception as e:
        return f"Error reading {target}: {e}"
    lines = text.splitlines()
    window = lines[offset - 1: offset - 1 + limit]
    if not window:
        return f"{target} has {len(lines)} lines; offset {offset} is past the end."
    body = _numbered(window, offset)
    suffix = ""
    if offset - 1 + limit < len(lines):
        suffix = (f"\n… file continues ({len(lines)} lines total). "
                  f"Call read_file again with offset={offset + limit}.")
    return body + suffix


def read_file_spec() -> ToolSpec:
    return ToolSpec(
        name="read_file",
        description=(
            "Read a file, returning numbered lines like '  12→text'. The "
            "'N→' prefix is display-only: NEVER include it in edit_file "
            "strings. Use offset/limit for large files. Always read a file "
            "before editing it."
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string",
                         "description": "File path (relative to project root or absolute)."},
                "offset": {"type": "integer",
                           "description": "1-based line to start from (default 1)."},
                "limit": {"type": "integer",
                          "description": "Max lines to return (default 2000)."},
            },
            "required": ["path"],
        },
        run=run_read,
        approve=lambda a, args: ALLOW,
    )


# --------------------------------------------------------------- write_file

def run_write(agent: "Agent", args: dict) -> str:
    target = resolve_in_project(str(args.get("path", "")), agent.cfg.project_dir)
    content = str(args.get("content", ""))
    existed = target.exists()
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)
    except Exception as e:
        return f"Error writing {target}: {e}"
    n = content.count("\n") + (0 if content.endswith("\n") or not content else 1)
    verb = "Overwrote" if existed else "Created"
    return f"{verb} {target} ({n} lines)."


def approve_write(agent: "Agent", args: dict) -> Approval:
    target = resolve_in_project(str(args.get("path", "")), agent.cfg.project_dir)
    content = str(args.get("content", ""))
    old = target.read_text(errors="replace") if target.is_file() else ""
    preview = _unified_diff(old, content, str(target)) or f"(new file {target})"
    return _write_approval(agent, target, truncate_middle(preview, 4000))


def write_file_spec() -> ToolSpec:
    return ToolSpec(
        name="write_file",
        description=(
            "Create a file or fully overwrite an existing one. Parent "
            "directories are created automatically. For small changes to "
            "existing files prefer edit_file; use write_file for new files "
            "or full rewrites."
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Destination path."},
                "content": {"type": "string",
                            "description": "Complete file content to write."},
            },
            "required": ["path", "content"],
        },
        run=run_write,
        approve=approve_write,
    )


# ---------------------------------------------------------------- edit_file

def run_edit(agent: "Agent", args: dict) -> str:
    target = resolve_in_project(str(args.get("path", "")), agent.cfg.project_dir)
    old = args.get("old_string", "")
    new = args.get("new_string", "")
    replace_all = bool(args.get("replace_all", False))
    if not target.is_file():
        return f"Error: {target} does not exist. Use write_file to create it."
    if old == "":
        return "Error: old_string is empty. To create or overwrite a file use write_file."
    if old == new:
        return "Error: old_string and new_string are identical."
    text = target.read_text(errors="replace")
    count = text.count(old)
    if count == 0:
        stripped = old.strip()
        hint = ""
        if stripped and stripped in text:
            hint = (" A match ignoring leading/trailing whitespace exists — "
                    "copy the exact text (including indentation) from read_file, "
                    "without the 'N→' line-number prefix.")
        return (f"Error: old_string not found in {target}.{hint} "
                "Re-read the file and pass the exact current text.")
    if count > 1 and not replace_all:
        return (f"Error: old_string appears {count} times in {target}. "
                "Add surrounding lines to make it unique, or set "
                "replace_all=true to replace every occurrence.")
    new_text = text.replace(old, new) if replace_all else text.replace(old, new, 1)
    try:
        target.write_text(new_text)
    except Exception as e:
        return f"Error writing {target}: {e}"
    label = f"{count} occurrences" if replace_all and count > 1 else "1 edit"
    return f"Applied {label} to {target}."


def approve_edit(agent: "Agent", args: dict) -> Approval:
    target = resolve_in_project(str(args.get("path", "")), agent.cfg.project_dir)
    old, new = args.get("old_string", ""), args.get("new_string", "")
    preview = ""
    if target.is_file() and old:
        text = target.read_text(errors="replace")
        if old in text:
            preview = _unified_diff(
                text,
                text.replace(old, new) if args.get("replace_all")
                else text.replace(old, new, 1),
                str(target),
            )
    return _write_approval(agent, target, truncate_middle(preview, 4000))


def edit_file_spec() -> ToolSpec:
    return ToolSpec(
        name="edit_file",
        description=(
            "Replace text in a file. old_string must match the file EXACTLY "
            "(including whitespace and indentation) and must be unique in "
            "the file — include 2-3 surrounding lines of context to ensure "
            "uniqueness. Never include the 'N→' line-number prefix shown by "
            "read_file. Set replace_all=true to change every occurrence."
        ),
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File to edit."},
                "old_string": {"type": "string",
                               "description": "Exact existing text to replace."},
                "new_string": {"type": "string",
                               "description": "Replacement text."},
                "replace_all": {"type": "boolean",
                                "description": "Replace all occurrences (default false)."},
            },
            "required": ["path", "old_string", "new_string"],
        },
        run=run_edit,
        approve=approve_edit,
    )


# -------------------------------------------------------------------- glob

def run_glob(agent: "Agent", args: dict) -> str:
    pattern = str(args.get("pattern", "")).strip()
    if not pattern:
        return "Error: empty pattern."
    root = agent.cfg.project_dir
    try:
        matches = [p for p in root.glob(pattern) if p.is_file()]
    except (ValueError, NotImplementedError) as e:
        return f"Error: bad glob pattern {pattern!r}: {e}"
    matches = [m for m in matches
               if not any(part in SKIP_DIRS for part in m.parts)]
    matches.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    if not matches:
        return f"No files match {pattern!r} under {root}."
    shown = matches[:100]
    lines = [str(m.relative_to(root)) for m in shown]
    extra = f"\n… and {len(matches) - 100} more" if len(matches) > 100 else ""
    return "\n".join(lines) + extra


def glob_spec() -> ToolSpec:
    return ToolSpec(
        name="glob",
        description=(
            "Find files by glob pattern relative to the project root "
            "(e.g. 'src/**/*.py', '**/*.test.js'). Results are sorted by "
            "modification time, newest first. Use this instead of `find`."
        ),
        parameters={
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Glob pattern."},
            },
            "required": ["pattern"],
        },
        run=run_glob,
        approve=lambda a, args: ALLOW,
    )


# -------------------------------------------------------------------- grep

def _grep_python(root: Path, pattern: str, include: str | None,
                 ignore_case: bool, max_results: int) -> list[str]:
    try:
        rx = re.compile(pattern, re.IGNORECASE if ignore_case else 0)
    except re.error as e:
        return [f"Error: invalid regex {pattern!r}: {e}"]
    hits: list[str] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fname in filenames:
            if include and not fnmatch.fnmatch(fname, include):
                continue
            fpath = Path(dirpath) / fname
            try:
                if fpath.stat().st_size > 1_500_000:
                    continue
                with open(fpath, "rb") as fh:
                    head = fh.read(1024)
                    if b"\x00" in head:
                        continue
                text = fpath.read_text(errors="replace")
            except OSError:
                continue
            for i, line in enumerate(text.splitlines(), 1):
                if rx.search(line):
                    rel = fpath.relative_to(root)
                    hits.append(f"{rel}:{i}: {line.strip()[:200]}")
                    if len(hits) >= max_results:
                        return hits
    return hits


def run_grep(agent: "Agent", args: dict) -> str:
    pattern = str(args.get("pattern", ""))
    if not pattern:
        return "Error: empty pattern."
    rel = str(args.get("path", ".") or ".")
    include = args.get("include") or None
    ignore_case = bool(args.get("ignore_case", False))
    max_results = 100
    root = resolve_in_project(rel, agent.cfg.project_dir)
    if not root.exists():
        return f"Error: search path {root} does not exist."

    rg = shutil.which("rg")
    if rg:
        cmd = [rg, "--line-number", "--no-heading", "--color", "never",
               "--max-count", "20", "-S"]
        if ignore_case:
            cmd.append("-i")
        if include:
            cmd += ["--glob", include]
        cmd += ["-e", pattern, str(root)]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True,
                                  errors="replace", timeout=30)
            if proc.returncode in (0, 1):
                lines = proc.stdout.splitlines()[:max_results]
                if not lines:
                    return f"No matches for {pattern!r}."
                out = []
                for ln in lines:
                    out.append(ln.replace(str(agent.cfg.project_dir) + os.sep, "", 1)[:250])
                more = "\n… (truncated)" if len(proc.stdout.splitlines()) > max_results else ""
                return "\n".join(out) + more
        except (subprocess.TimeoutExpired, OSError):
            pass  # fall back to python

    hits = _grep_python(root if root.is_dir() else root.parent,
                        pattern, include, ignore_case, max_results)
    if not hits:
        return f"No matches for {pattern!r}."
    more = "\n… (truncated at 100 matches)" if len(hits) >= max_results else ""
    return "\n".join(hits) + more


def grep_spec() -> ToolSpec:
    return ToolSpec(
        name="grep",
        description=(
            "Search file contents with a regular expression. Returns "
            "'path:line: text' matches (max 100). Optional include glob "
            "filters filenames (e.g. '*.py'). Use this instead of "
            "`grep -r`; uses ripgrep when available."
        ),
        parameters={
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Regex to search for."},
                "path": {"type": "string",
                         "description": "Directory or file to search (default: project root)."},
                "include": {"type": "string",
                            "description": "Filename glob filter, e.g. '*.ts'."},
                "ignore_case": {"type": "boolean",
                                "description": "Case-insensitive search."},
            },
            "required": ["pattern"],
        },
        run=run_grep,
        approve=lambda a, args: ALLOW,
    )
