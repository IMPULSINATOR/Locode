"""ask_user — pause and ask the user a clarifying question.

Claude Code's AskUserQuestion pattern: the model calls this tool when a
decision genuinely needs the user's input, offering 2-5 suggested options;
the user picks one (arrow keys / number keys in the TUI, a number in the
plain REPL) or types a custom answer, and the choice flows back as the
tool result so the model can act on it.

In non-interactive contexts (one-shot `-p`, piped stdin) the tool returns
an instruction to proceed with best judgment instead of hanging.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from . import ALLOW, ToolSpec

if TYPE_CHECKING:
    from ..agent import Agent

MAX_OPTIONS = 5


def run_ask(agent: "Agent", args: dict) -> str:
    question = str(args.get("question", "")).strip()
    if not question:
        return "Error: 'question' is required and must be non-empty."
    raw = args.get("options") or []
    if not isinstance(raw, list):
        raw = [raw]
    options = [str(o).strip() for o in raw if str(o).strip()][:MAX_OPTIONS]

    answer = agent.ui.ask_user(question, options)
    if answer is None:
        return ("Error: the user is not available for questions in this "
                "mode. Proceed with your best judgment and clearly state "
                "the assumption you made.")
    if not answer.strip():
        return ("The user skipped the question without answering. Proceed "
                "with your best judgment and state your assumption in the "
                "final summary.")
    return f"The user answered: {answer.strip()}"


def ask_spec() -> ToolSpec:
    return ToolSpec(
        name="ask_user",
        description=(
            "Ask the user ONE clarifying question and wait for their "
            "answer. Use it only when a decision materially changes the "
            "work (ambiguous requirements, mutually exclusive designs, "
            "missing preferences) and the answer cannot reasonably be "
            "inferred from the project. Provide 2-5 short suggested "
            "options when natural — the user can always type a custom "
            "answer instead. Do NOT ask about things that are obvious, "
            "already stated, or cheap to reverse; prefer making progress "
            "with a stated assumption. Never chain many questions in a "
            "row — batch what you need into the fewest questions possible."
        ),
        parameters={
            "type": "object",
            "properties": {
                "question": {
                    "type": "string",
                    "description": "The clarifying question, one sentence.",
                },
                "options": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "2-5 short suggested answers (optional). "
                                   "A custom-answer field is always shown "
                                   "in addition to these.",
                },
            },
            "required": ["question"],
        },
        run=run_ask,
        approve=lambda a, args: ALLOW,
    )
