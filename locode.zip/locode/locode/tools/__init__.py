"""Tool registry.

Deliberately small, mirroring what actually carries Claude Code and Codex:
a shell, four file primitives, a todo list for planning, and one subagent.
Each tool declares an OpenAI-style JSON schema (used natively when the
server supports tool calling, and rendered into the system prompt in
prompted mode) plus an approval hook consulted by the agent loop.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from ..agent import Agent


@dataclass
class Approval:
    decision: str          # "allow" | "ask" | "deny"
    reason: str = ""
    preview: str = ""      # shown to the user when asking (e.g. a diff)


ALLOW = Approval("allow")


@dataclass
class ToolSpec:
    name: str
    description: str
    parameters: dict
    run: Callable[["Agent", dict], str]
    approve: Callable[["Agent", dict], Approval]

    def openai_schema(self) -> dict:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


def build_registry(cfg, *, subagent: bool = False,
                   with_skill_tool: bool = False) -> dict[str, ToolSpec]:
    """Build the toolset. Subagents get a read-only subset (and no task
    tool — subagents cannot spawn subagents, same rule as Claude Code)."""
    from . import ask, files, shell, skill, todo, task, web

    specs: list[ToolSpec] = [
        files.read_file_spec(),
        files.glob_spec(),
        files.grep_spec(),
    ]
    if with_skill_tool:
        specs.append(skill.skill_spec())
    if not subagent:
        specs += [
            shell.bash_spec(),
            files.write_file_spec(),
            files.edit_file_spec(),
            todo.todo_write_spec(),
            ask.ask_spec(),
            web.fetch_spec(),
        ]
        if (cfg.search or {}).get("provider"):
            specs.append(web.search_spec())
        if cfg.enable_subagent:
            specs.append(task.task_spec())
    return {s.name: s for s in specs}


def render_tools_for_prompt(registry: dict[str, ToolSpec]) -> str:
    """Describe tools inside the system prompt for prompted mode."""
    lines = []
    for s in registry.values():
        lines.append(f"### {s.name}")
        lines.append(s.description.strip())
        lines.append("Parameters (JSON Schema):")
        lines.append("```json")
        lines.append(json.dumps(s.parameters, indent=2))
        lines.append("```")
        lines.append("")
    return "\n".join(lines)
