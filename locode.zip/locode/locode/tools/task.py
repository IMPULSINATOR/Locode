"""task — spawn a read-only research subagent (Claude Code's dispatch_agent).

The subagent gets its own fresh context window and a read-only toolset
(read_file, glob, grep), explores the codebase, and returns only its final
summary to the parent — keeping large exploration out of the main context.
Subagents cannot spawn subagents (depth limit 1, same as Claude Code).
"""
from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from . import ALLOW, Approval, ToolSpec

if TYPE_CHECKING:
    from ..agent import Agent


def run_task(agent: "Agent", args: dict) -> str:
    from ..agent import Agent  # local import to avoid a cycle

    prompt = str(args.get("prompt", "")).strip()
    if not prompt:
        return "Error: task prompt is empty."
    if agent.depth >= 1:
        return "Error: subagents cannot spawn subagents. Do the work directly."

    agent_def = None
    wanted = str(args.get("agent", "")).strip().lower()
    if wanted:
        agent_def = agent.agent_defs.get(wanted)
        if agent_def is None:
            names = ", ".join(agent.agent_defs) or "(none installed)"
            return (f"Error: no subagent named {wanted!r}. "
                    f"Available: {names}. Omit 'agent' for the default "
                    "read-only researcher.")

    sub_cfg = replace(agent.cfg, max_steps=agent.cfg.subagent_max_steps,
                      enable_subagent=False)
    sub = Agent(sub_cfg, ui=agent.ui, depth=agent.depth + 1, subagent=True,
                agent_def=agent_def)
    label = str(args.get("description", "") or wanted or "research task")
    agent.ui.subagent_start(label)
    try:
        result = sub.run_turn(prompt)
    finally:
        agent.ui.subagent_end()
    if not result.strip():
        return "Subagent finished without a report."
    return f"Subagent report:\n{result.strip()}"


def task_spec() -> ToolSpec:
    return ToolSpec(
        name="task",
        description=(
            "Delegate a task to a subagent with its own fresh context. By "
            "default it can read_file/glob/grep but cannot modify anything, "
            "and only its final report comes back to you. If custom "
            "subagents are listed in your instructions, pass "
            "agent=\"<name>\" to use one. "
            "Use it for wide codebase exploration ('find where X is handled "
            "and summarize') so large file contents don't fill your own "
            "context. Give it a self-contained prompt with everything it "
            "needs to know."
        ),
        parameters={
            "type": "object",
            "properties": {
                "description": {"type": "string",
                                "description": "3-6 word label shown to the user."},
                "prompt": {"type": "string",
                           "description": "Full, self-contained instructions for the subagent."},
                "agent": {"type": "string",
                          "description": "Optional: name of a custom subagent to use."},
            },
            "required": ["prompt"],
        },
        run=run_task,
        approve=lambda a, args: ALLOW,
    )
