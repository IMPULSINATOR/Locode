"""todo_write — Claude Code's TodoWrite pattern.

A structured plan the model maintains and the UI renders as a checklist.
For small local models this is doubly valuable: it acts as an external
working memory that survives context compaction.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from . import ALLOW, ToolSpec

if TYPE_CHECKING:
    from ..agent import Agent

VALID_STATUS = ("pending", "in_progress", "completed")
MARK = {"pending": "[ ]", "in_progress": "[~]", "completed": "[x]"}


def render_todos(todos: list[dict]) -> str:
    if not todos:
        return "(todo list is empty)"
    return "\n".join(
        f"{MARK.get(t.get('status', 'pending'), '[ ]')} {t.get('content', '')}"
        for t in todos
    )


def run_todo_write(agent: "Agent", args: dict) -> str:
    raw = args.get("todos", [])
    if not isinstance(raw, list):
        return "Error: todos must be a list of {content, status} objects."
    todos: list[dict] = []
    for item in raw:
        if isinstance(item, str):
            item = {"content": item, "status": "pending"}
        if not isinstance(item, dict) or not str(item.get("content", "")).strip():
            continue
        status = item.get("status", "pending")
        if status not in VALID_STATUS:
            status = "pending"
        todos.append({"content": str(item["content"]).strip(), "status": status})
    agent.todos = todos
    return "Todo list updated:\n" + render_todos(todos)


def todo_write_spec() -> ToolSpec:
    return ToolSpec(
        name="todo_write",
        description=(
            "Replace your task plan with an updated list. Use for any task "
            "with 3+ steps: write the plan first, mark exactly one item "
            "in_progress while working on it, and mark items completed "
            "IMMEDIATELY when done. Statuses: pending | in_progress | "
            "completed."
        ),
        parameters={
            "type": "object",
            "properties": {
                "todos": {
                    "type": "array",
                    "description": "The complete, updated todo list.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "content": {"type": "string"},
                            "status": {
                                "type": "string",
                                "enum": list(VALID_STATUS),
                            },
                        },
                        "required": ["content", "status"],
                    },
                }
            },
            "required": ["todos"],
        },
        run=run_todo_write,
        approve=lambda a, args: ALLOW,
    )
