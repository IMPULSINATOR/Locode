"""skill — load a skill's full instructions on demand.

Level 2 of progressive disclosure: the system prompt carries only each
skill's name and description; calling this tool loads the SKILL.md body.
Bundled files (scripts/, references/, assets/) are level 3 — the model
reads or runs them with read_file/bash only when the instructions say to.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from . import ALLOW, ToolSpec

if TYPE_CHECKING:
    from ..agent import Agent


def run_skill(agent: "Agent", args: dict) -> str:
    name = str(args.get("name", "")).strip()
    skills = agent.skills
    if not skills:
        return "Error: no skills are installed."
    skill = skills.get(name)
    if skill is None:
        available = ", ".join(skills)
        return f"Error: no skill named {name!r}. Installed skills: {available}."
    try:
        body = skill.load_body()
    except OSError as e:
        return f"Error reading skill {name}: {e}"
    bundled = skill.bundled_files()
    files_note = ""
    if bundled:
        files_note = ("\n\nBundled files (relative to the skill directory — "
                      "read or run them only when the instructions above "
                      "call for it):\n" +
                      "\n".join(f"  {f}" for f in bundled))
    return (f"Skill '{skill.name}' loaded. Skill directory: {skill.root}\n"
            f"Follow these instructions for the current task:\n\n{body}"
            f"{files_note}")


def skill_spec() -> ToolSpec:
    return ToolSpec(
        name="skill",
        description=(
            "Load the full instructions of an installed skill by name. Call "
            "this BEFORE starting work whenever the user's request matches "
            "a skill listed in the '# Skills' section of your instructions, "
            "then follow what it says. Skills may bundle scripts and "
            "reference files inside their directory."
        ),
        parameters={
            "type": "object",
            "properties": {
                "name": {"type": "string",
                         "description": "The skill's name, exactly as listed."},
            },
            "required": ["name"],
        },
        run=run_skill,
        approve=lambda a, args: ALLOW,
    )
