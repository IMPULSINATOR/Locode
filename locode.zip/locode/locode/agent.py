"""The agent loop.

Every serious coding harness — Claude Code (the `nO` loop), Codex CLI's
turn engine, mini-SWE-agent — converges on the same core:

    while True:
        response = model(system + history)
        if no tool calls: break
        for call in calls: gate -> execute -> append result

Everything else in this package exists to serve that loop: prompts shape
what the model asks for, safety gates what gets executed, parsing survives
malformed output, and compaction keeps the history inside the window.
History is append-only (never rewrite earlier messages) — Codex's rule for
staying prompt-cache-friendly.
"""
from __future__ import annotations

import json
import re
from concurrent.futures import ThreadPoolExecutor

from .agents import discover_agents
from .commands import discover_commands
from .config import Config
from .hooks import run_hooks
from .llm import LLMClient, ToolCall, Turn
from .parsing import (estimate_tokens, extract_tool_calls, truncate_middle)
from .prompts import COMPACT_PROMPT, build_system_prompt
from .safety import resolve_in_project
from .skills import discover_skills
from .tools import build_registry

MALFORMED_HELP = (
    "Your tool call was malformed: {err}\n"
    "Emit exactly ONE block in this format and nothing after it:\n"
    '<tool_call>\n{{"name": "tool_name", "arguments": {{...}}}}\n</tool_call>'
)


PLAN_BLOCKED = frozenset({"write_file", "edit_file", "bash"})
PLAN_PREAMBLE = (
    "[PLAN MODE — research only. You may read files, search, and delegate "
    "read-only research, but you must NOT modify anything or run commands. "
    "Produce a concrete implementation plan: numbered steps, the exact "
    "files to change and how, verification steps, and risks. End with the "
    "plan itself; do not begin executing.]\n\n")
# default lives on Config.goal_rounds now; this is only a safety floor
# in case something constructs a loop without going through cfg
GOAL_ROUNDS_FALLBACK = 25


class Agent:
    def __init__(self, cfg: Config, ui, depth: int = 0,
                 subagent: bool = False, agent_def=None) -> None:
        self.cfg = cfg
        self.ui = ui
        self.depth = depth
        self.subagent = subagent
        self.agent_def = agent_def
        self.prompted = cfg.resolved_tool_mode() == "prompted"
        self.skills = discover_skills(cfg)
        self.commands = {} if subagent else discover_commands(cfg)
        self.agent_defs = {} if subagent else discover_agents(cfg)
        self.mcp_servers = {}
        if agent_def is not None and agent_def.tools:
            # custom subagent with an explicit tool whitelist
            base = build_registry(cfg, subagent=False,
                                  with_skill_tool=bool(self.skills))
            base.pop("task", None)
            self.registry = {k: v for k, v in base.items()
                             if k in agent_def.tools}
        else:
            self.registry = build_registry(
                cfg, subagent=subagent, with_skill_tool=bool(self.skills))
        if not subagent and cfg.mcp_servers:
            from . import mcp
            self.mcp_servers = mcp.start_servers(cfg, notify=ui.notice)
            for spec in mcp.mcp_tool_specs(self.mcp_servers):
                self.registry[spec.name] = spec
        self.llm = LLMClient(cfg)
        self.todos: list[dict] = []
        self.goal: str = ""
        self.input_history: list[str] = []
        self.session_id: str | None = None
        from .envdetect import build_env
        self.env_extra, self.env_notes = build_env(cfg.project_dir)
        self.session_allow: set[str] = set()
        self._last_call_key: str = ""
        self._repeat_count: int = 0
        core_override = None
        if agent_def is not None:
            core_override = (
                f"You are '{agent_def.name}', a subagent inside locode, a "
                "local coding agent. Only your final plain-text report is "
                "returned to the caller.\n\n" + agent_def.prompt)
        self.messages: list[dict] = [{
            "role": "system",
            "content": build_system_prompt(
                cfg, self.registry, prompted=self.prompted, subagent=subagent,
                skills=self.skills, agent_defs=self.agent_defs,
                core_override=core_override, env_notes=self.env_notes),
        }]

    def close(self) -> None:
        for srv in self.mcp_servers.values():
            srv.close()

    # ------------------------------------------------------------- turn

    def run_turn(self, user_text: str) -> str:
        """Process one user request to completion. Returns the final reply."""
        if not self.subagent:
            blocked, msg = run_hooks(self.cfg, "user-prompt-submit",
                                     {"prompt": user_text})
            if blocked:
                self.ui.notice(f"prompt blocked by hook: {msg}")
                return f"(blocked by hook: {msg})"
            if user_text.strip() and (not self.input_history
                                      or self.input_history[-1] != user_text):
                self.input_history.append(user_text)
            user_text = self._expand_mentions(user_text)
            if self.cfg.plan_mode:
                user_text = PLAN_PREAMBLE + user_text
            elif self.goal:
                user_text += (
                    "\n\n[Active goal: " + self.goal + " — keep working "
                    "toward it; when it is genuinely met and verified with "
                    "real checks, end your reply with GOAL_MET on its own "
                    "line.]")
        self.messages.append({"role": "user", "content": user_text})
        final = ""
        for step in range(self.cfg.max_steps):
            self._maybe_compact()
            self.ui.update_status(
                estimate_tokens(self.messages),
                self.cfg.context_tokens - self.cfg.max_output_tokens)
            turn = self._call_model()
            calls, prose = self._resolve_calls(turn)

            if not self.cfg.stream and prose:
                self.ui.assistant_text(prose)

            if not calls:
                if self.prompted and turn is not None and self._had_parse_errors:
                    # model tried to call a tool but botched the format
                    self.messages.append({"role": "assistant",
                                          "content": turn.text})
                    self.messages.append({
                        "role": "user",
                        "content": MALFORMED_HELP.format(
                            err=self._had_parse_errors)})
                    continue
                final = prose
                if prose:
                    self.messages.append(
                        {"role": "assistant", "content": prose})
                break

            self._append_assistant(turn, prose, calls)
            try:
                self._execute_calls(calls)
            except KeyboardInterrupt:
                self._fill_pending_results(calls, "[interrupted by user]")
                raise
            if self._repeat_count >= 5:
                self.ui.notice("stopping: the model repeated the same tool "
                               "call five times.")
                final = prose or "(stopped after repeated identical tool calls)"
                break
        else:
            self.ui.notice(f"reached max steps ({self.cfg.max_steps}); "
                           "ask me to continue if the task is unfinished.")
            final = "(max steps reached — say 'continue' to keep going)"
        if not self.subagent:
            run_hooks(self.cfg, "stop", {"final": final})
            if self.cfg.save_sessions:
                from . import sessions
                sessions.save(self)
        return final

    # ------------------------------------------- harness flows (drive)

    def drive(self, user_text: str) -> str:
        """UI entry point: one user submission plus the harness-level
        flows on top of run_turn — the plan approve→execute gate and the
        /goal auto-continue loop."""
        was_plan = self.cfg.plan_mode and not self.subagent
        final = self.run_turn(user_text)
        if was_plan and self.cfg.plan_mode:
            final = self._plan_gate(final)
        if self.goal and not self.cfg.plan_mode and not self.subagent:
            final = self._goal_loop(final)
        return final

    def _plan_gate(self, final: str) -> str:
        ans = self.ui.ask_user(
            "The plan is ready. Execute it now?",
            ["Yes — exit plan mode and execute the plan",
             "Not yet — keep planning/refining"])
        if ans and ans.startswith("Yes"):
            self.cfg.plan_mode = False
            self.ui.notice("plan approved — plan mode off, executing.")
            return self.run_turn(
                "The plan is approved. Execute it now, step by step, "
                "verifying each change as you go.")
        self.ui.notice("staying in plan mode — refine the plan, or "
                       "/plan off (Shift+Tab) to exit without executing.")
        return final

    def _goal_loop(self, final: str) -> str:
        cap = getattr(self.cfg, "goal_rounds", None) or GOAL_ROUNDS_FALLBACK
        rounds = 0
        while (self.goal and "GOAL_MET" not in (final or "")[-300:]
               and rounds < cap):
            rounds += 1
            self.ui.notice(
                f"goal not confirmed met — auto-continuing "
                f"(round {rounds}/{cap}, Esc stops): {self.goal}")
            final = self.run_turn(
                "The goal is not confirmed met yet. Continue working "
                "toward it now.")
        if self.goal and "GOAL_MET" in (final or "")[-300:]:
            self.ui.notice(f"goal met ✓ — cleared: {self.goal}")
            self.goal = ""
        elif self.goal and rounds >= cap:
            self.ui.notice(
                f"goal loop paused after {cap} rounds — send any "
                "message to resume, or /goal clear to drop it.")
        return final

    def side_question(self, question: str) -> str:
        """/btw — answer using the current context WITHOUT appending
        anything to the conversation history."""
        msgs = self.messages + [{
            "role": "user",
            "content": ("[Side question — answer directly and concisely "
                        "from what you already know or can see in this "
                        "conversation. Do NOT use tools; just answer:] "
                        + question)}]
        self.ui.wait_start()
        try:
            turn = self.llm.chat(
                msgs, tools_schema=[],
                on_text=(self.ui.stream_text if self.cfg.stream else None))
        finally:
            self.ui.wait_stop()
        if not self.cfg.stream and turn.text:
            self.ui.assistant_text(turn.text)
        self.ui.stream_end()
        return turn.text

    # -------------------------------------------------- @file mentions

    MENTION_RE = re.compile(r"(?<!\S)@([\w./\\~-]+)")

    def _expand_mentions(self, text: str) -> str:
        """Inline @path mentions as attached file contents (max 3)."""
        attachments: list[str] = []
        for m in self.MENTION_RE.finditer(text):
            if len(attachments) >= 3:
                break
            p = resolve_in_project(m.group(1), self.cfg.project_dir)
            if not p.is_file():
                continue
            try:
                content = p.read_text(errors="replace")
            except OSError:
                continue
            attachments.append(
                f"[Attached file: {p}]\n```\n"
                + truncate_middle(content, 12_000) + "\n```")
        if not attachments:
            return text
        return text + "\n\n" + "\n\n".join(attachments)

    # ----------------------------------------------------------- model IO

    def _call_model(self) -> Turn:
        tools_schema = (None if self.prompted else
                        [s.openai_schema() for s in self.registry.values()])
        on_text = self.ui.stream_text if (self.cfg.stream and not self.subagent) else None
        on_think = (self.ui.stream_thinking
                    if (self.cfg.stream and self.cfg.show_thinking
                        and not self.subagent) else None)
        self.ui.wait_start()
        try:
            turn = self.llm.chat(self.messages, tools_schema,
                                 on_text=on_text, on_thinking=on_think)
        finally:
            self.ui.wait_stop()
        if (turn.thinking and self.cfg.show_thinking
                and not (self.cfg.stream and not self.subagent)):
            self.ui.stream_thinking(turn.thinking)
        self.ui.stream_end()
        return turn

    def _resolve_calls(self, turn: Turn) -> tuple[list[ToolCall], str]:
        """Normalize native and prompted transports into (calls, prose)."""
        self._had_parse_errors = ""
        if not self.prompted:
            return turn.tool_calls, turn.text
        parsed = extract_tool_calls(turn.text)
        if parsed.errors:
            self._had_parse_errors = "; ".join(parsed.errors)
        calls = [ToolCall(id=f"call_{i}", name=c.name, arguments=c.arguments)
                 for i, c in enumerate(parsed.calls[:1])]  # one per message
        return calls, parsed.text

    def _append_assistant(self, turn: Turn, prose: str,
                          calls: list[ToolCall]) -> None:
        if self.prompted:
            # keep the raw tool_call block so the transcript the model sees
            # matches the format it was told to produce
            self.messages.append({"role": "assistant", "content": turn.text})
        else:
            self.messages.append({
                "role": "assistant",
                "content": prose or "",
                "tool_calls": [{
                    "id": c.id,
                    "type": "function",
                    "function": {
                        "name": c.name,
                        "arguments": c.raw_arguments or json.dumps(c.arguments),
                    },
                } for c in calls],
            })

    # -------------------------------------------------------- execution

    def _execute_calls(self, calls: list[ToolCall]) -> None:
        responses: list[tuple[ToolCall, str]] = []
        if self._parallelizable(calls):
            self.ui.notice(f"running {len(calls)} subagents in parallel…")
            for call in calls:
                self.ui.tool_call(call.name, _summarize_args(call))
            spec = self.registry["task"]
            with ThreadPoolExecutor(max_workers=min(4, len(calls))) as ex:
                futures = [ex.submit(self._safe_run, spec, c) for c in calls]
                results = [f.result() for f in futures]
            for call, result in zip(calls, results):
                result = truncate_middle(result, self.cfg.tool_result_limit)
                responses.append((call, result))
                self.ui.tool_result(call.name, result)
                self._record_result(call, result)
            if self.prompted and responses:
                blocks = "\n".join(
                    f'<tool_response name="{c.name}">\n{r}\n</tool_response>'
                    for c, r in responses)
                self.messages.append({"role": "user", "content": blocks})
            return
        for call in calls:
            result = self._run_one(call)
            result = truncate_middle(result, self.cfg.tool_result_limit)
            responses.append((call, result))
            self.ui.tool_result(call.name, result)
            self._record_result(call, result)

        if self.prompted and responses:
            blocks = "\n".join(
                f'<tool_response name="{c.name}">\n{r}\n</tool_response>'
                for c, r in responses)
            self.messages.append({"role": "user", "content": blocks})

    def _record_result(self, call: ToolCall, result: str) -> None:
        if not self.prompted:
            self.messages.append({
                "role": "tool",
                "tool_call_id": call.id,
                "content": result,
            })

    def _parallelizable(self, calls: list[ToolCall]) -> bool:
        """Fan out only when every call is a `task` whose subagent is
        read-only (default researcher, or a custom def without write
        tools) — then there are no approvals to interleave."""
        if self.prompted or len(calls) < 2 or "task" not in self.registry:
            return False
        if any(c.name != "task" or c.parse_error for c in calls):
            return False
        write_tools = {"write_file", "edit_file", "bash"}
        for c in calls:
            wanted = str(c.arguments.get("agent", "")).strip().lower()
            if wanted:
                adef = self.agent_defs.get(wanted)
                if adef is None or (adef.tools and
                                    write_tools & set(adef.tools)):
                    return False
        return True

    def _safe_run(self, spec, call: ToolCall) -> str:
        try:
            return spec.run(self, call.arguments)
        except KeyboardInterrupt:
            return "[interrupted by user]"
        except Exception as e:
            return f"Error: {call.name} raised {type(e).__name__}: {e}"

    def _fill_pending_results(self, calls: list[ToolCall], note: str) -> None:
        """Keep the transcript valid if execution is interrupted midway."""
        if self.prompted:
            self.messages.append({"role": "user", "content": note})
            return
        answered = {m.get("tool_call_id") for m in self.messages
                    if m.get("role") == "tool"}
        for c in calls:
            if c.id not in answered:
                self.messages.append({"role": "tool", "tool_call_id": c.id,
                                      "content": note})

    def _run_one(self, call: ToolCall) -> str:
        if call.parse_error:
            return (f"Error: arguments for {call.name} were not valid JSON "
                    f"({call.parse_error}). Retry with correct JSON.")
        spec = self.registry.get(call.name)
        if spec is None:
            return (f"Error: unknown tool {call.name!r}. Available tools: "
                    f"{', '.join(self.registry)}.")

        if self.cfg.plan_mode and (call.name in PLAN_BLOCKED
                                   or call.name.startswith("mcp__")):
            return ("Denied: plan mode is active — research and planning "
                    "only. Do not execute changes or run commands; finish "
                    "writing the plan instead.")

        # repetition guard
        key = call.name + json.dumps(call.arguments, sort_keys=True, default=str)
        if key == self._last_call_key:
            self._repeat_count += 1
        else:
            self._last_call_key, self._repeat_count = key, 1

        self.ui.tool_call(call.name, _summarize_args(call))

        approval = spec.approve(self, call.arguments)
        if approval.decision == "deny":
            return f"Denied: {approval.reason}"
        if approval.decision == "ask":
            dangerous = approval.reason.startswith("DANGEROUS")
            if call.name in self.session_allow and not dangerous:
                pass
            else:
                answer = self.ui.confirm(call.name, approval.reason,
                                         approval.preview)
                if answer == "a" and not dangerous:
                    self.session_allow.add(call.name)
                elif answer != "y":
                    return ("Denied by user. Do not retry this exact action; "
                            "ask the user how to proceed or take a different "
                            "approach.")
        blocked, msg = run_hooks(self.cfg, "pre-tool-use",
                                 {"tool": call.name,
                                  "arguments": call.arguments})
        if blocked:
            return (f"Blocked by a user-configured hook: {msg}. "
                    "Do not retry this exact action.")
        try:
            out = spec.run(self, call.arguments)
        except KeyboardInterrupt:
            raise
        except Exception as e:  # a tool bug must not kill the session
            out = f"Error: {call.name} raised {type(e).__name__}: {e}"
        run_hooks(self.cfg, "post-tool-use",
                  {"tool": call.name, "arguments": call.arguments,
                   "result": out[:4000]})
        if self._repeat_count >= 3:
            out += ("\n[system note: you have now made this exact call "
                    f"{self._repeat_count} times with the same result. "
                    "Change your approach.]")
        return out

    # -------------------------------------------------------- compaction

    def _maybe_compact(self) -> None:
        budget = self.cfg.context_tokens - self.cfg.max_output_tokens
        if estimate_tokens(self.messages) < self.cfg.compact_threshold * budget:
            return
        if len(self.messages) <= 6:
            return
        self.compact()

    def compact(self, instructions: str | None = None) -> None:
        """Summarize older history into a continuation note. Optional
        `instructions` focus the summary (/compact <focus>)."""
        self.ui.notice("compacting older history…" if instructions
                       else "context is filling up — compacting older "
                            "history…")
        cut = self._find_cut()
        head, tail = self.messages[1:cut], self.messages[cut:]
        prompt = COMPACT_PROMPT
        if instructions:
            prompt += ("\n\nAdditionally, focus the summary especially "
                       "on: " + instructions)
        try:
            summary = self.llm.summarize(
                [self.messages[0]] + head, prompt)
        except Exception as e:
            self.ui.notice(f"compaction model call failed ({e}); "
                           "hard-truncating instead.")
            summary = "(summary unavailable — older history was truncated)"
        bridge = {
            "role": "user",
            "content": ("[The session was compacted. Summary of everything "
                        "so far:]\n" + summary +
                        "\n[Conversation continues below.]"),
        }
        self.messages = [self.messages[0], bridge] + tail

    def _find_cut(self) -> int:
        """Find an index that keeps the last few messages and never splits a
        native assistant-tool_calls/tool-result pair."""
        kept = 0
        for i in range(len(self.messages) - 1, 0, -1):
            kept += 1
            if self.messages[i].get("role") == "user" and kept >= 4:
                return i
        return max(1, len(self.messages) - 1)


def _summarize_args(call: ToolCall) -> str:
    a = call.arguments
    if call.name == "bash":
        return str(a.get("command", ""))[:120]
    if call.name in ("read_file", "write_file", "edit_file"):
        return str(a.get("path", ""))
    if call.name == "grep":
        return f"/{a.get('pattern', '')}/" + (f" in {a['path']}" if a.get("path") else "")
    if call.name == "glob":
        return str(a.get("pattern", ""))
    if call.name == "task":
        return str(a.get("description", a.get("prompt", "")))[:80]
    if call.name == "todo_write":
        items = a.get("todos", [])
        return f"{len(items)} item(s)" if isinstance(items, list) else ""
    txt = json.dumps(a, default=str)
    return txt[:100] + ("…" if len(txt) > 100 else "")
