"""Custom subagents — Claude Code's `.claude/agents` pattern.

An agent definition is a markdown file with frontmatter:

    ---
    name: code-reviewer
    description: Reviews diffs for bugs and style issues. Use after edits.
    tools: read_file, glob, grep          # optional — default read-only set
    ---
    You are a meticulous code reviewer. For the given files...

The body becomes the subagent's system prompt core. `tools:` whitelists
which tools it may use (task itself is never allowed — no recursion). The
main agent sees each definition's name+description and delegates with
`task(agent="code-reviewer", prompt=...)`.

Locations (first name wins): <project>/.locode/agents, <project>/.claude/agents,
~/.config/locode/agents, ~/.claude/agents, <plugin>/agents.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .skills import parse_frontmatter

DEFAULT_TOOLS = ("read_file", "glob", "grep", "skill")
NEVER = {"task"}  # subagents cannot spawn subagents


@dataclass
class AgentDef:
    name: str
    description: str
    prompt: str
    tools: list[str] | None      # None -> read-only default set
    source: str


def _parse_tools(raw) -> list[str] | None:
    if raw is None:
        return None
    if isinstance(raw, str):
        items = [t.strip() for t in raw.split(",")]
    elif isinstance(raw, list):
        items = [str(t).strip() for t in raw]
    else:
        return None
    items = [t for t in items if t and t not in NEVER]
    return items or None


def agent_search_dirs(cfg) -> list[tuple[Path, str]]:
    from .plugins import discover_plugins

    home = Path.home()
    dirs = [
        (cfg.project_dir / ".locode" / "agents", "project"),
        (cfg.project_dir / ".claude" / "agents", "project"),
        (home / ".config" / "locode" / "agents", "user"),
        (home / ".claude" / "agents", "user"),
    ]
    for plugin in discover_plugins(cfg):
        dirs.append((plugin.root / "agents", f"plugin:{plugin.name}"))
    return dirs


def discover_agents(cfg) -> dict[str, AgentDef]:
    out: dict[str, AgentDef] = {}
    for base, source in agent_search_dirs(cfg):
        if not base.is_dir():
            continue
        for f in sorted(base.glob("*.md")):
            try:
                meta, body = parse_frontmatter(f.read_text(errors="replace"))
            except OSError:
                continue
            name = str(meta.get("name") or f.stem).strip().lower()
            if not name or name in out or not body.strip():
                continue
            out[name] = AgentDef(
                name=name,
                description=str(meta.get("description", "")).strip()
                or "(no description)",
                prompt=body.strip(),
                tools=_parse_tools(meta.get("tools")),
                source=source,
            )
    return out


def render_agents_block(agents: dict[str, AgentDef]) -> str:
    if not agents:
        return ""
    lines = [
        "# Custom subagents",
        "Delegate with the task tool by passing agent=\"<name>\" when the "
        "job matches a description below. Each runs with its own context "
        "and returns only a report.",
        "",
    ]
    for a in agents.values():
        desc = " ".join(a.description.split())[:200]
        lines.append(f"- {a.name}: {desc}")
    return "\n".join(lines)
