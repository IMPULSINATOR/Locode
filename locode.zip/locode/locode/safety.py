"""Safety: command risk classification + workspace path jail.

Codex CLI enforces sandboxing at the OS level (Seatbelt / Landlock /
bubblewrap); Claude Code classifies commands and gates them behind a
permission system at the application level. A portable pure-Python harness
can't do kernel sandboxing, so we take the Claude Code route: classify every
command, gate by approval mode, and confine file tools to the project root.
This is a seatbelt, not a cage — review what you approve.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

# Patterns that should force a confirmation *even in full-access mode*.
DANGEROUS_PATTERNS: list[tuple[str, str]] = [
    # Windows / PowerShell equivalents
    (r"(?i)\b(rd|rmdir)\s+(/s\b\s*)+(/q\s+)?[A-Za-z]:[\\/]?\s*$",
     "recursive delete of a drive root"),
    (r"(?i)\bremove-item\b.*-recurse\b.*"
     r"([A-Za-z]:[\\/]?\s*$|\$env:USERPROFILE|\$HOME|C:\\Users\\?\s*$)",
     "recursive delete of a drive root or user profile"),
    (r"(?i)\bdel\s+(/[a-z]\s+)*[A-Za-z]:[\\/]\*", "bulk delete at a drive root"),
    (r"(?i)\bformat(\.com)?\s+[A-Za-z]:", "format a drive"),
    (r"(?i)\bdiskpart\b", "raw disk partitioning"),
    (r"(?i)\b(stop|restart)-computer\b", "power-cycle the machine"),
    (r"(?i)\biex\s*\(\s*(iwr|invoke-webrequest|invoke-restmethod)\b",
     "pipe remote script into a shell"),
    (r"(?i)\b(iwr|invoke-webrequest|invoke-restmethod)\b[^|;&]*\|\s*iex\b",
     "pipe remote script into a shell"),
    (r"(?i)\breg\s+delete\s+HK(LM|CU)\b.*\s/f\b",
     "force-delete a registry tree"),
    (r"\brm\s+(-[a-zA-Z]*r[a-zA-Z]*f|-[a-zA-Z]*f[a-zA-Z]*r)\b.*\s(/|~|\$HOME)(\s|$)",
     "recursive force-delete of home or filesystem root"),
    (r"\brm\s+-rf?\s+/\s*$", "delete filesystem root"),
    (r"\bmkfs(\.\w+)?\b", "format a filesystem"),
    (r"\bdd\b.*\bof=/dev/", "raw write to a block device"),
    (r">\s*/dev/sd[a-z]", "raw write to a block device"),
    (r":\(\)\s*\{.*\};\s*:", "fork bomb"),
    (r"\b(shutdown|reboot|poweroff|halt)\b", "power-cycle the machine"),
    (r"\bchmod\s+(-R\s+)?777\s+/(\s|$)", "world-writable filesystem root"),
    (r"\b(curl|wget)\b[^|;&]*\|\s*(sudo\s+)?(ba)?sh\b", "pipe remote script into a shell"),
]

# Patterns that need a look in workspace-write mode but are fine to allow.
RISKY_PATTERNS: list[tuple[str, str]] = [
    # Windows / PowerShell
    (r"(?i)\bremove-item\b.*-recurse", "recursive delete"),
    (r"(?i)\b(rd|rmdir)\s+/s\b", "recursive delete"),
    (r"(?i)\bdel\s+/[sf]", "bulk delete"),
    (r"(?i)\bset-executionpolicy\b", "changes script execution policy"),
    (r"(?i)\btaskkill\s+/f", "force-kill processes"),
    (r"\bsudo\b", "elevated privileges"),
    (r"\brm\s+-[a-zA-Z]*r", "recursive delete"),
    (r"\bgit\s+push\b.*(--force|-f)\b", "force push"),
    (r"\bgit\s+(reset\s+--hard|clean\s+-[a-zA-Z]*f)", "discard local changes"),
    (r"\bgit\s+push\b", "push to a remote"),
    (r"\b(pip|pip3|npm|pnpm|yarn|cargo|apt|apt-get|brew|uv)\s+(install|add|remove|uninstall|upgrade)\b",
     "modify installed packages"),
    (r"\bdocker\s+(rm|rmi|system\s+prune)\b", "remove docker resources"),
    (r"\bkill(all)?\b", "kill processes"),
    (r"\bcrontab\b", "modify scheduled jobs"),
    (r"[>]{1,2}\s*(/etc/|/usr/|/boot/|~/\.(bashrc|profile|zshrc|ssh))", "write to system/shell config"),
    (r"\bchown\b|\bchmod\s+-R\b", "recursive ownership/permission change"),
]


@dataclass
class Risk:
    level: str            # "safe" | "risky" | "dangerous"
    reason: str = ""


def classify_command(command: str) -> Risk:
    cmd = command.strip()
    for pat, why in DANGEROUS_PATTERNS:
        if re.search(pat, cmd):
            return Risk("dangerous", why)
    for pat, why in RISKY_PATTERNS:
        if re.search(pat, cmd):
            return Risk("risky", why)
    return Risk("safe")


def path_in_project(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def resolve_in_project(raw: str, root: Path) -> Path:
    """Resolve a model-supplied path against the project root."""
    p = Path(raw).expanduser()
    if not p.is_absolute():
        p = root / p
    return p.resolve()
