"""Training-data generation for fine-tuning local models on locode.

Design principles (why this isn't just "an LLM writing examples"):

1. REAL EXECUTION — every trajectory is produced by running the actual
   locode Agent against a real temp repo. Tool results in the data are
   what the tools actually returned, never hallucinated.
2. VERIFICATION / REJECTION SAMPLING — each task template ships a
   programmatic verifier (tests pass, file contains X, output matches).
   Trajectories that fail are discarded, so the dataset only contains
   demonstrably correct behavior.
3. TWO TEACHERS — a deterministic ORACLE (knows the answer because it
   built the repo; free, instant, format-perfect) for protocol/format
   training, and optionally a real TEACHER LLM endpoint (e.g. Qwen 3.6
   27B on vLLM) for distillation-style SFT with the same verification.
4. DUAL EXPORT — native format ({"messages": [... tool_calls ...],
   "tools": [...]}) for models trained with structured function calling,
   and prompted format (Hermes-style <tool_call> text) matching locode's
   prompted mode, with optional malformed→corrected self-heal augmentation.

What SFT on this data can and cannot do: it teaches the HARNESS PROTOCOL
(tool selection, exact-match edits, todo discipline, plan-mode compliance,
GOAL_MET, ask_user, recovering from Denied/Errors) extremely well; it does
NOT make the base model smarter at algorithms. Pick the strongest base you
can serve.

Usage:
    locode datagen --out data/ --count 500 --seed 7
    locode datagen --out data/ --count 2000 \
        --teacher-url http://localhost:8000/v1 --teacher-model qwen3.6-27b
"""
from __future__ import annotations

import hashlib
import json
import random
import shutil
import string
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from .agent import MALFORMED_HELP, Agent
from .config import Config
from .llm import LLMClient, ToolCall, Turn
from .ui import UI

# ------------------------------------------------------------ plumbing


class ScriptedLLM:
    """Feeds pre-planned oracle turns into the real Agent loop."""

    def __init__(self, turns: list[Turn]):
        self.turns = list(turns)

    def chat(self, messages, tools_schema, on_text=None, on_thinking=None):
        if not self.turns:
            return Turn(text="Done.")
        return self.turns.pop(0)

    def summarize(self, messages, instruction):  # pragma: no cover
        return "(summary)"


def _quiet_ui() -> UI:
    return UI(interactive=False, quiet=True)


def _tc(i: int, name: str, args: dict) -> ToolCall:
    return ToolCall(id=f"call_{i}", name=name, arguments=args,
                    raw_arguments=json.dumps(args))


def _slug(rng: random.Random, n: int = 6) -> str:
    return "".join(rng.choice(string.ascii_lowercase) for _ in range(n))


REPO_NAMES = ["invoicer", "webshop", "taskly", "parksys", "loanapi",
              "chatlog", "metrics", "gateway", "ledger", "notify"]


@dataclass
class Sample:
    template: str
    params: dict
    messages: list[dict]
    tools: list[dict]
    project_dir: str
    fake_dir: str
    ok: bool = True

    def key(self) -> str:
        return hashlib.sha1(json.dumps(
            [self.template, self.params, self.fake_dir], sort_keys=True,
            default=str).encode()).hexdigest()


@dataclass
class Template:
    name: str
    build: Callable          # (rng, repo: Path) -> params dict
    prompt: Callable         # (rng, params) -> user prompt str
    oracle: Callable         # (params) -> list[Turn]
    verify: Callable         # (repo, final, msgs, params) -> bool
    setup_agent: Callable | None = None   # (agent, params) -> None
    weight: int = 3


# --------------------------------------------------------- task templates

def _write(repo: Path, rel: str, text: str) -> None:
    p = repo / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text)


# 1. create a script and run it -------------------------------------------

def t_create_build(rng, repo):
    name = _slug(rng)
    word = rng.choice(["hello", "namaste", "ready", "systems-go", "pong"])
    _write(repo, "README.md", f"# {repo.name}\nUtility scripts live here.\n")
    return {"file": f"{name}.py", "word": word}


def t_create_prompt(rng, p):
    return rng.choice([
        "create {file} that prints {word} and run it to confirm",
        "make a script {file} which outputs {word}, then execute it",
        "I need {file} printing exactly {word} — write and verify it",
    ]).format(**p)


def t_create_oracle(p):
    code = f'print("{p["word"]}")\n'
    return [
        Turn(text="", tool_calls=[_tc(1, "write_file",
             {"path": p["file"], "content": code})]),
        Turn(text="", tool_calls=[_tc(2, "bash",
             {"command": f"python {p['file']}"})]),
        Turn(text=f"Created `{p['file']}` and ran it — it prints "
                  f"`{p['word']}` as required."),
    ]


def t_create_verify(repo, final, msgs, params):
    f = repo / list(repo.glob("*.py"))[0].name if list(repo.glob("*.py")) \
        else None
    return f is not None and any(
        m.get("role") == "tool" and "Traceback" not in m.get("content", "")
        for m in msgs)


# 2. fix a seeded bug so the test passes ------------------------------------

BUGS = [  # (buggy_line, fixed_line)
    ("    return a - b\n", "    return a + b\n"),
    ("    return a * b + 1\n", "    return a * b\n"),
    ("    return max(xs) if xs else None\n",
     "    return min(xs) if xs else None\n"),
]


def t_fix_build(rng, repo):
    fn = rng.choice(["add", "combine", "total"])
    buggy, fixed = rng.choice(BUGS[:2])
    _write(repo, "app/calc.py",
           f"def {fn}(a, b):\n{buggy}")
    _write(repo, "tests/test_calc.py",
           f"from app.calc import {fn}\n\n"
           f"def test_{fn}():\n    assert {fn}(2, 3) == "
           f"{2 + 3 if '+' in fixed else 2 * 3}\n")
    _write(repo, "app/__init__.py", "")
    _write(repo, "conftest.py", "")
    return {"fn": fn, "buggy": buggy, "fixed": fixed}


def t_fix_prompt(rng, p):
    return rng.choice([
        "tests are failing, find the bug and fix it",
        "pytest is red — figure out why and make it pass",
        "the {fn} function seems wrong, fix it and prove it with the tests",
    ]).format(**p)


def t_fix_oracle(p):
    return [
        Turn(text="", tool_calls=[_tc(1, "bash",
             {"command": "python -B -m pytest -p no:cacheprovider tests/ -q"})]),
        Turn(text="", tool_calls=[_tc(2, "read_file",
             {"path": "app/calc.py"})]),
        Turn(text="", tool_calls=[_tc(3, "edit_file",
             {"path": "app/calc.py", "old_string": p["buggy"].strip("\n"),
              "new_string": p["fixed"].strip("\n")})]),
        Turn(text="", tool_calls=[_tc(4, "bash",
             {"command": "python -B -m pytest -p no:cacheprovider tests/ -q"})]),
        Turn(text=f"The `{p['fn']}` implementation used the wrong operator. "
                  "Fixed it and the test suite now passes."),
    ]


def t_fix_verify(repo, final, msgs, params):
    import subprocess
    r = subprocess.run(["python", "-B", "-m", "pytest",
                    "-p", "no:cacheprovider", "tests/", "-q"],
                       cwd=repo, capture_output=True, text=True, timeout=60)
    return r.returncode == 0


# 3. multi-file feature with todo discipline --------------------------------

def t_todo_build(rng, repo):
    name = rng.choice(["config", "settings", "options"])
    key = _slug(rng, 4)
    val = rng.randint(5, 90)
    _write(repo, "src/__init__.py", "")
    _write(repo, "conftest.py", "")
    return {"mod": name, "key": key, "val": val}


def t_todo_prompt(rng, p):
    return (f"add a {p['mod']}.py module in src/ with DEFAULTS = "
            f"{{'{p['key']}': {p['val']}}}, a get({p['key']!r}) helper, "
            "and a smoke test; run the test")


def t_todo_oracle(p):
    mod, key, val = p["mod"], p["key"], p["val"]
    todos = [
        {"content": f"create src/{mod}.py with DEFAULTS and get()",
         "status": "in_progress"},
        {"content": "add smoke test", "status": "pending"},
        {"content": "run tests", "status": "pending"},
    ]
    code = (f"DEFAULTS = {{'{key}': {val}}}\n\n\n"
            f"def get(name):\n    return DEFAULTS.get(name)\n")
    test = (f"from src.{mod} import get\n\n\n"
            f"def test_get():\n    assert get('{key}') == {val}\n")
    return [
        Turn(text="", tool_calls=[_tc(1, "todo_write", {"todos": todos})]),
        Turn(text="", tool_calls=[_tc(2, "write_file",
             {"path": f"src/{mod}.py", "content": code})]),
        Turn(text="", tool_calls=[_tc(3, "write_file",
             {"path": f"tests/test_{mod}.py", "content": test})]),
        Turn(text="", tool_calls=[_tc(4, "bash",
             {"command": "python -B -m pytest -p no:cacheprovider tests/ -q"})]),
        Turn(text=f"Done: `src/{mod}.py` exposes DEFAULTS and `get()`, "
                  "with a passing smoke test."),
    ]


def t_todo_verify(repo, final, msgs, params):
    import subprocess
    r = subprocess.run(["python", "-B", "-m", "pytest",
                    "-p", "no:cacheprovider", "tests/", "-q"],
                       cwd=repo, capture_output=True, text=True, timeout=60)
    used_todo = any("todo_write" in json.dumps(m.get("tool_calls", ""))
                    for m in msgs if m.get("role") == "assistant")
    return r.returncode == 0 and used_todo


# 4. read the repo and answer (no mutation) ---------------------------------

ANSWER_KEYS = [
    ("TIMEOUT_SECONDS", "request timeout", "seconds", [10, 30, 45, 60, 120]),
    ("PORT", "port the server listens on", "", [3000, 5050, 8080, 8443, 9001]),
    ("MAX_RETRIES", "retry limit for failed requests", "retries",
     [2, 3, 4, 5, 7]),
]


def t_answer_build(rng, repo):
    key, label, unit, vals = rng.choice(ANSWER_KEYS)
    val = rng.choice(vals)
    _write(repo, "src/server.py",
           f"{key} = {val}\n\n"
           "def handle(req):\n    return req\n")
    _write(repo, "src/util.py", "def noop():\n    pass\n")
    return {"key": key, "label": label, "unit": unit, "val": val}


def t_answer_prompt(rng, p):
    return rng.choice([
        "what is the {label} configured in this repo?",
        "find the {label} the server uses and tell me",
        "check the code: what {label} are we running with?",
    ]).format(**p)


def t_answer_oracle(p):
    unit = f" {p['unit']}" if p["unit"] else ""
    return [
        Turn(text="", tool_calls=[_tc(1, "grep",
             {"pattern": p["key"], "path": "."})]),
        Turn(text="", tool_calls=[_tc(2, "read_file",
             {"path": "src/server.py"})]),
        Turn(text=f"The {p['label']} is **{p['val']}{unit}** — "
                  f"`{p['key']}` in `src/server.py`."),
    ]


def t_answer_verify(repo, final, msgs, params):
    wrote = any(m.get("role") == "assistant" and "write_file" in
                json.dumps(m.get("tool_calls") or "") for m in msgs)
    return str(params["val"]) in final and not wrote


# 5. ask_user before an ambiguous choice ------------------------------------

ASK_DOMAINS = [
    ("add persistence to this app",
     "Persist to a JSON file or SQLite?", ["JSON file", "SQLite"],
     {"JSON file": ("storage.py",
                    'import json\n\ndef save(data):\n    '
                    'json.dump(data, open("data.json", "w"))\n'),
      "SQLite": ("storage.py",
                 'import sqlite3\n\ndef save(data):\n    '
                 'con = sqlite3.connect("data.db")\n    con.close()\n')}),
    ("add a config file for the app",
     "Use YAML or TOML for the config file?", ["YAML", "TOML"],
     {"YAML": ("config.yaml", "debug: false\nworkers: 4\n"),
      "TOML": ("config.toml", "debug = false\nworkers = 4\n")}),
    ("add logging to this service",
     "Log to a file or to the console?", ["a file", "the console"],
     {"a file": ("logging_setup.py",
                 'import logging\n\nlogging.basicConfig('
                 'filename="app.log", level=logging.INFO)\n'),
      "the console": ("logging_setup.py",
                      'import logging\n\nlogging.basicConfig('
                      'level=logging.INFO)\n')}),
]


def t_ask_build(rng, repo):
    _write(repo, "app.py", "routes = {}\n")
    di = rng.randrange(len(ASK_DOMAINS))
    prompt, question, options, impls = ASK_DOMAINS[di]
    answer = rng.choice(options)
    path, code = impls[answer]
    return {"domain": di, "prompt": prompt, "question": question,
            "options": options, "answer": answer, "path": path,
            "code": code}


def t_ask_prompt(rng, p):
    return p["prompt"]


def t_ask_oracle(p):
    return [
        Turn(text="", tool_calls=[_tc(1, "ask_user",
             {"question": p["question"], "options": p["options"]})]),
        Turn(text="", tool_calls=[_tc(2, "write_file",
             {"path": p["path"], "content": p["code"]})]),
        Turn(text=f"Added `{p['path']}` using {p['answer']}, as you "
                  "chose."),
    ]


def t_ask_setup(agent, p):
    agent.ui.ask_user = lambda q, opts: p["answer"]


def t_ask_verify(repo, final, msgs, params):
    asked = any(m.get("role") == "tool" and
                "The user answered" in m.get("content", "") for m in msgs)
    return (repo / params["path"]).is_file() and asked


# 6. plan-mode compliance (research only, produce a plan) -------------------

def t_plan_build(rng, repo):
    _write(repo, "src/auth.py", "def login(u, p):\n    return True\n")
    _write(repo, "src/db.py", "USERS = {}\n")
    feature, steps = rng.choice(PLAN_FEATURES)
    return {"feature": feature, "steps": steps}


PLAN_FEATURES = [
    ("password hashing in the auth flow",
     "Add `hash_password`/`verify_password` helpers in `src/auth.py` using "
     "`hashlib.pbkdf2_hmac`, store salted hashes in `db.USERS`, update "
     "`login()` to verify via the helper"),
    ("rate limiting on login attempts",
     "Track attempt timestamps per user in `src/db.py`, add a "
     "`check_rate_limit()` guard in `src/auth.py`, return a clear error "
     "when exceeded"),
    ("audit logging for logins",
     "Add an `audit_log()` helper writing structured entries, call it from "
     "`login()` on success and failure, make the log path configurable"),
    ("session tokens after login",
     "Generate signed tokens with `secrets.token_urlsafe`, store them in "
     "`src/db.py` with expiry, add a `validate_session()` helper"),
    ("input validation on credentials",
     "Reject empty/overlong usernames and passwords in `login()`, "
     "centralize rules in a `validate()` helper, cover edge cases"),
    ("account lockout after repeated failures",
     "Count consecutive failures per user in `src/db.py`, lock the account "
     "after N, add an unlock path and tests"),
]


def t_plan_prompt(rng, p):
    return rng.choice([
        "add {f}", "we need {f} — how should we do it?",
        "implement {f} in this codebase",
    ]).format(f=p["feature"])


def t_plan_oracle(p):
    return [
        Turn(text="", tool_calls=[_tc(1, "read_file",
             {"path": "src/auth.py"})]),
        Turn(text="", tool_calls=[_tc(2, "grep",
             {"pattern": "USERS", "path": "."})]),
        Turn(text="Here is the plan:\n\n"
                  f"1. {p['steps']}.\n"
                  "2. Add focused tests for the new behavior.\n"
                  "3. Run the suite to verify nothing regressed.\n\n"
                  "Risks: touching the login path affects every caller — "
                  "keep the public signature stable. Verification: the new "
                  "tests plus a manual login round-trip."),
    ]


def t_plan_setup(agent, p):
    agent.cfg.plan_mode = True


def t_plan_verify(repo, final, msgs, params):
    mutated = any(m.get("role") == "assistant" and any(
        n in json.dumps(m.get("tool_calls") or "")
        for n in ("write_file", "edit_file", "bash"))
        for m in msgs)
    return (not mutated) and "1." in final and "plan" in final.lower()


# 7. goal marker discipline --------------------------------------------------

def t_goal_build(rng, repo):
    return t_fix_build(rng, repo)


def t_goal_prompt(rng, p):
    return rng.choice([
        "make the failing test pass",
        "get the suite green",
        "fix whatever is breaking the tests",
        "tests are red — make them pass",
    ])


def t_goal_oracle(p):
    turns = t_fix_oracle(p)
    turns[-1] = Turn(text=turns[-1].text + "\n\nGOAL_MET")
    return turns


def t_goal_setup(agent, p):
    agent.goal = "the test suite passes"


def t_goal_verify(repo, final, msgs, params):
    return t_fix_verify(repo, final, msgs, params) and \
        final.rstrip().endswith("GOAL_MET")


# 8. recover from a denied tool ---------------------------------------------

def t_denied_build(rng, repo):
    fname = rng.choice(["notes.txt", "status.txt", "message.txt",
                        "banner.txt"])
    word = rng.choice(["updated", "refreshed", "synced", "ready", "done"])
    _write(repo, fname, "old\n")
    return {"file": fname, "word": word}


def t_denied_prompt(rng, p):
    return "overwrite {file} so it says: {word}".format(**p)


def t_denied_oracle(p):
    return [
        Turn(text="", tool_calls=[_tc(1, "bash",
             {"command": f"sudo tee {p['file']} <<< {p['word']}"})]),
        Turn(text="", tool_calls=[_tc(2, "write_file",
             {"path": p["file"], "content": p["word"] + "\n"})]),
        Turn(text="The shell route was denied, so I used the write_file "
                  f"tool instead — `{p['file']}` now says `{p['word']}`."),
    ]


def t_denied_setup(agent, p):
    agent.cfg.approval = "workspace-write"


def t_denied_verify(repo, final, msgs, params):
    denied = any(m.get("role") == "tool" and
                 m.get("content", "").startswith("Denied")
                 for m in msgs)
    return denied and (repo / params["file"]).read_text().strip() \
        == params["word"]


TEMPLATES: list[Template] = [
    Template("create_and_run", t_create_build, t_create_prompt,
             t_create_oracle, t_create_verify, weight=3),
    Template("fix_failing_test", t_fix_build, t_fix_prompt,
             t_fix_oracle, t_fix_verify, weight=5),
    Template("feature_with_todos", t_todo_build, t_todo_prompt,
             t_todo_oracle, t_todo_verify, weight=3),
    Template("read_and_answer", t_answer_build, t_answer_prompt,
             t_answer_oracle, t_answer_verify, weight=3),
    Template("ask_user_choice", t_ask_build, t_ask_prompt,
             t_ask_oracle, t_ask_verify, setup_agent=t_ask_setup, weight=3),
    Template("plan_mode", t_plan_build, t_plan_prompt,
             t_plan_oracle, t_plan_verify, setup_agent=t_plan_setup,
             weight=3),
    Template("goal_marker", t_goal_build, t_goal_prompt,
             t_goal_oracle, t_goal_verify, setup_agent=t_goal_setup,
             weight=3),
    Template("recover_from_denied", t_denied_build, t_denied_prompt,
             t_denied_oracle, t_denied_verify,
             setup_agent=t_denied_setup, weight=2),
]


# ------------------------------------------------------------- rollout

def rollout(tpl: Template, rng: random.Random,
            teacher: LLMClient | None = None) -> Sample | None:
    base = Path(tempfile.mkdtemp(prefix="locode-dg-"))
    repo = base / rng.choice(REPO_NAMES)
    repo.mkdir()
    try:
        params = tpl.build(rng, repo)
        prompt = tpl.prompt(rng, params)
        cfg = Config(project_dir=repo, stream=False,
                     approval="full-access", enable_subagent=False,
                     save_sessions=False)
        cfg.family = "generic"
        cfg.tool_mode = "native"
        agent = Agent(cfg, ui=_quiet_ui())
        if tpl.setup_agent:
            tpl.setup_agent(agent, params)
        agent.llm = teacher if teacher is not None \
            else ScriptedLLM(tpl.oracle(params))
        try:
            final = agent.run_turn(prompt)
        except Exception:
            return None
        try:
            ok = bool(tpl.verify(repo, final or "", agent.messages,
                                 params))
        except Exception:
            ok = False
        if not ok:
            return None
        from .tools import ToolSpec  # noqa: F401  (schemas below)
        tools = [{"type": "function", "function": {
                    "name": s.name, "description": s.description,
                    "parameters": s.parameters}}
                 for s in agent.registry.values()]
        fake_dir = f"/home/dev/{repo.name}"
        return Sample(template=tpl.name, params=params,
                      messages=[dict(m) for m in agent.messages],
                      tools=tools, project_dir=str(repo),
                      fake_dir=fake_dir)
    finally:
        shutil.rmtree(base, ignore_errors=True)


# -------------------------------------------------------------- export

def _scrub(text: str, real: str, fake: str) -> str:
    return text.replace(real, fake)


def to_native(sample: Sample) -> dict:
    msgs = []
    for m in sample.messages:
        m = dict(m)
        if isinstance(m.get("content"), str):
            m["content"] = _scrub(m["content"], sample.project_dir,
                                  sample.fake_dir)
        msgs.append(m)
    return {"messages": msgs, "tools": sample.tools,
            "meta": {"template": sample.template}}


def to_prompted(sample: Sample, rng: random.Random,
                selfheal_p: float = 0.15) -> dict:
    """Render to plain-text messages in locode's prompted protocol,
    optionally injecting a malformed→corrected self-heal sequence."""
    out: list[dict] = []
    for m in sample.messages:
        role = m.get("role")
        content = m.get("content") or ""
        if isinstance(content, str):
            content = _scrub(content, sample.project_dir, sample.fake_dir)
        if role == "assistant" and m.get("tool_calls"):
            blocks = []
            for tc in m["tool_calls"]:
                fn = tc["function"]
                payload = {"name": fn["name"],
                           "arguments": json.loads(fn["arguments"])}
                good = json.dumps(payload)
                if rng.random() < selfheal_p:
                    broken = good[:-1]  # drop closing brace
                    out.append({"role": "assistant",
                                "content": f"<tool_call>\n{broken}\n"
                                           "</tool_call>"})
                    out.append({"role": "user",
                                "content": MALFORMED_HELP.format(
                                    err="unterminated JSON object")})
                blocks.append(f"<tool_call>\n{good}\n</tool_call>")
            text = (content + "\n" if content else "") + "\n".join(blocks)
            out.append({"role": "assistant", "content": text})
        elif role == "tool":
            name = m.get("name", "tool")
            out.append({"role": "user",
                        "content": f'<tool_response name="{name}">\n'
                                   f"{content}\n</tool_response>"})
        else:
            out.append({"role": role, "content": content})
    return {"messages": out, "meta": {"template": sample.template}}


# ------------------------------------------------------------ generate

def generate(out_dir: Path, count: int, seed: int = 0,
             teacher_url: str = "", teacher_model: str = "",
             teacher_key: str = "", teacher_format: str = "openai",
             workers_n: int = 8, log=print) -> dict:
    rng = random.Random(seed)
    out_dir.mkdir(parents=True, exist_ok=True)
    teacher = None
    if teacher_url:
        if teacher_format == "anthropic":
            from .anthropic_compat import AnthropicTeacher
            teacher = AnthropicTeacher(teacher_url, teacher_model,
                                       api_key=teacher_key)
        else:
            tcfg = Config(base_url=teacher_url, model=teacher_model,
                          api_key=teacher_key or "dummy", stream=False)
            tcfg.family = "generic"
            teacher = LLMClient(tcfg)
        log(f"teacher: {teacher_model} @ {teacher_url} "
            f"[{teacher_format} format] "
            "(verified trajectories only will be kept)")

    pool: list[Template] = []
    for t in TEMPLATES:
        pool += [t] * t.weight

    samples: list[Sample] = []
    seen: set[str] = set()
    attempts = 0
    t0 = time.time()
    from concurrent.futures import ThreadPoolExecutor

    def one(job_seed: int) -> Sample | None:
        r = random.Random(job_seed)
        return rollout(r.choice(pool), r, teacher)

    # cloud teachers parallelize well; local single-GPU teachers should
    # pass --workers 1-2 to avoid queueing against themselves
    workers = max(1, workers_n)
    next_seed = seed * 1_000_003
    with ThreadPoolExecutor(max_workers=workers) as ex:
        while len(samples) < count and attempts < count * 6:
            batch = min(workers * 4, count * 6 - attempts)
            seeds = [next_seed + i for i in range(batch)]
            next_seed += batch
            attempts += batch
            for s in ex.map(one, seeds):
                if s is None or s.key() in seen or len(samples) >= count:
                    continue
                seen.add(s.key())
                samples.append(s)
            log(f"  {len(samples)}/{count} verified "
                f"({attempts} attempts, {time.time() - t0:.0f}s)")

    rng.shuffle(samples)
    n_val = max(1, len(samples) // 20)
    val, train = samples[:n_val], samples[n_val:]

    def dump(path: Path, rows: list[dict]) -> None:
        with path.open("w") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")

    dump(out_dir / "train_native.jsonl", [to_native(s) for s in train])
    dump(out_dir / "val_native.jsonl", [to_native(s) for s in val])
    dump(out_dir / "train_prompted.jsonl",
         [to_prompted(s, rng) for s in train])
    dump(out_dir / "val_prompted.jsonl",
         [to_prompted(s, rng, selfheal_p=0.0) for s in val])

    by_tpl: dict[str, int] = {}
    for s in samples:
        by_tpl[s.template] = by_tpl.get(s.template, 0) + 1
    stats = {"total": len(samples), "train": len(train), "val": len(val),
             "attempts": attempts, "by_template": by_tpl,
             "teacher": teacher_model or "oracle", "seed": seed,
             "seconds": round(time.time() - t0, 1)}
    (out_dir / "stats.json").write_text(json.dumps(stats, indent=2))
    log(json.dumps(stats, indent=2))
    return stats
