"""Custom slash commands — markdown prompt templates.

Drop `review.md` into `.locode/commands/` (or `.claude/commands/` — Claude
Code's location works as-is) and `/review src/app.py` expands the file into
a prompt, substituting `$ARGUMENTS` (everything after the command) and
`$1`…`$9` (whitespace-split words). Optional YAML frontmatter with a
`description` shows up in /help.
"""
from __future__ import annotations

import re
import shlex
from dataclasses import dataclass
from pathlib import Path

from .skills import parse_frontmatter


@dataclass
class CustomCommand:
    name: str
    path: Path
    description: str
    source: str


def command_search_dirs(cfg) -> list[tuple[Path, str]]:
    from .plugins import discover_plugins

    home = Path.home()
    dirs = [
        (cfg.project_dir / ".locode" / "commands", "project"),
        (cfg.project_dir / ".claude" / "commands", "project"),
        (home / ".config" / "locode" / "commands", "user"),
        (home / ".claude" / "commands", "user"),
    ]
    for plugin in discover_plugins(cfg):
        dirs.append((plugin.root / "commands", f"plugin:{plugin.name}"))
    return dirs


def discover_commands(cfg) -> dict[str, CustomCommand]:
    cmds: dict[str, CustomCommand] = {}
    for base, source in command_search_dirs(cfg):
        if not base.is_dir():
            continue
        for f in sorted(base.glob("*.md")):
            name = f.stem.lower()
            if name in cmds:
                continue  # earlier source wins
            desc = ""
            try:
                meta, _ = parse_frontmatter(f.read_text(errors="replace"))
                desc = str(meta.get("description", "")).strip()
            except OSError:
                continue
            cmds[name] = CustomCommand(name=name, path=f,
                                       description=desc, source=source)
    return cmds


def expand_command(cmd: CustomCommand, args: str) -> str:
    _, body = parse_frontmatter(cmd.path.read_text(errors="replace"))
    args = args.strip()
    try:
        words = shlex.split(args)
    except ValueError:
        words = args.split()

    def word(m: re.Match) -> str:
        i = int(m.group(1)) - 1
        return words[i] if 0 <= i < len(words) else ""

    out = re.sub(r"\$(\d)", word, body)
    if "$ARGUMENTS" in out:
        out = out.replace("$ARGUMENTS", args)
    elif args:
        out += f"\n\nARGUMENTS: {args}"
    return out.strip()
