"""locode — a local-model coding agent harness.

A Claude Code / Codex CLI-inspired terminal coding agent for models you run
yourself (Qwen 3.6 / 3.5, Gemma 4, …) behind any OpenAI-compatible server
(Ollama, vLLM, LM Studio, llama.cpp, SGLang).
"""
__version__ = "0.10.0"
