"""Anthropic Messages-format client for the datagen teacher.

Z.ai's GLM Coding Plan (and its trials) expose an *Anthropic-compatible*
endpoint so tools like Claude Code can use GLM as a drop-in. This client
speaks that format with stdlib urllib only, presenting the same .chat()
interface as LLMClient, so `locode datagen --teacher-format anthropic`
can burn plan/trial quota to generate verified trajectories.

Mapping notes:
- OpenAI-style history -> Anthropic: system messages lift to the top-level
  `system` field; assistant tool_calls become `tool_use` content blocks;
  consecutive role="tool" results are batched into ONE following user
  message of `tool_result` blocks (Anthropic requires this shape).
- Response `text` blocks -> Turn.text, `tool_use` -> ToolCall,
  `thinking` -> Turn.thinking.
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request

from .llm import ToolCall, Turn

ANTHROPIC_VERSION = "2023-06-01"


class AnthropicTeacher:
    def __init__(self, base_url: str, model: str, api_key: str = "",
                 max_tokens: int = 8192, temperature: float = 0.6,
                 timeout: float = 300.0):
        self.base_url = base_url.rstrip("/")
        if self.base_url.endswith("/v1"):
            self.base_url = self.base_url[:-3]
        self.model = model
        self.api_key = api_key
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.timeout = timeout

    # ---------------------------------------------------------- mapping

    @staticmethod
    def _convert_messages(messages: list[dict]) -> tuple[str, list[dict]]:
        system_parts: list[str] = []
        out: list[dict] = []
        pending_results: list[dict] = []

        def flush_results() -> None:
            if pending_results:
                out.append({"role": "user", "content": list(pending_results)})
                pending_results.clear()

        for m in messages:
            role = m.get("role")
            if role == "system":
                system_parts.append(str(m.get("content", "")))
                continue
            if role == "tool":
                pending_results.append({
                    "type": "tool_result",
                    "tool_use_id": m.get("tool_call_id", ""),
                    "content": str(m.get("content", "")),
                })
                continue
            flush_results()
            if role == "assistant" and m.get("tool_calls"):
                blocks: list[dict] = []
                text = str(m.get("content") or "")
                if text.strip():
                    blocks.append({"type": "text", "text": text})
                for tc in m["tool_calls"]:
                    fn = tc.get("function", {})
                    try:
                        args = json.loads(fn.get("arguments") or "{}")
                    except json.JSONDecodeError:
                        args = {}
                    blocks.append({"type": "tool_use",
                                   "id": tc.get("id", ""),
                                   "name": fn.get("name", ""),
                                   "input": args})
                out.append({"role": "assistant", "content": blocks})
            else:
                out.append({"role": role,
                            "content": str(m.get("content") or "")})
        flush_results()
        return "\n\n".join(p for p in system_parts if p), out

    @staticmethod
    def _convert_tools(tools_schema: list[dict] | None) -> list[dict]:
        out = []
        for t in tools_schema or []:
            fn = t.get("function", t)
            out.append({"name": fn.get("name", ""),
                        "description": fn.get("description", ""),
                        "input_schema": fn.get("parameters")
                        or {"type": "object", "properties": {}}})
        return out

    # ---------------------------------------------------------- request

    def _post(self, body: dict) -> dict:
        req = urllib.request.Request(
            self.base_url + "/v1/messages",
            data=json.dumps(body).encode(),
            headers={"Content-Type": "application/json",
                     "x-api-key": self.api_key,
                     "Authorization": f"Bearer {self.api_key}",
                     "anthropic-version": ANTHROPIC_VERSION},
            method="POST")
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))

    def chat(self, messages, tools_schema, on_text=None,
             on_thinking=None) -> Turn:
        system, msgs = self._convert_messages(messages)
        body: dict = {"model": self.model, "max_tokens": self.max_tokens,
                      "temperature": self.temperature, "messages": msgs}
        if system:
            body["system"] = system
        tools = self._convert_tools(tools_schema)
        if tools:
            body["tools"] = tools

        last_err: Exception | None = None
        for attempt in range(3):
            try:
                data = self._post(body)
                break
            except urllib.error.HTTPError as e:
                last_err = e
                if e.code in (408, 409, 429, 500, 502, 503, 529):
                    time.sleep(2.0 * (attempt + 1))
                    continue
                raise ConnectionError(
                    f"teacher HTTP {e.code}: "
                    f"{e.read()[:300].decode(errors='replace')}") from e
            except (urllib.error.URLError, TimeoutError, OSError) as e:
                last_err = e
                time.sleep(2.0 * (attempt + 1))
        else:
            raise ConnectionError(f"teacher unreachable: {last_err}")

        text_parts: list[str] = []
        think_parts: list[str] = []
        calls: list[ToolCall] = []
        for i, block in enumerate(data.get("content") or []):
            btype = block.get("type")
            if btype == "text":
                text_parts.append(str(block.get("text", "")))
            elif btype == "thinking":
                think_parts.append(str(block.get("thinking", "")))
            elif btype == "tool_use":
                args = block.get("input")
                if not isinstance(args, dict):
                    args = {}
                calls.append(ToolCall(
                    id=str(block.get("id") or f"call_{i}"),
                    name=str(block.get("name", "")),
                    arguments=args,
                    raw_arguments=json.dumps(args)))
        return Turn(text="".join(text_parts), tool_calls=calls,
                    thinking="\n".join(think_parts))

    def summarize(self, messages, instruction: str) -> str:
        msgs = list(messages) + [{"role": "user", "content": instruction}]
        return self.chat(msgs, tools_schema=[]).text
