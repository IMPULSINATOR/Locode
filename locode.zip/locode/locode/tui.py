"""Full-screen terminal UI built on Textual (v2 — polished).

Claude Code renders with Ink (React for terminals); this is the Python
analogue. What's here:

- slash-command suggestions that pop up above the input as you type `/`
  (↑/↓ select, Tab completes, Esc dismisses)
- an activity line with a spinner, rotating whimsical verbs, elapsed time
  and an interrupt hint while the model works
- tool calls and thinking rendered as collapsible dropdowns (results and
  reasoning tucked away until you expand them)
- approval modals with syntax-highlighted diff previews
- input history, live context-usage status bar, Esc interrupts mid-stream

Threading: the agent runs in a worker thread; every UI touch is marshalled
via call_from_thread. Approvals block the worker on a Queue. Esc sets a
flag the adapter checks at each stream chunk / tool call, raising
KeyboardInterrupt inside the worker, which the agent unwinds safely.
"""
from __future__ import annotations

import itertools
import json
import queue
import random
import re
import threading
import time

from rich.markup import escape
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, VerticalScroll
from textual.message import Message
from textual.screen import ModalScreen
from textual.widgets import (Button, Collapsible, Input, Markdown,
                             OptionList, Static, TextArea)
from textual.widgets.option_list import Option

from . import __version__
from .agent import Agent
from .config import Config
from .replcmds import BUILTIN_COMMANDS, handle
from .tools.files import complete_mention_path
from .tools.todo import render_todos

VERBS = [
    "Discombobulating", "Percolating", "Noodling", "Marinating",
    "Ruminating", "Cogitating", "Conjuring", "Tinkering", "Wrangling",
    "Sleuthing", "Spelunking", "Untangling", "Grokking", "Deliberating",
    "Incubating", "Scheming", "Calibrating", "Simmering", "Whittling",
    "Reticulating", "Brewing", "Puzzling", "Mulling", "Zhuzhing",
    "Sautéing", "Herding", "Composing", "Fermenting", "Riffing",
]
SPINNER = itertools.cycle("⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏")

# Some Windows terminals leak raw CSI/SGR mouse-report bytes (e.g.
# "[<65;74;31M") into whatever widget has focus if a click/scroll lands
# mid-render while a modal is closing. Disabling App(mouse=...) (see
# cli.py) fixes this structurally; this regex is a cheap second line of
# defense that strips any such fragment that slips through regardless.
ANSI_LEAK_RE = re.compile(r"\x1b?\[[<]?[0-9;]*[A-Za-z~]")
AT_MENTION_RE = re.compile(r"(?<!\S)@([\w./\\~-]*)$")


def _strip_leaked_escapes(text: str) -> str:
    return ANSI_LEAK_RE.sub("", text) if "[" in text else text


# --------------------------------------------------------------- adapter

class TextualUI:
    """Implements the same interface as ui.UI, marshalling onto the app."""

    interactive = True

    def __init__(self, app: "LocodeApp") -> None:
        self.app = app
        self.interrupt = threading.Event()
        self.dead = False
        self.transcript: list[str] = []      # plain-text log (tests/debug)

    # -- plumbing ---------------------------------------------------------

    def _post(self, fn, *args) -> None:
        if self.dead:
            return
        if threading.get_ident() == self.app.ui_thread_id:
            fn(*args)
        else:
            try:
                self.app.call_from_thread(fn, *args)
            except RuntimeError:
                self.dead = True  # app is shutting down

    def _check(self) -> None:
        if self.interrupt.is_set():
            self.interrupt.clear()
            raise KeyboardInterrupt

    def _log(self, text: str) -> None:
        self.transcript.append(text)

    # -- model output -----------------------------------------------------

    def wait_start(self) -> None:
        self._check()
        self._post(self.app.set_thinking, True)

    def wait_stop(self) -> None:
        self._post(self.app.set_thinking, False)

    def stream_text(self, chunk: str) -> None:
        self._check()
        self._log(chunk)
        self._post(self.app.append_stream, chunk)

    def stream_thinking(self, chunk: str) -> None:
        self._check()
        self._post(self.app.append_thinking, chunk)

    def stream_end(self) -> None:
        self._post(self.app.finish_stream)

    def assistant_text(self, text: str) -> None:
        if text.strip():
            self._log(text)
            self._post(self.app.add_markdown, text)

    # -- tools ------------------------------------------------------------

    def tool_call(self, name: str, summary: str) -> None:
        self._check()
        self._log(f"⏺ {name}({summary})")
        self._post(self.app.add_tool_call, name, summary)

    def tool_result(self, name: str, result: str) -> None:
        self._log(result)
        self._post(self.app.set_tool_result, name, result)

    def todos_panel(self, todos: list[dict]) -> None:
        self._log(render_todos(todos))
        self._post(self.app.add_renderable,
                   Panel(render_todos(todos), title="plan",
                         border_style="dim"))

    def subagent_start(self, label: str) -> None:
        self._log(f"⇢ subagent: {label}")
        self._post(self.app.add_line,
                   f"[magenta]⇢ subagent:[/] [dim]{escape(label)}[/]", "line")

    def subagent_end(self) -> None:
        self._post(self.app.add_line, "[magenta]⇠ subagent finished[/]",
                   "line")

    # -- approvals --------------------------------------------------------

    def confirm(self, tool: str, reason: str, preview: str) -> str:
        q: "queue.Queue[str]" = queue.Queue(maxsize=1)
        self._post(self.app.ask_approval, tool, reason, preview, q)
        while True:
            try:
                ans = q.get(timeout=0.5)
                self._log(f"[approval:{tool}] -> {ans}")
                return ans
            except queue.Empty:
                if self.dead:
                    return "n"

    def ask_user(self, question: str, options: list[str]) -> str | None:
        q: "queue.Queue[str]" = queue.Queue(maxsize=1)
        self._post(self.app.ask_question, question, options, q)
        while True:
            try:
                ans = q.get(timeout=0.5)
                self._log(f"[ask_user] -> {ans!r}")
                return ans
            except queue.Empty:
                if self.dead:
                    return None

    # -- misc -------------------------------------------------------------

    def notice(self, msg: str) -> None:
        self._log(msg)
        self._post(self.app.add_line, f"[yellow]•[/] [dim]{escape(msg)}[/]",
                   "line")

    def error(self, msg: str) -> None:
        self._log(f"error: {msg}")
        self._post(self.app.add_line, f"[bold red]error:[/] {escape(msg)}",
                   "line")

    def print_line(self, markup: str) -> None:
        self._log(markup)
        self._post(self.app.add_line, markup, "line")

    def update_status(self, used_tokens: int, budget: int) -> None:
        self._post(self.app.set_ctx, used_tokens, budget)


# ---------------------------------------------------------------- widgets

class PromptArea(TextArea):
    """Multi-line prompt. Enter submits; Ctrl+J (or Shift+Enter, on
    terminals that report it — most don't, hence Ctrl+J as the reliable
    fallback) inserts a newline instead. ↑/↓ recall history when the
    buffer holds a single line (like a normal shell); on multi-line
    content they move the cursor instead. Also drives the slash-
    suggestions popup navigation when it's open."""

    class Submitted(Message):
        def __init__(self, value: str) -> None:
            self.value = value
            super().__init__()

    def __init__(self, **kw) -> None:
        super().__init__(show_line_numbers=False, soft_wrap=True, **kw)
        # NOTE: named recall_history, not history — TextArea already owns
        # `self.history` internally (its undo/redo edit-history object);
        # shadowing it breaks focus handling.
        self.recall_history: list[str] = []
        self._idx: int | None = None

    def remember(self, text: str) -> None:
        if text and (not self.recall_history
                     or self.recall_history[-1] != text):
            self.recall_history.append(text)
        self._idx = None

    def _to_end(self) -> None:
        self.move_cursor(self.document.end)

    async def _on_key(self, event) -> None:
        app: "LocodeApp" = self.app  # type: ignore[assignment]
        if app.suggestions_open:
            if event.key in ("up", "down"):
                app.suggestions_move(-1 if event.key == "up" else 1)
                event.stop(), event.prevent_default()
                return
            if event.key in ("tab", "right"):
                completed = app.suggestions_take()
                if completed:
                    self.load_text(completed)
                    self._to_end()
                event.stop(), event.prevent_default()
                return
            if event.key == "enter" and app._sugg_kind == "at":
                app.suggestions_take()   # inserts the path, keeps composing
                event.stop(), event.prevent_default()
                return
            if event.key == "escape":
                app.suggestions_hide()
                event.stop(), event.prevent_default()
                return

        if event.key == "enter":
            event.stop(), event.prevent_default()
            self.post_message(self.Submitted(self.text))
            return
        if event.key in ("ctrl+j", "shift+enter"):
            event.stop(), event.prevent_default()
            self.insert("\n")
            return

        single_line = "\n" not in self.text
        if event.key == "up" and single_line and self.recall_history:
            event.stop(), event.prevent_default()
            self._idx = (len(self.recall_history) - 1 if self._idx is None
                         else max(0, self._idx - 1))
            self.load_text(self.recall_history[self._idx])
            self._to_end()
            return
        if event.key == "down" and single_line and self._idx is not None:
            event.stop(), event.prevent_default()
            self._idx += 1
            if self._idx >= len(self.recall_history):
                self._idx = None
                self.clear()
            else:
                self.load_text(self.recall_history[self._idx])
                self._to_end()
            return
        await super()._on_key(event)


class _QuestionOptions(OptionList):
    """OptionList with 1-9 quick-select (mirrors the suggestions UX)."""

    def _on_key(self, event) -> None:
        ch = event.character or ""
        screen = self.screen
        if (ch.isdigit() and isinstance(screen, QuestionScreen)
                and 1 <= int(ch) <= len(screen.options)):
            event.stop(), event.prevent_default()
            screen.dismiss(screen.options[int(ch) - 1])


class QuestionScreen(ModalScreen[str]):
    """The model asked a clarifying question: pick an option (↑/↓ +
    Enter, or a number key) or type a custom answer. Esc skips."""

    BINDINGS = [Binding("escape", "skip", "skip", show=False)]

    def __init__(self, question: str, options: list[str]) -> None:
        super().__init__()
        self.question = question
        self.options = options

    def compose(self) -> ComposeResult:
        with Container(id="question-box"):
            yield Static(f"[bold cyan]?[/] {escape(self.question)}",
                         id="question-title")
            if self.options:
                rows = [Option(Text.from_markup(
                            f"[b cyan]{i}.[/] {escape(opt)}"))
                        for i, opt in enumerate(self.options, 1)]
                yield _QuestionOptions(*rows, id="question-options")
            yield Static("[dim]…or type your own answer "
                         "(Esc to skip):[/]", id="question-hint")
            yield Input(placeholder="custom answer",
                        id="question-input")

    def on_mount(self) -> None:
        if self.options:
            lst = self.query_one("#question-options", OptionList)
            lst.highlighted = 0
            lst.focus()
        else:
            self.query_one("#question-input", Input).focus()

    def on_option_list_option_selected(
            self, event: OptionList.OptionSelected) -> None:
        event.stop()
        self.dismiss(self.options[event.option_index])

    def on_input_submitted(self, event: Input.Submitted) -> None:
        event.stop()   # never let the app treat this as a prompt submit
        self.dismiss(_strip_leaked_escapes(event.value.strip()))

    def action_skip(self) -> None:
        self.dismiss("")


class SessionPickerScreen(ModalScreen[str]):
    """Pick a past conversation to resume — one real entry per
    conversation (see sessions.py), not per-turn snapshots. Esc starts
    fresh / keeps the current conversation instead."""

    BINDINGS = [Binding("escape", "cancel", "start fresh", show=False)]

    def __init__(self, sessions: list[dict]) -> None:
        super().__init__()
        self.sessions = sessions

    def compose(self) -> ComposeResult:
        with Container(id="resume-box"):
            yield Static(
                f"[bold cyan]?[/] Resume which conversation? "
                f"({len(self.sessions)} found \u2014 Esc for a fresh "
                "start)", id="resume-title")
            rows = []
            for s in self.sessions:
                when = time.strftime("%b %d %H:%M", time.localtime(s["ts"]))
                goal = f" · goal: {s['goal'][:30]}" if s.get("goal") else ""
                label = (f"{when}  ·  {s['n_messages']} msg  ·  "
                        f"{s['summary']}{goal}")
                rows.append(Option(Text(label)))
            with VerticalScroll(id="resume-options-wrap"):
                yield OptionList(*rows, id="resume-options")

    def on_mount(self) -> None:
        self.query_one("#resume-options", OptionList).focus()

    def on_option_list_option_selected(
            self, event: OptionList.OptionSelected) -> None:
        event.stop()
        idx = event.option_index
        session_id = (self.sessions[idx]["session_id"]
                     if 0 <= idx < len(self.sessions) else "")
        self.dismiss(session_id)

    def action_cancel(self) -> None:
        self.dismiss("")


class ApprovalScreen(ModalScreen[str]):
    """y / n / a modal with an optional diff/command preview."""

    BINDINGS = [
        Binding("y", "choose('y')", "allow"),
        Binding("n", "choose('n')", "deny"),
        Binding("a", "choose('a')", "always"),
        Binding("escape", "choose('n')", "deny", show=False),
    ]

    def __init__(self, tool: str, reason: str, preview: str) -> None:
        super().__init__()
        self.tool, self.reason, self.preview = tool, reason, preview

    def compose(self) -> ComposeResult:
        with Container(id="approval-box"):
            yield Static(
                f"[bold yellow]{escape(self.tool)}[/] needs approval — "
                f"{escape(self.reason)}", id="approval-title")
            if self.preview:
                p = self.preview
                looks_diff = p.lstrip().startswith(("---", "+++", "@@")) \
                    or "\n+++" in p
                body = Syntax(p, "diff", word_wrap=True) if looks_diff \
                    else Text(p)
                with VerticalScroll(id="approval-preview"):
                    yield Static(body)
            with Horizontal(id="approval-buttons"):
                yield Button("Allow (y)", id="y", variant="success")
                yield Button("Deny (n)", id="n", variant="error")
                yield Button("Always this tool (a)", id="a",
                             variant="primary")

    def action_choose(self, ans: str) -> None:
        self.dismiss(ans)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id or "n")


# -------------------------------------------------------------------- app

class LocodeApp(App):
    TITLE = "locode"

    CSS = """
    #topbar { dock: top; height: 1; background: $panel;
              color: $text-muted; padding: 0 1; }
    #chat { padding: 0 1; scrollbar-size-vertical: 1; }
    #suggestions { display: none; margin: 0 1; padding: 0 1; height: auto;
                   max-height: 12; border: round $primary-darken-2;
                   background: $surface; scrollbar-size-vertical: 1; }
    #suggestions.open { display: block; }
    .sugg { height: 1; }
    .sugg.selected { background: $primary-darken-2; }
    #activity { display: none; height: 1; margin: 0 2; color: $text-muted; }
    #activity.on { display: block; }
    #prompt { height: 5; margin: 0 1 1 1; border: round $primary; }
    #prompt:focus { border: round $accent; }
    #prompt.multiline { height: 8; }
    .user { color: $success; margin-top: 1; }
    .line { }
    .assistant { margin-top: 1; }
    Collapsible { border: none; padding: 0; margin: 0 0 0 0; }
    Collapsible > Contents { padding: 0 0 0 3; }
    .result-body { color: $text-muted; }
    .think-body { color: $text-muted; text-style: italic; }
    QuestionScreen { align: center middle; }
    #question-box { width: 80%; max-width: 100; border: round $accent;
                    background: $surface; padding: 1 2; height: auto; }
    #question-options { max-height: 12; margin: 1 0 0 0;
                        scrollbar-size-vertical: 1; }
    #question-hint { margin-top: 1; }
    #question-input { border: round $primary; margin-top: 0; }
    SessionPickerScreen { align: center middle; }
    #resume-box { width: 85%; max-width: 110; max-height: 80%;
                  border: round $accent; background: $surface;
                  padding: 1 2; height: auto; }
    #resume-options-wrap { max-height: 16; margin: 1 0 0 0;
                           scrollbar-size-vertical: 1; }
    ApprovalScreen { align: center middle; }
    #approval-box { width: 90%; max-width: 110; max-height: 80%;
                    border: round $warning; background: $surface;
                    padding: 1 2; height: auto; }
    #approval-preview { max-height: 20; margin: 1 0; }
    #approval-buttons { height: 3; align-horizontal: center; }
    #approval-buttons Button { margin: 0 2; }
    """

    BINDINGS = [
        Binding("escape", "interrupt", "stop turn", show=False),
        # NOT priority=True: Textual's built-in Screen binding for ctrl+c
        # is "copy selected text" (falls through via SkipAction when
        # nothing is selected) — priority=True here would hijack ctrl+c
        # unconditionally and copy would never get a chance to run.
        Binding("ctrl+c", "smart_quit", "interrupt/quit", show=False),
        Binding("ctrl+q", "quit", "quit", show=False),
        Binding("ctrl+l", "clear_view", "clear view", show=False),
        Binding("shift+tab", "toggle_plan", "plan mode", show=False,
                priority=True),
        Binding("ctrl+shift+c", "copy_reply", "copy last reply",
                show=False),
    ]

    def __init__(self, cfg: Config, agent_factory=None) -> None:
        super().__init__()
        self.cfg = cfg
        self._agent_factory = agent_factory or (lambda c, ui: Agent(c, ui))
        self.agent: Agent | None = None
        self.ui_adapter: TextualUI | None = None
        self.ui_thread_id: int = 0
        self.busy = False
        self.thinking = False
        self._ctx_pct = 0
        self._used_tokens = 0
        # streaming state
        self._cur_md: Markdown | None = None
        self._md_src = ""
        self._cur_think: Collapsible | None = None
        self._cur_think_body: Static | None = None
        self._think_src = ""
        self._think_t0 = 0.0
        self._cur_tool: Collapsible | None = None
        self._cur_tool_body: Static | None = None
        self._last_reply: str = ""    # for Ctrl+Shift+C clipboard copy
        # activity line
        self._verb = random.choice(VERBS)
        self._busy_t0 = 0.0
        self._verb_t = 0.0
        # suggestions ("slash" = commands, "at" = file/dir mentions)
        self.suggestions_open = False
        self._sugg_items: list[tuple[str, str]] = []
        self._sugg_sel = 0
        self._sugg_kind = ""
        self._at_range: tuple | None = None

    # -- layout -----------------------------------------------------------

    def compose(self) -> ComposeResult:
        yield Static(id="topbar")
        yield VerticalScroll(id="chat")
        yield VerticalScroll(id="suggestions")
        yield Static(id="activity")
        yield PromptArea(id="prompt",
                        placeholder="Describe a task…  (/ commands, "
                                    "@file, ↑ history, Ctrl+J newline)")

    def on_mount(self) -> None:
        self.ui_thread_id = threading.get_ident()
        self.ui_adapter = TextualUI(self)
        self.agent = self._agent_factory(self.cfg, self.ui_adapter)
        self.refresh_topbar()
        n_mcp = sum(1 for t in self.agent.registry if t.startswith("mcp__"))
        bits = [f"{len(self.agent.skills)} skill(s)",
                f"{len(self.agent.commands)} command(s)"]
        if self.agent.agent_defs:
            bits.append(f"{len(self.agent.agent_defs)} subagent(s)")
        if n_mcp:
            bits.append(f"{n_mcp} MCP tool(s)")
        self.add_line(
            f"[bold]locode[/] v{__version__} · [cyan]{self.cfg.model}[/] @ "
            f"{self.cfg.base_url}\n[dim]project: {self.cfg.project_dir} · "
            + " · ".join(bits) + " · /help[/]", "line")
        if self.cfg.continue_session:
            from . import sessions
            found = sessions.list_sessions(self.cfg)
            if len(found) <= 1:
                data = sessions.restore(self.agent, self.ui_adapter)
                if data:
                    self.replay_transcript()
                    self.query_one("#prompt", PromptArea).recall_history = \
                        list(self.agent.input_history)
            else:
                self._open_resume_picker(found)
        self.set_interval(0.25, self._tick_activity)
        self.query_one("#prompt", PromptArea).focus()

    def _open_resume_picker(self, found: list[dict]) -> None:
        self.push_screen(SessionPickerScreen(found),
                         callback=self._on_session_picked)

    def _on_session_picked(self, session_id: str) -> None:
        if not session_id:
            self.ui_adapter.notice("staying on the current conversation.")
            return
        from . import sessions
        data = sessions.restore_session(self.agent, self.ui_adapter,
                                        session_id)
        if data:
            self.query_one("#chat", VerticalScroll).remove_children()
            self.replay_transcript()
            self.query_one("#prompt", PromptArea).recall_history = \
                list(self.agent.input_history)
            self.refresh_topbar()

    def replay_transcript(self) -> None:
        """Render a restored session's messages into the visible chat log
        (restoring the agent's internal state alone leaves the screen
        blank, which is confusing on --continue)."""
        self.add_line("[dim]── resumed conversation ──[/]", "line")
        open_tool: str | None = None
        for m in self.agent.messages[1:]:
            role = m.get("role")
            if role == "user":
                content = m.get("content", "")
                if isinstance(content, str) and content.strip():
                    # strip harness-injected wrappers so replay reads clean
                    for marker in ("[PLAN MODE", "[Active goal:",
                                  "[Attached file:"):
                        if marker in content:
                            content = content.split(marker, 1)[0].strip()
                    if content:
                        self.add_user(content)
            elif role == "assistant":
                calls = m.get("tool_calls")
                if calls:
                    for tc in calls:
                        fn = tc.get("function", {})
                        name = fn.get("name", "tool")
                        try:
                            args = json.loads(fn.get("arguments") or "{}")
                        except Exception:
                            args = {}
                        summary = ", ".join(f"{k}={v!r}" for k, v in
                                           list(args.items())[:2])[:80]
                        self.add_tool_call(name, summary)
                        open_tool = name
                else:
                    content = m.get("content", "")
                    if isinstance(content, str) and content.strip():
                        self.add_markdown(content)   # also sets _last_reply
            elif role == "tool" and open_tool:
                self.set_tool_result(open_tool, str(m.get("content", "")))
                open_tool = None
        self.add_line("[dim]── end of resumed history — continue below ──[/]",
                      "line")

    def on_unmount(self) -> None:
        if self.ui_adapter:
            self.ui_adapter.dead = True
            self.ui_adapter.interrupt.set()
        if self.agent:
            self.agent.close()

    # -- topbar / activity --------------------------------------------------

    def refresh_topbar(self) -> None:
        state = ("[yellow]working[/]" if self.busy else "[green]ready[/]")
        tok = (f" · {self._used_tokens // 1000}k tok" if self._used_tokens
               else "")
        mode = " · [b magenta]PLAN[/]" if self.cfg.plan_mode else ""
        goal = (" · [yellow]goal[/]"
                if self.agent is not None and self.agent.goal else "")
        self.query_one("#topbar", Static).update(
            f"[b]locode[/] · {self.cfg.model} · {self.cfg.approval}{mode}"
            f"{goal} · ctx {self._ctx_pct}%{tok} · {state}"
            f"[dim] · ^C quit[/]")

    def set_thinking(self, on: bool) -> None:
        self.thinking = on

    def set_busy(self, on: bool) -> None:
        self.busy = on
        if on:
            self._busy_t0 = time.monotonic()
            self._verb_t = self._busy_t0
            self._verb = random.choice(VERBS)
        act = self.query_one("#activity", Static)
        act.set_class(on, "on")
        if not on:
            act.update("")
        self.refresh_topbar()

    def _tick_activity(self) -> None:
        if not self.busy:
            return
        now = time.monotonic()
        if now - self._verb_t > 6:
            self._verb = random.choice(VERBS)
            self._verb_t = now
        elapsed = int(now - self._busy_t0)
        label = self._verb if self.thinking or True else self._verb
        self.query_one("#activity", Static).update(
            f"[yellow]{next(SPINNER)}[/] [b]{label}…[/] "
            f"[dim]({elapsed}s · esc to interrupt)[/]")

    def set_ctx(self, used: int, budget: int) -> None:
        self._used_tokens = used
        self._ctx_pct = min(100, int(100 * used / max(1, budget)))
        self.refresh_topbar()

    # -- chat log helpers ---------------------------------------------------

    def _mount_chat(self, widget) -> None:
        chat = self.query_one("#chat", VerticalScroll)
        chat.mount(widget)
        self.call_after_refresh(chat.scroll_end, animate=False)

    def add_line(self, markup: str, klass: str = "line") -> None:
        self._mount_chat(Static(markup, classes=klass))

    def add_renderable(self, renderable) -> None:
        self._mount_chat(Static(renderable, classes="line"))

    def add_markdown(self, text: str) -> None:
        self._last_reply = text
        self._mount_chat(Markdown(text, classes="assistant"))

    def add_user(self, text: str) -> None:
        self.add_line(f"[bold green]❯[/] {escape(text)}", "user")

    # -- tool dropdowns -------------------------------------------------------

    def add_tool_call(self, name: str, summary: str) -> None:
        body = Static("[dim]running…[/]", classes="result-body")
        box = Collapsible(body, title=f"⏺ {name}({summary})",
                          collapsed=True)
        self._cur_tool, self._cur_tool_body = box, body
        self._mount_chat(box)

    def set_tool_result(self, name: str, result: str) -> None:
        lines = result.splitlines() or [""]
        shown = "\n".join(ln[:200] for ln in lines[:40])
        if len(lines) > 40:
            shown += f"\n… +{len(lines) - 40} more line(s)"
        failed = result.startswith(("Error", "Denied")) \
            or result.startswith("exit code:") and \
            not result.startswith("exit code: 0")
        if self._cur_tool_body is not None:
            self._cur_tool_body.update(Text(shown))
        if self._cur_tool is not None:
            mark = "✗" if failed else "✓"
            self._cur_tool.title = f"{mark} {self._cur_tool.title[2:]}" \
                if self._cur_tool.title[:1] in "⏺✓✗" \
                else self._cur_tool.title
        self._cur_tool = self._cur_tool_body = None

    # -- streaming ----------------------------------------------------------

    def append_stream(self, chunk: str) -> None:
        self._collapse_think()
        if self._cur_md is None:
            self._md_src = ""
            self._cur_md = Markdown("", classes="assistant")
            self._mount_chat(self._cur_md)
        self._md_src += chunk
        self._cur_md.update(self._md_src)
        chat = self.query_one("#chat", VerticalScroll)
        self.call_after_refresh(chat.scroll_end, animate=False)

    def append_thinking(self, chunk: str) -> None:
        if self._cur_think is None:
            self._think_src = ""
            self._think_t0 = time.monotonic()
            self._cur_think_body = Static("", classes="think-body")
            self._cur_think = Collapsible(
                self._cur_think_body, title="✻ Thinking…", collapsed=False)
            self._mount_chat(self._cur_think)
        self._think_src += chunk
        self._cur_think_body.update(Text(self._think_src, style="italic"))

    def _collapse_think(self) -> None:
        if self._cur_think is not None:
            secs = max(1, int(time.monotonic() - self._think_t0))
            self._cur_think.title = f"✻ Thought for {secs}s"
            self._cur_think.collapsed = True
            self._cur_think = self._cur_think_body = None
            self._think_src = ""

    def finish_stream(self) -> None:
        self._collapse_think()
        if self._md_src.strip():
            self._last_reply = self._md_src
        self._cur_md = None
        self._md_src = ""

    # -- approvals ------------------------------------------------------------

    def ask_approval(self, tool: str, reason: str, preview: str,
                     q: "queue.Queue[str]") -> None:
        self.push_screen(ApprovalScreen(tool, reason, preview),
                         callback=lambda ans: q.put(ans or "n"))

    def ask_question(self, question: str, options: list[str],
                     q: "queue.Queue[str]") -> None:
        self.push_screen(QuestionScreen(question, options),
                         callback=lambda ans: q.put(ans or ""))

    # -- slash suggestions ------------------------------------------------------

    def _all_commands(self) -> list[tuple[str, str]]:
        items = list(BUILTIN_COMMANDS)
        if self.agent:
            for c in self.agent.commands.values():
                items.append((c.name, c.description or
                              f"custom command ({c.source})"))
        return items

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        area = event.text_area
        if area.id != "prompt":
            return
        raw = area.text
        clean = _strip_leaked_escapes(raw)
        if clean != raw:
            # a stray mouse/CSI escape leaked into the widget — scrub it
            # and stop, the resulting load_text() re-fires this handler
            area.load_text(clean)
            area.move_cursor(area.document.end)
            return
        area.set_class("\n" in raw, "multiline")
        if raw.startswith("/") and "\n" not in raw and " " not in raw:
            prefix = raw[1:].lower()
            items = [(n, d) for n, d in self._all_commands()
                     if n.startswith(prefix)]
            self._show_suggestions(items[:25], kind="slash")
            return

        row, col = area.cursor_location
        line = area.document.get_line(row)
        m = AT_MENTION_RE.search(line[:col])
        if m and self.agent:
            self._at_range = ((row, m.start(1)), (row, col))
            entries = complete_mention_path(self.agent.cfg.project_dir,
                                            m.group(1))
            items = [(p, "dir" if is_dir else "file")
                    for p, is_dir in entries]
            self._show_suggestions(items, kind="at")
            return

        self.suggestions_hide()

    def _show_suggestions(self, items: list[tuple[str, str]],
                         kind: str) -> None:
        box = self.query_one("#suggestions", VerticalScroll)
        box.remove_children()
        box.scroll_home(animate=False)
        self._sugg_items = items
        self._sugg_kind = kind
        self._sugg_sel = 0
        if not items:
            self.suggestions_hide()
            return
        self.suggestions_open = True
        box.add_class("open")
        for i, (name, meta) in enumerate(items):
            sel = " selected" if i == 0 else ""
            if kind == "at":
                icon = "📁" if meta == "dir" else "📄"
                label = f"{icon} {escape(name)}"
            else:
                label = f"[b]/{name}[/]  [dim]{escape(meta[:70])}[/]"
            box.mount(Static(label, classes="sugg" + sel))

    def suggestions_hide(self) -> None:
        self.suggestions_open = False
        box = self.query_one("#suggestions", VerticalScroll)
        box.remove_class("open")
        box.remove_children()
        self._sugg_items = []
        self._sugg_kind = ""
        self._at_range = None

    def suggestions_move(self, delta: int) -> None:
        if not self._sugg_items:
            return
        self._sugg_sel = (self._sugg_sel + delta) % len(self._sugg_items)
        selected = None
        for i, row in enumerate(self.query("#suggestions .sugg")):
            row.set_class(i == self._sugg_sel, "selected")
            if i == self._sugg_sel:
                selected = row
        if selected is not None:
            selected.scroll_visible(animate=False)

    def suggestions_take(self) -> str | None:
        if not self._sugg_items:
            return None
        if self._sugg_kind == "at":
            path, meta = self._sugg_items[self._sugg_sel]
            prompt = self.query_one("#prompt", PromptArea)
            if self._at_range:
                start, end = self._at_range
                insert = path if meta == "dir" else path + " "
                prompt.replace(insert, start, end)
                prompt.cursor_location = (start[0], start[1] + len(insert))
            self.suggestions_hide()
            return None
        name = self._sugg_items[self._sugg_sel][0]
        self.suggestions_hide()
        return "/" + name + " "

    # -- input ------------------------------------------------------------

    def on_prompt_area_submitted(self, event: PromptArea.Submitted) -> None:
        text = _strip_leaked_escapes(event.value).strip()
        prompt = self.query_one("#prompt", PromptArea)
        if self.suggestions_open and self._sugg_items:
            # enter with the popup open runs the selected command
            sel = f"/{self._sugg_items[self._sugg_sel][0]}"
            if sel.startswith(text) and text != sel:
                text = sel
        self.suggestions_hide()
        prompt.clear()
        prompt.set_class(False, "multiline")
        if not text:
            return
        prompt.remember(text)
        if self.busy:
            self.add_line("[yellow]•[/] [dim]still working — Esc to "
                          "interrupt first.[/]", "line")
            return
        if text.startswith("/") and "\n" not in text:
            try:
                action, payload = handle(text, self.agent, self.ui_adapter)
            except Exception as e:
                self.ui_adapter.error(f"{type(e).__name__}: {e}")
                return
            if action == "quit":
                self.exit()
            elif action == "agent":
                self.agent = payload
            elif action == "prompt":
                self._start_turn(payload, echo=text)
                return
            elif action == "side":
                self._start_side(payload)
                return
            elif action == "resume":
                self._open_resume_picker(payload)
                return
            self.refresh_topbar()
            return
        self._start_turn(text)

    def _start_turn(self, text: str, echo: str | None = None) -> None:
        self.add_user(echo or text)
        self.set_busy(True)
        self.ui_adapter.interrupt.clear()
        self.run_worker(lambda: self._turn_worker(text), thread=True,
                        exclusive=True, group="turn")

    # -- the worker ---------------------------------------------------------

    def _turn_worker(self, text: str) -> None:
        ui = self.ui_adapter
        try:
            self.agent.drive(text)
        except KeyboardInterrupt:
            ui.notice("turn interrupted — context preserved.")
        except ConnectionError as e:
            ui.error(str(e))
        except Exception as e:
            ui.error(f"unexpected {type(e).__name__}: {e}")
        finally:
            ui.stream_end()
            self.call_from_thread(self.set_busy, False)
            self.call_from_thread(self.refresh_topbar)
            self.call_from_thread(
                self.query_one("#prompt", PromptArea).focus)

    def _start_side(self, question: str) -> None:
        self.add_line(f"[bold magenta]btw ❯[/] {escape(question)}", "user")
        self.set_busy(True)
        self.ui_adapter.interrupt.clear()
        self.run_worker(lambda: self._side_worker(question), thread=True,
                        exclusive=True, group="turn")

    def _side_worker(self, question: str) -> None:
        ui = self.ui_adapter
        try:
            self.agent.side_question(question)
            ui.notice("side answer — not added to the conversation context.")
        except KeyboardInterrupt:
            ui.notice("interrupted.")
        except ConnectionError as e:
            ui.error(str(e))
        except Exception as e:
            ui.error(f"unexpected {type(e).__name__}: {e}")
        finally:
            ui.stream_end()
            self.call_from_thread(self.set_busy, False)
            self.call_from_thread(self.refresh_topbar)
            self.call_from_thread(
                self.query_one("#prompt", PromptArea).focus)

    # -- actions ------------------------------------------------------------

    def action_toggle_plan(self) -> None:
        self.cfg.plan_mode = not self.cfg.plan_mode
        self.ui_adapter.notice(
            "plan mode ON — research only; I'll ask before executing."
            if self.cfg.plan_mode else "plan mode off.")
        self.refresh_topbar()

    def action_interrupt(self) -> None:
        if self.suggestions_open:
            self.suggestions_hide()
            return
        if self.busy and self.ui_adapter:
            self.ui_adapter.interrupt.set()
            self.add_line("[yellow]•[/] [dim]stopping…[/]", "line")

    def action_smart_quit(self) -> None:
        if self.busy:
            self.action_interrupt()
        else:
            self.exit()

    def action_clear_view(self) -> None:
        self.query_one("#chat", VerticalScroll).remove_children()

    def action_copy_reply(self) -> None:
        if not self._last_reply:
            self.ui_adapter.notice("nothing to copy yet.")
            return
        self.copy_to_clipboard(self._last_reply)
        self.ui_adapter.notice(
            "copied the last reply to your clipboard. (For selecting "
            "arbitrary text -- tool output, older messages -- hold Shift "
            "while dragging to use your terminal's native selection, "
            "then Ctrl+C/Ctrl+Shift+C as your terminal expects.)")
