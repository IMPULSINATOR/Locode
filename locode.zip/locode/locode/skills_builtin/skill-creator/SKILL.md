---
name: skill-creator
description: Create, scaffold, or improve Agent Skills (SKILL.md packs) for locode, Claude Code, or any agentskills.io-compatible tool. Use whenever the user asks to make a skill, write a SKILL.md, teach the agent a new capability, package a workflow, or turn instructions into a reusable skill.
license: MIT
---

# Skill Creator

You are helping the user author a skill that follows the open Agent Skills
standard (https://agentskills.io/specification), so it works in locode,
Claude Code, Codex CLI and other compatible agents.

## What a skill is

```
skill-name/
├── SKILL.md          required — frontmatter + instructions
├── scripts/          optional — executable helpers the agent runs
├── references/       optional — docs the agent reads when needed
└── assets/           optional — templates/files used in output
```

## Workflow

1. Ask (briefly) if unclear: what task should the skill cover, and what are
   2-3 example requests that should trigger it?
2. Pick a name: lowercase letters, digits and hyphens only, max 64 chars,
   must not start/end with a hyphen, and MUST exactly match the folder name.
3. Choose the location:
   - project-specific → `.locode/skills/<name>/` in the project root
   - personal/global → `~/.config/locode/skills/<name>/`
   (Claude Code equivalents `.claude/skills/` and `~/.claude/skills/` also
   work — ask the user if they want cross-tool sharing.)
4. Write `SKILL.md` with write_file.
5. Validate against the checklist below, then tell the user to run
   `/clear` (or restart locode) so the new skill is discovered.

## Frontmatter rules

Required — and only these two are required:

```yaml
---
name: my-skill-name
description: What the skill does AND when to use it, with trigger words.
---
```

- `description` ≤ 1024 chars. It is the ONLY thing the agent sees before
  deciding to load the skill, so make it "pushy": state the capability,
  then list trigger phrases ("Use when the user mentions X, Y, Z…").
- Never put `<` or `>` in frontmatter values (prompt-injection risk).
- Optional fields: `license`, `metadata:` (author/version), `compatibility`
  (rarely needed), `allowed-tools` (experimental; runtimes may ignore it).

## Body rules

- Markdown, imperative voice, written TO the agent ("Run…", "Never…").
- Keep it under ~500 lines / ~5k tokens. Move detail into
  `references/*.md` and link with relative paths one level deep.
- Prefer a deterministic `scripts/*.py` over prose for anything mechanical
  (parsing, conversion, validation) and tell the agent when to run it.
- Recommended sections: `# Title`, `## When to use`, `## Steps`,
  `## Examples`, `## Guidelines`.

## Validation checklist

- [ ] folder name == frontmatter `name`, lowercase-hyphen, ≤64 chars
- [ ] description states what + when, ≤1024 chars, no angle brackets
- [ ] body ≤ ~500 lines; deep detail moved to references/
- [ ] any referenced file actually exists at the relative path
- [ ] a stranger's request matching the description would be well served
      by following the body verbatim

## Improving an existing skill

Read its SKILL.md, diagnose against the checklist, then apply the smallest
edit that fixes the gap — usually the description (bad triggering) or
splitting an oversized body into references/.
